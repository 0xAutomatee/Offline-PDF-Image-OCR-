USE [WallMartSummary];
GO

/*==============================================================================
    PROJECT       : WALMART SUMMARY
    PROCEDURE     : dbo.sp_Run_WallMartSummary
    DESCRIPTION   : Run all Walmart Summary procedures in sequence
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_Run_WallMartSummary
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY

        /*----------------------------------------------------------------------
          1. Drop existing Walmart summary and report tables
        ----------------------------------------------------------------------*/
        EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;

        /*----------------------------------------------------------------------
          2. Generate DB and Invoice tables
        ----------------------------------------------------------------------*/
        EXEC dbo.sp_WallMartSummary_db_and_inv_tabels;

        /*----------------------------------------------------------------------
          3. Generate DB Status
        ----------------------------------------------------------------------*/
        EXEC dbo.sp_WallMartSummary_gen_DBs_Status;

        /*----------------------------------------------------------------------
          4. Generate Invoice Status
        ----------------------------------------------------------------------*/
        EXEC dbo.sp_WallMartSummary_Invoice_Status;

        PRINT 'WallMart Summary procedures executed successfully.';

    END TRY
    BEGIN CATCH

        PRINT CONCAT(
            'WallMart Summary execution failed. Error: ',
            ERROR_MESSAGE()
        );

        THROW;

    END CATCH;
END;
GO


/*==============================================================================
    RUN MASTER PROCEDURE
==============================================================================*/

-- EXEC dbo.sp_Run_WallMartSummary;
GO