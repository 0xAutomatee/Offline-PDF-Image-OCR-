CREATE PROCEDURE dbo.sp_Run_WallMartSummary
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY

       -- 1. Drop Walmart summary and report tables if they exist

       EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;

         -- 1A. Generate DB and Invoice Tables
        EXEC dbo.sp_WallMartSummary_db_and_inv_tabels;

        -- 2. Generate DB Status
        EXEC dbo.sp_WallMartSummary_gen_DBs_Status;

        -- 3. Update Invoice Status
        EXEC dbo.sp_WallMartSummary_Invoice_Status;


        PRINT 'WallMart Summary procedures executed successfully.';
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO


-- Execute the master procedure
-- EXEC dbo.sp_Run_WallMartSummary;