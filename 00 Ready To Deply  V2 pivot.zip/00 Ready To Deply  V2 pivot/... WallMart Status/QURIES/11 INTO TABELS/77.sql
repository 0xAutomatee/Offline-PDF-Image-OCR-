USE [WallMartSummary];
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALMART SUMMARY
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_db_and_inv_tabels
|
|  VERSION
|  `-- V-07
|
|  SOURCE
|  `-- dbo.step_01_inquiry_rows
|
|  MAIN TABLE
|  `-- dbo.WallMartSummary_Sheet
|
|  OUTPUT TABLES
|  |-- dbo.WC9085_Invoices
|  |-- dbo.WC9085_DBs
|  |-- dbo.WA9085_Invoices
|  |-- dbo.WA9085_DBs
|  |-- dbo.SA9200_Invoices
|  |-- dbo.SA9200_DBs
|  |-- dbo.WM9263_Invoices
|  `-- dbo.WM9263_DBs
|
|  DESCRIPTION
|  `-- Prepare source data and create account-wise invoice and DB tables.
|
==============================================================================*/


/*==============================================================================
|
|  QUERY INDEX
|
|  |-- Q#001  Validate source table
|  |-- Q#002  Recreate WallMartSummary_Sheet
|  |-- Q#003  Add and update InvYear
|  |-- Q#004  Add and update WriteStatus
|  |-- Q#005  Add and update Paid
|  |-- Q#006  Add and update PaidnFullyDeduct
|  |-- Q#007  Create WC9085 invoice and DB tables
|  |-- Q#008  Create WA9085 invoice and DB tables
|  |-- Q#009  Create SA9200 invoice and DB tables
|  |-- Q#010  Create WM9263 invoice and DB tables
|  `-- Q#011  Verify all created tables
|
==============================================================================*/


CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_db_and_inv_tabels
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @RowsAffected INT = 0,
        @SourceRows   INT = 0;

    BEGIN TRY

        PRINT '============================================================';
        PRINT 'PROJECT       : WALMART SUMMARY';
        PRINT 'PROCEDURE     : dbo.sp_WallMartSummary_db_and_inv_tabels';
        PRINT 'QUERY VERSION : V-07';
        PRINT 'SOURCE TABLE  : dbo.step_01_inquiry_rows';
        PRINT '============================================================';


        /*======================================================================
        |-- Q#001 | SOURCE | Validate required source table
        ======================================================================*/

        RAISERROR(
            'Q#001 started: Validating source table...',
            0,
            1
        ) WITH NOWAIT;

        IF OBJECT_ID('dbo.step_01_inquiry_rows', 'U') IS NULL
        BEGIN
            THROW 50001,
                  'Required source table dbo.step_01_inquiry_rows was not found.',
                  1;
        END;

        SELECT @SourceRows = COUNT(*)
        FROM dbo.step_01_inquiry_rows;

        PRINT CONCAT(
            'Q#001 completed: Source table found. Rows = ',
            @SourceRows
        );

    /*======================================================================
        |-- Q#001A | update the date  to US FORMAT
        ======================================================================*/


/*-- Format [date] as US date: MM/DD/YYYY */
UPDATE dbo.step_01_inquiry_rows
SET [date] = CONVERT(VARCHAR(10), TRY_CONVERT(DATE, [date]), 101)
WHERE TRY_CONVERT(DATE, [date]) IS NOT NULL;

SET @RowsAffected = @@ROWCOUNT;

PRINT CONCAT(
    'Date format updated to MM/DD/YYYY. Rows affected: ',
    @RowsAffected
);




   /*======================================================================
        |-- Q#001B | update the due_date  to US FORMAT
        ======================================================================*/


/*-- Format [due_date] as US date: MM/DD/YYYY */
UPDATE dbo.step_01_inquiry_rows
SET [due_date] = CONVERT(VARCHAR(10), TRY_CONVERT(DATE, [date]), 101)
WHERE TRY_CONVERT(DATE, [due_date]) IS NOT NULL;

SET @RowsAffected = @@ROWCOUNT;

PRINT CONCAT(
    'Due_Date format updated to MM/DD/YYYY. Rows affected: ',
    @RowsAffected
);



















        /*======================================================================
        |-- Q#002 | WMS | Recreate optimized source table
        ======================================================================*/

        RAISERROR(
            'Q#002 started: Recreating dbo.WallMartSummary_Sheet...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WallMartSummary_Sheet;

        SELECT *
        INTO dbo.WallMartSummary_Sheet
        FROM dbo.step_01_inquiry_rows;

        SET @RowsAffected = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#002 completed: WallMartSummary_Sheet created. Rows = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#003 | WMS.InvYear | Add and populate invoice year
        ======================================================================*/

        RAISERROR(
            'Q#003 started: Adding and updating InvYear...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'InvYear') IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD InvYear INT NULL;

            PRINT 'Q#003 info: InvYear column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#003 info: InvYear column already exists.';
        END;

        EXEC sys.sp_executesql N'
            UPDATE WMS
            SET WMS.InvYear =
                YEAR(TRY_CONVERT(DATETIME, WMS.[date]))
            FROM dbo.WallMartSummary_Sheet AS WMS
            WHERE WMS.[date] IS NOT NULL;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#003 completed: InvYear rows updated = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#004 | WMS.WriteStatus | Add and populate write-up status
        ======================================================================*/

        RAISERROR(
            'Q#004 started: Adding and updating WriteStatus...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'WriteStatus') IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD WriteStatus VARCHAR(50) NULL;

            PRINT 'Q#004 info: WriteStatus column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#004 info: WriteStatus column already exists.';
        END;

        EXEC sys.sp_executesql N'
            UPDATE WMS
            SET WMS.WriteStatus =
                CASE
                    WHEN WMS.comment LIKE ''%write%''
                        THEN ''Write-up Sent''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#004 completed: WriteStatus rows processed = ',
            @RowsAffected
        );





        /*======================================================================
        |--Q#005A | WMS.RetailLinkStatus | Add and populate Retail Link status
        ======================================================================*/

        RAISERROR(
            'Q#005A started: Adding and updating RetailLinkStatus...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'RetailLinkStatus') IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD RetailLinkStatus VARCHAR(50) NULL;

            PRINT 'Q#005A info: RetailLinkStatus column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#005A info: RetailLinkStatus column already exists.';
        END;

        EXEC sys.sp_executesql N'
            UPDATE WMS
            SET WMS.RetailLinkStatus =
                CASE
                    WHEN WMS.comment LIKE ''%No%''
                     AND WMS.comment LIKE ''%Record%''
                        THEN ''NoRetailLink''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#005A completed: RetailLinkStatus rows processed = ',
            @RowsAffected
        );












        /*======================================================================
        |-- Q#005 | WMS.Paid | Add and populate invoice-paid status
        ======================================================================*/

        RAISERROR(
            'Q#005 started: Adding and updating Paid...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'Paid') IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD Paid VARCHAR(50) NULL;

            PRINT 'Q#005 info: Paid column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#005 info: Paid column already exists.';
        END;

        EXEC sys.sp_executesql N'
   UPDATE WMS
SET WMS.Paid =
    CASE
        /* Unpaid rows */
        WHEN LTRIM(RTRIM(WMS.[comment]))
             COLLATE Latin1_General_100_CI_AS LIKE ''Unpaid%''
            THEN ''Unpaid''

        /* Paid rows, but exclude deducted comments */
        WHEN
        (
               LTRIM(RTRIM(WMS.[comment]))
               COLLATE Latin1_General_100_CI_AS LIKE ''Paid%''

            OR LTRIM(RTRIM(WMS.[comment]))
               COLLATE Latin1_General_100_CI_AS LIKE ''Fully paid%''
        )
        AND LTRIM(RTRIM(WMS.[comment]))
            COLLATE Latin1_General_100_CI_AS NOT LIKE ''%dedu%''
        AND LTRIM(RTRIM(WMS.[comment]))
            COLLATE Latin1_General_100_CI_AS NOT LIKE ''%fully ded%''
            THEN ''InvPaid''

        ELSE NULL
    END
FROM dbo.WallMartSummary_Sheet AS WMS
WHERE LTRIM(RTRIM(WMS.[ref])) LIKE ''IN%'';

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#005 completed: Paid rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#006 | WMS.PaidnFullyDeduct | Add and populate deducted status
        ======================================================================*/

        RAISERROR(
            'Q#006 started: Adding and updating PaidnFullyDeduct...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'PaidnFullyDeduct'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD PaidnFullyDeduct VARCHAR(50) NULL;

            PRINT 'Q#006 info: PaidnFullyDeduct column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#006 info: PaidnFullyDeduct column already exists.';
        END;

        EXEC sys.sp_executesql N'
            UPDATE WMS
            SET WMS.PaidnFullyDeduct =
                CASE
                    WHEN WMS.comment LIKE ''%paid%''
                     AND WMS.comment LIKE ''%deducted%''
                        THEN ''PaidnDeducted''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#006 completed: PaidnFullyDeduct rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#007 | WC9085 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#007 started: Creating WC9085 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WC9085_Invoices;
        DROP TABLE IF EXISTS dbo.WC9085_DBs;

        SELECT *
        INTO dbo.WC9085_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WC9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q007_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WC9085_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WC9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q007_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#007 completed: WC9085_Invoices = ',
            @Q007_InvoiceRows,
            ', WC9085_DBs = ',
            @Q007_DBRows
        );


        /*======================================================================
        |-- Q#008 | WA9085 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#008 started: Creating WA9085 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WA9085_Invoices;
        DROP TABLE IF EXISTS dbo.WA9085_DBs;

        SELECT *
        INTO dbo.WA9085_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WA9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q008_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WA9085_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WA9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q008_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#008 completed: WA9085_Invoices = ',
            @Q008_InvoiceRows,
            ', WA9085_DBs = ',
            @Q008_DBRows
        );


        /*======================================================================
        |-- Q#009 | SA9200 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#009 started: Creating SA9200 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.SA9200_Invoices;
        DROP TABLE IF EXISTS dbo.SA9200_DBs;

        SELECT *
        INTO dbo.SA9200_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'SA9200'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q009_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.SA9200_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'SA9200'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q009_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#009 completed: SA9200_Invoices = ',
            @Q009_InvoiceRows,
            ', SA9200_DBs = ',
            @Q009_DBRows
        );


        /*======================================================================
        |-- Q#010 | WM9263 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#010 started: Creating WM9263 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WM9263_Invoices;
        DROP TABLE IF EXISTS dbo.WM9263_DBs;

        SELECT *
        INTO dbo.WM9263_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WM9263'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q010_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WM9263_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WM9263'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q010_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#010 completed: WM9263_Invoices = ',
            @Q010_InvoiceRows,
            ', WM9263_DBs = ',
            @Q010_DBRows
        );


        /*======================================================================
        |-- Q#011 | ALL TABLES | Verify table names and row counts
        ======================================================================*/

        RAISERROR(
            'Q#011 started: Verifying account tables...',
            0,
            1
        ) WITH NOWAIT;

        SELECT
            V.Table_Name,
            V.Total_Rows
        FROM
        (
            SELECT
                1 AS Table_Order,
                'WC9085_Invoices' AS Table_Name,
                COUNT(*) AS Total_Rows
            FROM dbo.WC9085_Invoices

            UNION ALL

            SELECT 2, 'WC9085_DBs', COUNT(*)
            FROM dbo.WC9085_DBs

            UNION ALL

            SELECT 3, 'WA9085_Invoices', COUNT(*)
            FROM dbo.WA9085_Invoices

            UNION ALL

            SELECT 4, 'WA9085_DBs', COUNT(*)
            FROM dbo.WA9085_DBs

            UNION ALL

            SELECT 5, 'SA9200_Invoices', COUNT(*)
            FROM dbo.SA9200_Invoices

            UNION ALL

            SELECT 6, 'SA9200_DBs', COUNT(*)
            FROM dbo.SA9200_DBs

            UNION ALL

            SELECT 7, 'WM9263_Invoices', COUNT(*)
            FROM dbo.WM9263_Invoices

            UNION ALL

            SELECT 8, 'WM9263_DBs', COUNT(*)
            FROM dbo.WM9263_DBs
        ) AS V
        ORDER BY V.Table_Order;

        PRINT 'Q#011 completed: All account tables verified.';

        PRINT '============================================================';
        PRINT 'PROCEDURE COMPLETED SUCCESSFULLY';
        PRINT '============================================================';

    END TRY
    BEGIN CATCH

        DECLARE
            @ErrorNumber    INT            = ERROR_NUMBER(),
            @ErrorLine      INT            = ERROR_LINE(),
            @ErrorProcedure NVARCHAR(256)  = ERROR_PROCEDURE(),
            @ErrorMessage   NVARCHAR(4000) = ERROR_MESSAGE();

        PRINT '============================================================';
        PRINT 'PROCEDURE FAILED';
        PRINT CONCAT('ERROR NUMBER    : ', @ErrorNumber);
        PRINT CONCAT('ERROR PROCEDURE : ', COALESCE(@ErrorProcedure, 'N/A'));
        PRINT CONCAT('ERROR LINE      : ', @ErrorLine);
        PRINT CONCAT('ERROR MESSAGE   : ', @ErrorMessage);
        PRINT '============================================================';

        THROW;

    END CATCH;
END;
GO


/*==============================================================================
|-- EXECUTE PROCEDURE
==============================================================================*/

-- EXEC dbo.sp_WallMartSummary_db_and_inv_tabels;
GO

