USE [WallMartSummary];
GO

/*==============================================================================
|  WALMART OPEN ACCOUNT
|  -- CREATE ACCOUNT-WISE INVOICE AND DB TABLES
|
|  VERSION
|  -- V-02
==============================================================================*/





sql
USE [WallMartSummary];
GO

/*==============================================================================
|
|  PROJECT
|  -- WALMART SUMMARY
|
|  SCRIPT
|  -- CREATE ACCOUNT-WISE INVOICE AND DB TABLES
|
|  VERSION
|  -- V-01
|
|  SOURCE
|  -- dbo.step_01_inquiry_rows
|
|  MAIN TABLE
|  -- dbo.WallMartSummary_Sheet
|
|  OUTPUT TABLES
|  |-- dbo.WC9085_Invoices
|  |-- dbo.WC9085_DBs
|  |-- dbo.WA9085_Invoices
|  |-- dbo.WA9085_DBs
|  |-- dbo.SA9200_Invoices
|  |-- dbo.SA9200_DBs
|  |-- dbo.WM9263_Invoices
|  -- dbo.WM9263_DBs
|
|  --DESCRIPTION
|  -- Prepare source data and create account-wise IN and DB tables.
|
==============================================================================*/


/*==============================================================================
|
|  QUERY INDEX
|
|  |-- Q#001  Recreate dbo.WallMartSummary_Sheet
|  |-- Q#002  Add InvYear column
|  |-- Q#003  Update InvYear from [date]
|  |-- Q#004  Add WriteStatus column
|  |-- Q#005  Update WriteStatus
|  |-- Q#006  Add Paid column
|  |-- Q#007  Update Paid status
|  |-- Q#008  Add PaidnFullyDeduct column
|  |-- Q#009  Update PaidnFullyDeduct status
|  |-- Q#010  Create WC9085 invoice and DB tables
|  |-- Q#011  Create WA9085 invoice and DB tables
|  |-- Q#012  Create SA9200 invoice and DB tables
|  |-- Q#013  Create WM9263 invoice and DB tables
|  -- Q#014  Verify all created tables
|
==============================================================================*/











/*==============================================================================
|-- Q#001 - CREATE OPTIMIZED SOURCE TABLE
|-- SOURCE : dbo.step_01_inquiry_rows
|-- TARGET : dbo.WallMartSummary_Sheet
==============================================================================*/

DROP TABLE IF EXISTS dbo.WallMartSummary_Sheet;
GO

SELECT *
INTO dbo.WallMartSummary_Sheet
FROM dbo.step_01_inquiry_rows;

DECLARE @Q001_RowsInserted INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#001 completed: dbo.WallMartSummary_Sheet created. Rows inserted = ',
    @Q001_RowsInserted
);
GO


/*==============================================================================
|-- Q#002 - ADD InvYear COLUMN
|-- SOURCE : dbo.WallMartSummary_Sheet.[date]
|-- EXAMPLE: 2021-10-19 00:00:00 -> 2021
==============================================================================*/

IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'InvYear') IS NULL
BEGIN
    ALTER TABLE dbo.WallMartSummary_Sheet
    ADD InvYear INT NULL;

    PRINT 'Q#002 completed: InvYear column added.';
END
ELSE
BEGIN
    PRINT 'Q#002 completed: InvYear column already exists.';
END;
GO


/*==============================================================================
|-- Q#003 - UPDATE InvYear
==============================================================================*/

DECLARE @Q003_RowsUpdated INT;

UPDATE WMS
SET WMS.InvYear = YEAR(TRY_CONVERT(DATETIME, WMS.[date]))
FROM dbo.WallMartSummary_Sheet AS WMS
WHERE WMS.[date] IS NOT NULL;

SET @Q003_RowsUpdated = @@ROWCOUNT;

PRINT CONCAT(
    'Q#003 completed: InvYear rows updated = ',
    @Q003_RowsUpdated
);
GO


/*==============================================================================
|-- Q#004 - ADD WriteStatus COLUMN
==============================================================================*/

IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'WriteStatus') IS NULL
BEGIN
    ALTER TABLE dbo.WallMartSummary_Sheet
    ADD WriteStatus VARCHAR(50) NULL;

    PRINT 'Q#004 completed: WriteStatus column added.';
END
ELSE
BEGIN
    PRINT 'Q#004 completed: WriteStatus column already exists.';
END;
GO


/*==============================================================================
|-- Q#005 - UPDATE WriteStatus
==============================================================================*/

DECLARE @Q005_RowsUpdated INT;

UPDATE WMS
SET WMS.WriteStatus =
    CASE
        WHEN WMS.comment LIKE '%write%'
            THEN 'Write-up Sent'
        ELSE NULL
    END
FROM dbo.WallMartSummary_Sheet AS WMS;

SET @Q005_RowsUpdated = @@ROWCOUNT;

PRINT CONCAT(
    'Q#005 completed: WriteStatus rows processed = ',
    @Q005_RowsUpdated
);
GO


/*==============================================================================
|-- Q#006 - ADD Paid COLUMN
==============================================================================*/

IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'Paid') IS NULL
BEGIN
    ALTER TABLE dbo.WallMartSummary_Sheet
    ADD Paid VARCHAR(50) NULL;

    PRINT 'Q#006 completed: Paid column added.';
END
ELSE
BEGIN
    PRINT 'Q#006 completed: Paid column already exists.';
END;
GO


/*==============================================================================
|-- Q#007 - UPDATE Paid
|-- RULE   : Contains "paid" but does not contain "deducted"
==============================================================================*/

DECLARE @Q007_RowsUpdated INT;

UPDATE WMS
SET WMS.Paid =
    CASE
        WHEN WMS.comment LIKE '%paid%'
         AND WMS.comment NOT LIKE '%deducted%'
            THEN 'InvPaid'
        ELSE NULL
    END
FROM dbo.WallMartSummary_Sheet AS WMS;

SET @Q007_RowsUpdated = @@ROWCOUNT;

PRINT CONCAT(
    'Q#007 completed: Paid rows processed = ',
    @Q007_RowsUpdated
);
GO


/*==============================================================================
|-- Q#008 - ADD PaidnFullyDeduct COLUMN
==============================================================================*/

IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'PaidnFullyDeduct') IS NULL
BEGIN
    ALTER TABLE dbo.WallMartSummary_Sheet
    ADD PaidnFullyDeduct VARCHAR(50) NULL;

    PRINT 'Q#008 completed: PaidnFullyDeduct column added.';
END
ELSE
BEGIN
    PRINT 'Q#008 completed: PaidnFullyDeduct column already exists.';
END;
GO


/*==============================================================================
|-- Q#009 - UPDATE PaidnFullyDeduct
|-- RULE   : Contains both "paid" and "deducted"
==============================================================================*/

DECLARE @Q009_RowsUpdated INT;

UPDATE WMS
SET WMS.PaidnFullyDeduct =
    CASE
        WHEN WMS.comment LIKE '%paid%'
         AND WMS.comment LIKE '%deducted%'
            THEN 'PaidnDeducted'
        ELSE NULL
    END
FROM dbo.WallMartSummary_Sheet AS WMS;

SET @Q009_RowsUpdated = @@ROWCOUNT;

PRINT CONCAT(
    'Q#009 completed: PaidnFullyDeduct rows processed = ',
    @Q009_RowsUpdated
);
GO


/*==============================================================================
|-- Q#010 - CREATE WC9085 TABLES
==============================================================================*/

DROP TABLE IF EXISTS dbo.WC9085_Invoices;
DROP TABLE IF EXISTS dbo.WC9085_DBs;

SELECT *
INTO dbo.WC9085_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WC9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

DECLARE @Q010_InvoiceRows INT = @@ROWCOUNT;

SELECT *
INTO dbo.WC9085_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WC9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

DECLARE @Q010_DBRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#010 completed: WC9085_Invoices = ',
    @Q010_InvoiceRows,
    ', WC9085_DBs = ',
    @Q010_DBRows
);
GO


/*==============================================================================
|-- Q#011 - CREATE WA9085 TABLES
==============================================================================*/

DROP TABLE IF EXISTS dbo.WA9085_Invoices;
DROP TABLE IF EXISTS dbo.WA9085_DBs;

SELECT *
INTO dbo.WA9085_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WA9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

DECLARE @Q011_InvoiceRows INT = @@ROWCOUNT;

SELECT *
INTO dbo.WA9085_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WA9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

DECLARE @Q011_DBRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#011 completed: WA9085_Invoices = ',
    @Q011_InvoiceRows,
    ', WA9085_DBs = ',
    @Q011_DBRows
);
GO


/*==============================================================================
|-- Q#012 - CREATE SA9200 TABLES
==============================================================================*/

DROP TABLE IF EXISTS dbo.SA9200_Invoices;
DROP TABLE IF EXISTS dbo.SA9200_DBs;

SELECT *
INTO dbo.SA9200_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'SA9200'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

DECLARE @Q012_InvoiceRows INT = @@ROWCOUNT;

SELECT *
INTO dbo.SA9200_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'SA9200'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

DECLARE @Q012_DBRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#012 completed: SA9200_Invoices = ',
    @Q012_InvoiceRows,
    ', SA9200_DBs = ',
    @Q012_DBRows
);
GO


/*==============================================================================
|-- Q#013 - CREATE WM9263 TABLES
==============================================================================*/

DROP TABLE IF EXISTS dbo.WM9263_Invoices;
DROP TABLE IF EXISTS dbo.WM9263_DBs;

SELECT *
INTO dbo.WM9263_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WM9263'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

DECLARE @Q013_InvoiceRows INT = @@ROWCOUNT;

SELECT *
INTO dbo.WM9263_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WM9263'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

DECLARE @Q013_DBRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#013 completed: WM9263_Invoices = ',
    @Q013_InvoiceRows,
    ', WM9263_DBs = ',
    @Q013_DBRows
);
GO


/*==============================================================================
|-- Q#014 - VERIFY CREATED TABLES
==============================================================================*/

SELECT
    V.Table_Name,
    V.Total_Rows
FROM
(
    SELECT
        1 AS Table_Order,
        'WC9085_Invoices' AS Table_Name,
        COUNT(*) AS Total_Rows
    FROM dbo.WC9085_Invoices

    UNION ALL

    SELECT
        2,
        'WC9085_DBs',
        COUNT(*)
    FROM dbo.WC9085_DBs

    UNION ALL

    SELECT
        3,
        'WA9085_Invoices',
        COUNT(*)
    FROM dbo.WA9085_Invoices

    UNION ALL

    SELECT
        4,
        'WA9085_DBs',
        COUNT(*)
    FROM dbo.WA9085_DBs

    UNION ALL

    SELECT
        5,
        'SA9200_Invoices',
        COUNT(*)
    FROM dbo.SA9200_Invoices

    UNION ALL

    SELECT
        6,
        'SA9200_DBs',
        COUNT(*)
    FROM dbo.SA9200_DBs

    UNION ALL

    SELECT
        7,
        'WM9263_Invoices',
        COUNT(*)
    FROM dbo.WM9263_Invoices

    UNION ALL

    SELECT
        8,
        'WM9263_DBs',
        COUNT(*)
    FROM dbo.WM9263_DBs
) AS V
ORDER BY V.Table_Order;

PRINT 'Q#014 completed: Account-wise invoice and DB tables verified.';
GO