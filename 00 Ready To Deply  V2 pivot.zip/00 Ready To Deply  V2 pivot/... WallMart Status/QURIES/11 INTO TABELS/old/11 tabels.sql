/*==============================================================================
|  WALMART OPEN ACCOUNT
|  `-- CREATE ACCOUNT-WISE INVOICE AND DB TABLES
==============================================================================*/


/*==============================================================================
|-- 00. Optimize The data
==============================================================================*/



/*==============================================================================
|--  step 001   ADD InvYear COLUMN
|-- SOURCE : dbo.WallMartSummary_Sheet.[date]
|-- RESULT : 2021-10-19 00:00:00 → 2021
==============================================================================*/

/*==============================================================================
|-- DROP OLD TABLE IF IT EXISTS
==============================================================================*/



DROP TABLE IF EXISTS dbo.WallMartSummary_Sheet;
GO

/*==============================================================================
|-- CREATE WallMartSummary_Sheet FROM step_01_inquiry_rows
==============================================================================*/

SELECT *
INTO dbo.WallMartSummary_Sheet
FROM dbo.step_01_inquiry_rows;
GO

PRINT CONCAT(
    'dbo.WallMartSummary_Sheet created successfully. Rows inserted: ',
    (SELECT COUNT(*) FROM dbo.WallMartSummary_Sheet)
);
GO















IF COL_LENGTH('dbo.WallMartSummary_Sheet', 'InvYear') IS NULL
BEGIN
    ALTER TABLE dbo.WallMartSummary_Sheet
    ADD InvYear INT NULL;

    PRINT 'InvYear column added successfully.';
END
ELSE
BEGIN
    PRINT 'InvYear column already exists.';
END;
GO

/*==============================================================================
|-- UPDATE InvYear FROM [date]
==============================================================================*/

UPDATE dbo.WallMartSummary_Sheet
SET InvYear = YEAR(TRY_CONVERT(DATETIME, [date]))
WHERE [date] IS NOT NULL;

PRINT CONCAT('InvYear rows updated: ', @@ROWCOUNT);



-- Step 1: Add WriteStatus column if it does not exist
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'WallMartSummary_Sheet' 
      AND COLUMN_NAME = 'WriteStatus'
)
BEGIN
    ALTER TABLE WallMartSummary_Sheet
    ADD WriteStatus VARCHAR(50);
END;

GO


-- Step 2: Populate WriteStatus column
-- Marks records where comment contains "write"
UPDATE WallMartSummary_Sheet
SET WriteStatus = CASE
    WHEN comment LIKE '%write%' THEN 'Write-up Sent'
    ELSE NULL
END;

GO


-- Step 3: Add Paid column if it does not exist
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'WallMartSummary_Sheet' 
      AND COLUMN_NAME = 'Paid'
)
BEGIN
    ALTER TABLE WallMartSummary_Sheet
    ADD Paid VARCHAR(50);
END;

GO


-- Step 4: Populate Paid column
-- Marks paid records except those that contain "deducted"
UPDATE WallMartSummary_Sheet
SET Paid = CASE
    WHEN comment LIKE '%paid%' 
         AND comment NOT LIKE '%deducted%' 
    THEN 'InvPaid'
    ELSE NULL
END;

GO


-- Step 5: Add PaidnFullyDeduct column if it does not exist
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'WallMartSummary_Sheet' 
      AND COLUMN_NAME = 'PaidnFullyDeduct'
)
BEGIN
    ALTER TABLE WallMartSummary_Sheet
    ADD PaidnFullyDeduct VARCHAR(50);
END;

GO


-- Step 6: Populate PaidnFullyDeduct column
-- Marks paid records where deduction is mentioned
UPDATE WallMartSummary_Sheet
SET PaidnFullyDeduct = CASE
    WHEN comment LIKE '%paid%' 
         AND comment LIKE '%deducted%' 
    THEN 'PaidnDeducted'
    ELSE NULL
END;

GO






/*==============================================================================
|-- 01. WC9085
==============================================================================*/

DROP TABLE IF EXISTS dbo.WC9085_Invoices;
DROP TABLE IF EXISTS dbo.WC9085_DBs;

SELECT *
INTO dbo.WC9085_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WC9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

SELECT *
INTO dbo.WC9085_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WC9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';


/*==============================================================================
|-- 02. WA9085
==============================================================================*/

DROP TABLE IF EXISTS dbo.WA9085_Invoices;
DROP TABLE IF EXISTS dbo.WA9085_DBs;

SELECT *
INTO dbo.WA9085_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WA9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

SELECT *
INTO dbo.WA9085_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WA9085'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';


/*==============================================================================
|-- 03. SA9200
==============================================================================*/

DROP TABLE IF EXISTS dbo.SA9200_Invoices;
DROP TABLE IF EXISTS dbo.SA9200_DBs;

SELECT *
INTO dbo.SA9200_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'SA9200'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

SELECT *
INTO dbo.SA9200_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'SA9200'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';


/*==============================================================================
|-- 04. WM9263
==============================================================================*/

DROP TABLE IF EXISTS dbo.WM9263_Invoices;
DROP TABLE IF EXISTS dbo.WM9263_DBs;

SELECT *
INTO dbo.WM9263_Invoices
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WM9263'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

SELECT *
INTO dbo.WM9263_DBs
FROM dbo.WallMartSummary_Sheet
WHERE LTRIM(RTRIM(acct)) = 'WM9263'
  AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';


/*==============================================================================
|-- VERIFY CREATED TABLES
==============================================================================*/

SELECT 'WC9085_Invoices' AS Table_Name, COUNT(*) AS Total_Rows
FROM dbo.WC9085_Invoices

UNION ALL

SELECT 'WC9085_DBs', COUNT(*)
FROM dbo.WC9085_DBs

UNION ALL

SELECT 'WA9085_Invoices', COUNT(*)
FROM dbo.WA9085_Invoices

UNION ALL

SELECT 'WA9085_DBs', COUNT(*)
FROM dbo.WA9085_DBs

UNION ALL

SELECT 'SA9200_Invoices', COUNT(*)
FROM dbo.SA9200_Invoices

UNION ALL

SELECT 'SA9200_DBs', COUNT(*)
FROM dbo.SA9200_DBs

UNION ALL

SELECT 'WM9263_Invoices', COUNT(*)
FROM dbo.WM9263_Invoices

UNION ALL

SELECT 'WM9263_DBs', COUNT(*)
FROM dbo.WM9263_DBs;