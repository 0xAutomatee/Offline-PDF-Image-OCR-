===============================================================================
                     WALMART REPORT FULL PROCESS OUTLINE
===============================================================================

STEP 01 — USER UPLOADS WALMART FILE
-----------------------------------

User selects:
    WallMart Accounts

User uploads:
    Walmart inquiry file
    (.xlsx / .xls / .csv)

Application actions:
    1. Reads the uploaded file.
    2. Makes column names SQL-safe.
    3. Keeps the uploaded source data.
    4. Adds basic helper fields where needed.
    5. Uploads the prepared file into SQL Server.

SQL DATABASE:
    WallMartSummary

FIRST SQL TABLE:
    dbo.step_01_inquiry_rows


===============================================================================
STEP 02 — CREATE MAIN WALMART SUMMARY SOURCE
===============================================================================

SQL Procedure:
    dbo.sp_WallMartSummary_db_and_inv_tabels

SOURCE:
    dbo.step_01_inquiry_rows

PROCESS:

    dbo.step_01_inquiry_rows
              |
              |-- Clean / standardize [date]
              |
              |-- Clean / standardize [due_date]
              |
              v
    dbo.WallMartSummary_Sheet

The procedure recreates this table every run:

    DROP old dbo.WallMartSummary_Sheet
    CREATE new dbo.WallMartSummary_Sheet
    COPY data from dbo.step_01_inquiry_rows


===============================================================================
STEP 03 — ADD CALCULATED STATUS COLUMNS
===============================================================================

SQL table:
    dbo.WallMartSummary_Sheet

CALCULATED COLUMN:
    InvYear

RULE:
    InvYear = year taken from [date]

EXAMPLE:
    Date: 08/15/2026
    InvYear: 2026


CALCULATED COLUMN:
    WriteStatus

RULE:
    Used for DB rows.
    If comment starts with a write-up variation:

        Write Up...
        Writeup...
        Write-up...
        Write  Up...
        Write_up...

    and the comment does not contain "approval",

    then:

        WriteStatus = Write-up Sent


CALCULATED COLUMN:
    RetailLinkStatus

RULE:
    If comment contains both:

        No
        Record

    then:

        RetailLinkStatus = NoRetailLink


CALCULATED COLUMN:
    Paid

RULE:
    Used for invoice rows.

    If comment starts with:

        Unpaid...

    then:

        Paid = Unpaid

    If comment starts with:

        Paid...
        Fully paid...

    and does not contain deduction wording,

    then:

        Paid = InvPaid


CALCULATED COLUMN:
    PaidnFullyDeduct

RULE:
    If comment includes both:

        paid
        deduc

    then:

        PaidnFullyDeduct = PaidnDeducted


CALCULATED COLUMN:
    Dispute_Amount

RULE:
    Used for DB rows.

    If comment starts with:

        REDISPUTE OPEN...
        DISPUTE OPEN...

    then:

        Dispute_Amount = Disputed


===============================================================================
STEP 04 — SPLIT DATA BY WALMART ACCOUNT AND DOCUMENT TYPE
===============================================================================

SOURCE:
    dbo.WallMartSummary_Sheet

SPLIT RULE:

    acct + ref_type

DOCUMENT TYPE:

    IN = Invoice
    DB = Debit / Open Deduction


OUTPUT TABLES:

    WC9085
    ------------------------------------------------
    dbo.WC9085_Invoices
    dbo.WC9085_DBs


    WA9085
    ------------------------------------------------
    dbo.WA9085_Invoices
    dbo.WA9085_DBs


    SA9200
    ------------------------------------------------
    dbo.SA9200_Invoices
    dbo.SA9200_DBs


    WM9263
    ------------------------------------------------
    dbo.WM9263_Invoices
    dbo.WM9263_DBs


===============================================================================
STEP 05 — CREATE OPEN AGING DB STATUS REPORT
===============================================================================

SQL Procedure:
    dbo.sp_WallMartSummary_gen_DBs_Status

MAIN SOURCE:
    dbo.WallMartSummary_Sheet

DB ACCOUNT SOURCES:
    dbo.WC9085_DBs
    dbo.WA9085_DBs
    dbo.SA9200_DBs

REPORT PROCESS:

    1. Reads DB rows.
    2. Uses account, reason, pay_day, InvYear,
       Dispute_Amount, and WriteStatus.
    3. Finds all valid years dynamically.
    4. Groups DB rows by:

        Account
        Reason
        InvYear

    5. Calculates totals for every year.
    6. Calculates Total Amount.
    7. Calculates total Dispute_Amount where:

        Dispute_Amount = Disputed

    8. Calculates Write-up Sent where:

        WriteStatus = Write-up Sent

    9. Creates account totals.
   10. Creates all-account total.
   11. Adds report titles, blank rows, headings,
       display order, and technical sort order.


FINAL SQL REPORT TABLE:
    dbo.DBs_Status


DBS STATUS REPORT FORMAT:

    WALMART OPEN AGING (DB'S) STATUS SUMMARY

    Summary
        2022
        2023
        2024
        2025
        2026
        Total Amount
        Dispute_Amount
        Write-up Sent

    All Accounts Total

    WC9085 - WAL-MART CANADA, INC. (Open DB's)
        Reason
        Year columns
        Total Amount
        Dispute_Amount
        Write-up Sent
        ACCOUNT TOTAL

    WA9085 - WAL-MART STORE, INC. (Open DB's)
        Reason
        Year columns
        Total Amount
        Dispute_Amount
        Write-up Sent
        ACCOUNT TOTAL

    SA9200 - SAM'S CLUB (Open DB's)
        Reason
        Year columns
        Total Amount
        Dispute_Amount
        Write-up Sent
        ACCOUNT TOTAL


===============================================================================
STEP 06 — CREATE INVOICE STATUS REPORT
===============================================================================

SQL Procedure:
    dbo.sp_WallMartSummary_Invoice_Status

INVOICE SOURCES:

    dbo.WC9085_Invoices
    dbo.WA9085_Invoices
    dbo.SA9200_Invoices
    dbo.WM9263_Invoices

REPORT PROCESS:

    1. Checks whether each invoice source table exists.
    2. Skips missing tables safely.
    3. Skips source tables with no valid rows.
    4. Combines all valid invoice data.
    5. Finds all available InvYear values dynamically.
    6. Creates year columns dynamically.

       Example:
           2022
           2023
           2024
           2025
           2026

    7. Calculates per-account totals:

       Total Amount
           SUM(pay_day)

       Paid#
           SUM(pay_day)
           where Paid = InvPaid

       Paid & Fully Deduct
           SUM(pay_day)
           where PaidnFullyDeduct = PaidnDeducted

       RetailLinkStatus
           SUM(pay_day)
           where RetailLinkStatus = NoRetailLink

    8. Creates:
       - summary row
       - blank spacing rows
       - account rows
       - final total row


FINAL SQL REPORT TABLE:
    dbo.Invoices_Status


INVOICE STATUS REPORT FORMAT:

    INVOICE STATUS SUMMARY

    Summary
        2022
        2023
        2024
        2025
        2026
        Total Amount
        Paid#
        Paid & Fully Deduct
        RetailLinkStatus

    Total Amount BY YEAR

    WC9085 - WAL-MART CANADA, INC.
    WA9085 - WAL-MART STORE, INC.
    SA9200 - SAM'S CLUB
    WM9263 - WAL-MART STORE #2306

    Total


===============================================================================
STEP 07 — APPLICATION CREATES EXCEL WORKBOOK
===============================================================================

The SQL creates report tables.
The Python application reads those SQL tables.
The Excel formatting is handled by the application.

SQL TABLES USED FOR EXPORT:

    dbo.DBs_Status
    dbo.Invoices_Status
    dbo.WallMartSummary_Sheet
    dbo.WC9085_DBs
    dbo.WC9085_Invoices
    dbo.WA9085_DBs
    dbo.WA9085_Invoices
    dbo.SA9200_DBs
    dbo.SA9200_Invoices
    dbo.WM9263_DBs
    dbo.WM9263_Invoices


EXCEL OUTPUT:

    LATEST_SQL_TABLES.xlsx


EXCEL FORMATTING:

    DBs_Status:
        - report title
        - account section colors
        - summary rows
        - dynamic year columns
        - currency formatting
        - Total Amount column
        - Dispute_Amount column
        - Write-up Sent column

    Invoices_Status:
        - report title
        - account section layout
        - dynamic year columns
        - currency formatting
        - Paid# column
        - Paid & Fully Deduct column
        - RetailLinkStatus display column


===============================================================================
COMPLETE FLOW
===============================================================================

[User Uploads Walmart File]
             |
             v
[Application Reads and Normalizes File]
             |
             v
[dbo.step_01_inquiry_rows]
             |
             v
[dbo.sp_WallMartSummary_db_and_inv_tabels]
             |
             v
[dbo.WallMartSummary_Sheet]
             |
             +---------------------------+
             |                           |
             v                           v
[Invoice Account Tables]            [DB Account Tables]
             |                           |
             v                           v
[sp_WallMartSummary_              [sp_WallMartSummary_
 Invoice_Status]                    gen_DBs_Status]
             |                           |
             v                           v
[dbo.Invoices_Status]              [dbo.DBs_Status]
             |                           |
             +-------------+-------------+
                           |
                           v
          [Application Reads SQL Report Tables]
                           |
                           v
             [Creates Formatted Excel Workbook]
                           |
                           v
                [LATEST_SQL_TABLES.xlsx Download]


===============================================================================
IMPORTANT
===============================================================================

The SQL file does NOT directly read Excel files.

The application is responsible for:

    Upload file
    Normalize columns
    Save data into dbo.step_01_inquiry_rows
    Run SQL procedures
    Read SQL report tables
    Create and download Excel workbook

The SQL is responsible for:

    Transform source rows
    Calculate status columns
    Split invoice and DB account tables
    Build DBs_Status
    Build Invoices_Status
    Calculate all totals and dynamic year columns