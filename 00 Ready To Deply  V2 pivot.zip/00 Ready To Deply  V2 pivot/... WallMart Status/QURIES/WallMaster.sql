USE [WallMartSummary];
GO

/*==============================================================================
|
|  WALMART SUMMARY
|
|  dbo.sp_WallMartSummary_db_and_inv_tabels
|
|  +-- PROJECT
|  |   `-- WALMART SUMMARY
|  |
|  +-- PROCEDURE
|  |   `-- dbo.sp_WallMartSummary_db_and_inv_tabels
|  |
|  +-- VERSION
|  |   `-- V-09
|  |
|  +-- SOURCE
|  |   `-- dbo.step_01_inquiry_rows
|  |
|  +-- MAIN TABLE
|  |   `-- dbo.WallMartSummary_Sheet
|  |
|  +-- OUTPUT TABLES
|  |   +-- dbo.WC9085_Invoices
|  |   +-- dbo.WC9085_DBs
|  |   +-- dbo.WA9085_Invoices
|  |   +-- dbo.WA9085_DBs
|  |   +-- dbo.SA9200_Invoices
|  |   +-- dbo.SA9200_DBs
|  |   +-- dbo.WM9263_Invoices
|  |   `-- dbo.WM9263_DBs
|  |
|  `-- DESCRIPTION
|      `-- Prepare source data and create account-wise invoice and DB tables.
|
==============================================================================*/


/*==============================================================================
|
|  QUERY DIRECTORY
|
|  +-- Q#001  | Validate required source table
|  +-- Q#001A | Update date to US format
|  +-- Q#001B | Update due_date to US format
|  +-- Q#002  | Recreate dbo.WallMartSummary_Sheet
|  +-- Q#003  | Add and populate InvYear
|  +-- Q#004  | Add and populate WriteStatus
|  +-- Q#005A | Add and populate RetailLinkStatus
|  +-- Q#005  | Add and populate Paid
|  +-- Q#006  | Add and populate PaidnFullyDeduct
|  +-- Q#006B | Add and populate Dispute_Amount
|  +-- Q#007  | Create WC9085 invoice and DB tables
|  +-- Q#008  | Create WA9085 invoice and DB tables
|  +-- Q#009  | Create SA9200 invoice and DB tables
|  +-- Q#010  | Create WM9263 invoice and DB tables
|  `-- Q#011  | Verify all created tables
|
==============================================================================*/


CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_db_and_inv_tabels
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @RowsAffected INT = 0,
        @SourceRows   INT = 0;

    BEGIN TRY

        PRINT '============================================================';
        PRINT 'PROJECT       : WALMART SUMMARY';
        PRINT 'PROCEDURE     : dbo.sp_WallMartSummary_db_and_inv_tabels';
        PRINT 'QUERY VERSION : V-09';
        PRINT 'SOURCE TABLE  : dbo.step_01_inquiry_rows';
        PRINT '============================================================';


        /*======================================================================
        |-- Q#001 | SOURCE | Validate required source table
        ======================================================================*/

        RAISERROR(
            'Q#001 started: Validating source table...',
            0,
            1
        ) WITH NOWAIT;

        IF OBJECT_ID(
            'dbo.step_01_inquiry_rows',
            'U'
        ) IS NULL
        BEGIN
            THROW 50001,
                  'Required source table dbo.step_01_inquiry_rows was not found.',
                  1;
        END;

        SELECT
            @SourceRows = COUNT(*)
        FROM dbo.step_01_inquiry_rows;

        PRINT CONCAT(
            'Q#001 completed: Source table found. Rows = ',
            @SourceRows
        );


        /*======================================================================
        |-- Q#001A | SOURCE.DATE | Update date to US format MM/DD/YYYY
        ======================================================================*/

        RAISERROR(
            'Q#001A started: Updating date to US format...',
            0,
            1
        ) WITH NOWAIT;

        UPDATE S
        SET S.[date] =
            CONVERT(
                VARCHAR(10),
                TRY_CONVERT(DATE, S.[date]),
                101
            )
        FROM dbo.step_01_inquiry_rows AS S
        WHERE TRY_CONVERT(DATE, S.[date]) IS NOT NULL;

        SET @RowsAffected = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#001A completed: Date rows updated = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#001B | SOURCE.DUE_DATE | Update due_date to US format MM/DD/YYYY
        ======================================================================*/

        RAISERROR(
            'Q#001B started: Updating due_date to US format...',
            0,
            1
        ) WITH NOWAIT;

        UPDATE S
        SET S.[due_date] =
            CONVERT(
                VARCHAR(10),
                TRY_CONVERT(DATE, S.[due_date]),
                101
            )
        FROM dbo.step_01_inquiry_rows AS S
        WHERE TRY_CONVERT(DATE, S.[due_date]) IS NOT NULL;

        SET @RowsAffected = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#001B completed: Due_Date rows updated = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#002 | WMS | Recreate optimized source table
        ======================================================================*/

        RAISERROR(
            'Q#002 started: Recreating dbo.WallMartSummary_Sheet...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WallMartSummary_Sheet;

        SELECT *
        INTO dbo.WallMartSummary_Sheet
        FROM dbo.step_01_inquiry_rows;

        SET @RowsAffected = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#002 completed: WallMartSummary_Sheet created. Rows = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#003 | WMS.INVYEAR | Add and populate invoice year
        ======================================================================*/

        RAISERROR(
            'Q#003 started: Adding and updating InvYear...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'InvYear'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD InvYear INT NULL;

            PRINT 'Q#003 info: InvYear column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#003 info: InvYear column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
            UPDATE WMS
            SET WMS.InvYear =
                YEAR(
                    TRY_CONVERT(
                        DATETIME,
                        WMS.[date]
                    )
                )
            FROM dbo.WallMartSummary_Sheet AS WMS
            WHERE WMS.[date] IS NOT NULL;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#003 completed: InvYear rows updated = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#004 | WMS.WRITESTATUS | Add and populate write-up status
        ======================================================================*/

        RAISERROR(
            'Q#004 started: Adding and updating WriteStatus...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'WriteStatus'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD WriteStatus VARCHAR(50) NULL;

            PRINT 'Q#004 info: WriteStatus column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#004 info: WriteStatus column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
           UPDATE WMS
SET WMS.WriteStatus =
    CASE
        WHEN
        (
               LTRIM(WMS.comment)
                   COLLATE Latin1_General_100_CI_AI
                   LIKE ''Write Up%''

            OR LTRIM(WMS.comment)
                   COLLATE Latin1_General_100_CI_AI
                   LIKE ''Writeup%''

            OR LTRIM(WMS.comment)
                   COLLATE Latin1_General_100_CI_AI
                   LIKE ''Write-up%''

            OR LTRIM(WMS.comment)
                   COLLATE Latin1_General_100_CI_AI
                   LIKE ''Write  Up%''

            OR LTRIM(WMS.comment)
                   COLLATE Latin1_General_100_CI_AI
                   LIKE ''Write_up%''
        )
        AND WMS.comment
                COLLATE Latin1_General_100_CI_AI
                NOT LIKE ''%approval%''
        THEN ''Write-up Sent''

        ELSE NULL
    END
FROM dbo.WallMartSummary_Sheet AS WMS
WHERE WMS.ref
          COLLATE Latin1_General_100_CI_AI
          LIKE ''DB%'';

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#004 completed: WriteStatus rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#005A | WMS.RETAILLINKSTATUS | Add and populate Retail Link status
        ======================================================================*/

        RAISERROR(
            'Q#005A started: Adding and updating RetailLinkStatus...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'RetailLinkStatus'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD RetailLinkStatus VARCHAR(50) NULL;

            PRINT 'Q#005A info: RetailLinkStatus column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#005A info: RetailLinkStatus column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
            UPDATE WMS
            SET WMS.RetailLinkStatus =
                CASE
                    WHEN WMS.comment
                         COLLATE Latin1_General_100_CI_AI
                         LIKE ''%No%''
                     AND WMS.comment
                         COLLATE Latin1_General_100_CI_AI
                         LIKE ''%Record%''
                        THEN ''NoRetailLink''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#005A completed: RetailLinkStatus rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#005 | WMS.PAID | Add and populate invoice-paid status
        ======================================================================*/

        RAISERROR(
            'Q#005 started: Adding and updating Paid...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'Paid'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD Paid VARCHAR(50) NULL;

            PRINT 'Q#005 info: Paid column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#005 info: Paid column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
            UPDATE WMS
            SET WMS.Paid =
                CASE
                    /*----------------------------------------------------------
                    |-- Unpaid rows
                    ----------------------------------------------------------*/

                    WHEN LTRIM(RTRIM(WMS.[comment]))
                         COLLATE Latin1_General_100_CI_AS
                         LIKE ''Unpaid%''
                        THEN ''Unpaid''

                    /*----------------------------------------------------------
                    |-- Paid rows, excluding deducted comments
                    ----------------------------------------------------------*/

                    WHEN
                    (
                           LTRIM(RTRIM(WMS.[comment]))
                           COLLATE Latin1_General_100_CI_AS
                           LIKE ''Paid%''

                        OR LTRIM(RTRIM(WMS.[comment]))
                           COLLATE Latin1_General_100_CI_AS
                           LIKE ''Fully paid%''
                    )
                    AND LTRIM(RTRIM(WMS.[comment]))
                        COLLATE Latin1_General_100_CI_AS
                        NOT LIKE ''%dedu%''
                    AND LTRIM(RTRIM(WMS.[comment]))
                        COLLATE Latin1_General_100_CI_AS
                        NOT LIKE ''%fully ded%''
                        THEN ''InvPaid''

                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS
            WHERE LTRIM(RTRIM(WMS.[ref]))
                  COLLATE Latin1_General_100_CI_AS
                  LIKE ''IN%'';

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#005 completed: Paid rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#006 | WMS.PAIDNFULLYDEDUCT | Add and populate deducted status
        ======================================================================*/

        RAISERROR(
            'Q#006 started: Adding and updating PaidnFullyDeduct...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'PaidnFullyDeduct'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD PaidnFullyDeduct VARCHAR(50) NULL;

            PRINT 'Q#006 info: PaidnFullyDeduct column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#006 info: PaidnFullyDeduct column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
            UPDATE WMS
            SET WMS.PaidnFullyDeduct =
                CASE
                    WHEN WMS.comment
                         COLLATE Latin1_General_100_CI_AI
                         LIKE ''%paid%''
                     AND WMS.comment
                         COLLATE Latin1_General_100_CI_AI
                         LIKE ''%deduc%''
                        THEN ''PaidnDeducted''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS;

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#006 completed: PaidnFullyDeduct rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#006B | WMS.DISPUTE_AMOUNT | Add and populate dispute status
        ======================================================================*/

        RAISERROR(
            'Q#006B started: Adding and updating Dispute_Amount...',
            0,
            1
        ) WITH NOWAIT;

        IF COL_LENGTH(
            'dbo.WallMartSummary_Sheet',
            'Dispute_Amount'
        ) IS NULL
        BEGIN
            ALTER TABLE dbo.WallMartSummary_Sheet
            ADD Dispute_Amount VARCHAR(50) NULL;

            PRINT 'Q#006B info: Dispute_Amount column added.';
        END
        ELSE
        BEGIN
            PRINT 'Q#006B info: Dispute_Amount column already exists.';
        END;

        EXEC sys.sp_executesql
        N'
            UPDATE WMS
            SET WMS.Dispute_Amount =
                CASE
                    WHEN
                    (
                           LTRIM(WMS.comment)
                           COLLATE Latin1_General_100_CI_AI
                           LIKE ''REDISPUTE OPEN%''

                        OR LTRIM(WMS.comment)
                           COLLATE Latin1_General_100_CI_AI
                           LIKE ''DISPUTE OPEN%''
                    )
                        THEN ''Disputed''
                    ELSE NULL
                END
            FROM dbo.WallMartSummary_Sheet AS WMS
            WHERE LTRIM(RTRIM(WMS.ref))
                  COLLATE Latin1_General_100_CI_AI
                  LIKE ''DB%'';

            SELECT @UpdatedRows = @@ROWCOUNT;
        ',
        N'@UpdatedRows INT OUTPUT',
        @UpdatedRows = @RowsAffected OUTPUT;

        PRINT CONCAT(
            'Q#006B completed: Dispute_Amount rows processed = ',
            @RowsAffected
        );


        /*======================================================================
        |-- Q#007 | WC9085 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#007 started: Creating WC9085 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WC9085_Invoices;
        DROP TABLE IF EXISTS dbo.WC9085_DBs;

        SELECT *
        INTO dbo.WC9085_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WC9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q007_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WC9085_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WC9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q007_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#007 completed: WC9085_Invoices = ',
            @Q007_InvoiceRows,
            ', WC9085_DBs = ',
            @Q007_DBRows
        );


        /*======================================================================
        |-- Q#008 | WA9085 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#008 started: Creating WA9085 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WA9085_Invoices;
        DROP TABLE IF EXISTS dbo.WA9085_DBs;

        SELECT *
        INTO dbo.WA9085_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WA9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q008_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WA9085_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WA9085'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q008_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#008 completed: WA9085_Invoices = ',
            @Q008_InvoiceRows,
            ', WA9085_DBs = ',
            @Q008_DBRows
        );


        /*======================================================================
        |-- Q#009 | SA9200 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#009 started: Creating SA9200 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.SA9200_Invoices;
        DROP TABLE IF EXISTS dbo.SA9200_DBs;

        SELECT *
        INTO dbo.SA9200_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'SA9200'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q009_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.SA9200_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'SA9200'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q009_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#009 completed: SA9200_Invoices = ',
            @Q009_InvoiceRows,
            ', SA9200_DBs = ',
            @Q009_DBRows
        );


        /*======================================================================
        |-- Q#010 | WM9263 | Create invoice and DB tables
        ======================================================================*/

        RAISERROR(
            'Q#010 started: Creating WM9263 tables...',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS dbo.WM9263_Invoices;
        DROP TABLE IF EXISTS dbo.WM9263_DBs;

        SELECT *
        INTO dbo.WM9263_Invoices
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WM9263'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'IN';

        DECLARE @Q010_InvoiceRows INT = @@ROWCOUNT;

        SELECT *
        INTO dbo.WM9263_DBs
        FROM dbo.WallMartSummary_Sheet
        WHERE LTRIM(RTRIM(acct)) = 'WM9263'
          AND UPPER(LTRIM(RTRIM(ref_type))) = 'DB';

        DECLARE @Q010_DBRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#010 completed: WM9263_Invoices = ',
            @Q010_InvoiceRows,
            ', WM9263_DBs = ',
            @Q010_DBRows
        );


        /*======================================================================
        |-- Q#011 | ALL TABLES | Verify table names and row counts
        ======================================================================*/

        RAISERROR(
            'Q#011 started: Verifying account tables...',
            0,
            1
        ) WITH NOWAIT;

        SELECT
            V.Table_Name,
            V.Total_Rows
        FROM
        (
            SELECT
                1 AS Table_Order,
                'WC9085_Invoices' AS Table_Name,
                COUNT(*) AS Total_Rows
            FROM dbo.WC9085_Invoices

            UNION ALL

            SELECT
                2,
                'WC9085_DBs',
                COUNT(*)
            FROM dbo.WC9085_DBs

            UNION ALL

            SELECT
                3,
                'WA9085_Invoices',
                COUNT(*)
            FROM dbo.WA9085_Invoices

            UNION ALL

            SELECT
                4,
                'WA9085_DBs',
                COUNT(*)
            FROM dbo.WA9085_DBs

            UNION ALL

            SELECT
                5,
                'SA9200_Invoices',
                COUNT(*)
            FROM dbo.SA9200_Invoices

            UNION ALL

            SELECT
                6,
                'SA9200_DBs',
                COUNT(*)
            FROM dbo.SA9200_DBs

            UNION ALL

            SELECT
                7,
                'WM9263_Invoices',
                COUNT(*)
            FROM dbo.WM9263_Invoices

            UNION ALL

            SELECT
                8,
                'WM9263_DBs',
                COUNT(*)
            FROM dbo.WM9263_DBs
        ) AS V
        ORDER BY V.Table_Order;

        PRINT 'Q#011 completed: All account tables verified.';

        PRINT '============================================================';
        PRINT 'PROCEDURE COMPLETED SUCCESSFULLY';
        PRINT '============================================================';

    END TRY
    BEGIN CATCH

        DECLARE
            @ErrorNumber    INT            = ERROR_NUMBER(),
            @ErrorLine      INT            = ERROR_LINE(),
            @ErrorProcedure NVARCHAR(256)  = ERROR_PROCEDURE(),
            @ErrorMessage   NVARCHAR(4000) = ERROR_MESSAGE();

        PRINT '============================================================';
        PRINT 'PROCEDURE FAILED';
        PRINT CONCAT(
            'ERROR NUMBER    : ',
            @ErrorNumber
        );
        PRINT CONCAT(
            'ERROR PROCEDURE : ',
            COALESCE(@ErrorProcedure, 'N/A')
        );
        PRINT CONCAT(
            'ERROR LINE      : ',
            @ErrorLine
        );
        PRINT CONCAT(
            'ERROR MESSAGE   : ',
            @ErrorMessage
        );
        PRINT '============================================================';

        THROW;

    END CATCH;
END;
GO


/*==============================================================================
|
|  EXECUTION
|
|  dbo.sp_WallMartSummary_db_and_inv_tabels
|  `-- Execute procedure
|
==============================================================================*/

-- EXEC dbo.sp_WallMartSummary_db_and_inv_tabels;
GO






--   >>>>>>>>>>>>>>>>>>>>>           22222222222222222222222222



USE [WallMartSummary]
GO
/****** Object:  StoredProcedure [dbo].[sp_WallMartSummary_gen_DBs_Status]    Script Date: 8/24/2026 8:52:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*==============================================================================
|-- STEP 02
|   `-- CREATE V-15 PROCEDURE
==============================================================================*/

ALTER PROCEDURE [dbo].[sp_WallMartSummary_gen_DBs_Status]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY

        /*======================================================================
        |-- Q#01
        |   `-- START PROCEDURE
        ======================================================================*/

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

        RAISERROR('PROJECT       : WALLMART SUMMARY', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'PROCEDURE     : dbo.sp_WallMartSummary_gen_DBs_Status',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('QUERY VERSION : V-15', 0, 1)
        WITH NOWAIT;

        RAISERROR('SOURCE TABLE  : dbo.WallMartSummary_Sheet', 0, 1)
        WITH NOWAIT;

        RAISERROR('TARGET TABLE  : dbo.DBs_Status', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'DISPUTE RULE  : SUM(pay_day) WHERE Dispute_Amount LIKE %%Disputed%%',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'WRITE-UP RULE : SUM(pay_day) WHERE WriteStatus LIKE %%Write-up Sent%%',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;


        /*======================================================================
        |-- Q#02
        |   `-- VALIDATE SOURCE TABLE
        ======================================================================*/

        IF OBJECT_ID('dbo.WallMartSummary_Sheet', 'U') IS NULL
        BEGIN
            THROW 50001,
                  'Required table dbo.WallMartSummary_Sheet was not found.',
                  1;
        END;

        RAISERROR(
            'Q#02 completed: Source table found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#03
        |   `-- VALIDATE REQUIRED SOURCE COLUMNS
        ======================================================================*/

        DECLARE @MissingColumns NVARCHAR(MAX);
        DECLARE @ErrorMessage   NVARCHAR(2048);

        ;WITH RequiredColumns AS
        (
            SELECT Column_Name
            FROM
            (
                VALUES
                    ('acct'),
                    ('order'),
                    ('InvYear'),
                    ('pay_day'),
                    ('ref_type'),
                    ('WriteStatus'),
                    ('Dispute_Amount')
            ) AS C(Column_Name)
        )
        SELECT
            @MissingColumns =
                STRING_AGG
                (
                    QUOTENAME(R.Column_Name),
                    ', '
                )
        FROM RequiredColumns AS R
        WHERE COL_LENGTH
              (
                  'dbo.WallMartSummary_Sheet',
                  R.Column_Name
              ) IS NULL;

        IF @MissingColumns IS NOT NULL
        BEGIN
            SET @ErrorMessage =
                N'Missing columns in dbo.WallMartSummary_Sheet: '
                + @MissingColumns;

            THROW 50002,
                  @ErrorMessage,
                  1;
        END;

        RAISERROR(
            'Q#03 completed: Required source columns found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#04
        |   `-- PREPARE ACCOUNT SETTINGS
        ======================================================================*/

        DROP TABLE IF EXISTS #Accounts;

        CREATE TABLE #Accounts
        (
            Account_Order INT           NOT NULL,
            Account_Code  NVARCHAR(50)  NOT NULL,
            Account_Title NVARCHAR(300) NOT NULL
        );

        INSERT INTO #Accounts
        (
            Account_Order,
            Account_Code,
            Account_Title
        )
        VALUES
            (
                1,
                N'WC9085',
                N'WC9085 - WAL-MART CANADA, INC. (Open DB''s)'
            ),
            (
                2,
                N'WA9085',
                N'WA9085 - WAL-MART STORE, INC. (Open DB''s)'
            ),
            (
                3,
                N'SA9200',
                N'SA9200 - SAM''S CLUB (Open DB''s)'
            );

        PRINT CONCAT(
            'Q#04 completed: Account settings inserted = ',
            @@ROWCOUNT
        );


        /*======================================================================
        |-- Q#05
        |   `-- PREPARE CLEAN SOURCE DATA
        ======================================================================*/

        DROP TABLE IF EXISTS #DB_Source;

        SELECT
            A.Account_Order,
            A.Account_Code,
            A.Account_Title,

            Reason =
                COALESCE
                (
                    NULLIF
                    (
                        LTRIM(RTRIM(CONVERT(NVARCHAR(300), S.[order]))),
                        ''
                    ),
                    N'NO REASON'
                ),

            InvYear =
                TRY_CONVERT
                (
                    INT,
                    S.InvYear
                ),

            Amount =
                V.CleanAmount,

            DisputeAmount =
                CASE
                    WHEN S.Dispute_Amount IS NOT NULL
                     AND LTRIM
                         (
                             RTRIM
                             (
                                 CONVERT
                                 (
                                     NVARCHAR(4000),
                                     S.Dispute_Amount
                                 )
                             )
                         ) LIKE N'%Disputed%'
                        THEN V.CleanAmount
                    ELSE CAST(0.00 AS DECIMAL(18,2))
                END,

            WriteUpSent =
                CASE
                    WHEN S.WriteStatus IS NOT NULL
                     AND LTRIM
                         (
                             RTRIM
                             (
                                 CONVERT
                                 (
                                     NVARCHAR(4000),
                                     S.WriteStatus
                                 )
                             )
                         ) LIKE N'%Write-up Sent%'
                        THEN V.CleanAmount
                    ELSE CAST(0.00 AS DECIMAL(18,2))
                END

        INTO #DB_Source

        FROM dbo.WallMartSummary_Sheet AS S

        INNER JOIN #Accounts AS A
            ON A.Account_Code =
               LTRIM
               (
                   RTRIM
                   (
                       CONVERT
                       (
                           NVARCHAR(50),
                           S.acct
                       )
                   )
               )

        CROSS APPLY
        (
            SELECT
                CleanAmount =
                    ISNULL
                    (
                        TRY_CONVERT
                        (
                            DECIMAL(18,2),

                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE
                                        (
                                            LTRIM
                                            (
                                                RTRIM
                                                (
                                                    CONVERT
                                                    (
                                                        NVARCHAR(100),
                                                        S.pay_day
                                                    )
                                                )
                                            ),
                                            '$',
                                            ''
                                        ),
                                        ',',
                                        ''
                                    ),
                                    '(',
                                    '-'
                                ),
                                ')',
                                ''
                            )
                        ),
                        0.00
                    )
        ) AS V

        WHERE UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          CONVERT
                          (
                              NVARCHAR(50),
                              S.ref_type
                          )
                      )
                  )
              ) = 'DB'

          AND TRY_CONVERT(INT, S.InvYear) IS NOT NULL

          AND S.[order] IS NOT NULL

          AND LTRIM
              (
                  RTRIM
                  (
                      CONVERT
                      (
                          NVARCHAR(300),
                          S.[order]
                      )
                  )
              ) <> '';

        DECLARE @SourceRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#05 completed: Clean source rows = ',
            @SourceRows
        );


        /*======================================================================
        |-- Q#06
        |   `-- VALIDATE CLEAN SOURCE DATA WITHOUT STOPPING PROCEDURE
        ======================================================================*/

        DECLARE @HasValidDBSource BIT = 0;

        IF EXISTS
        (
            SELECT 1
            FROM #DB_Source
        )
        BEGIN
            SET @HasValidDBSource = 1;

            RAISERROR(
                'Q#06 completed: Valid DB source data found.',
                0,
                1
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN
            SET @HasValidDBSource = 0;

            RAISERROR(
                'Q#06 skipped: No valid DB source rows were found.',
                10,
                1
            ) WITH NOWAIT;

            RAISERROR(
                'Q#06 info: dbo.DBs_Status generation skipped; procedure will continue.',
                10,
                1
            ) WITH NOWAIT;
        END;


        /*======================================================================
        |-- Q#06B
        |   `-- RUN DB REPORT ONLY WHEN VALID DB SOURCE EXISTS
        ======================================================================*/

        IF @HasValidDBSource = 1
        BEGIN


        /*======================================================================
        |-- Q#07
        |   `-- PREVIEW WRITE-UP SOURCE DATA
        ======================================================================*/

        SELECT
            Account_Code,
            Reason,
            InvYear,

            Total_Amount =
                CAST
                (
                    SUM(Amount)
                    AS DECIMAL(18,2)
                ),

            [Dispute_Amount] =
                CAST
                (
                    SUM(DisputeAmount)
                    AS DECIMAL(18,2)
                ),

            [Write-up Sent] =
                CAST
                (
                    SUM(WriteUpSent)
                    AS DECIMAL(18,2)
                )

        FROM #DB_Source

        GROUP BY
            Account_Code,
            Reason,
            InvYear

        ORDER BY
            Account_Code,
            Reason,
            InvYear;

        RAISERROR(
            'Q#07 completed: Amount and Write-up preview generated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#08
        |   `-- DECLARE DYNAMIC VARIABLES
        ======================================================================*/

        DECLARE @CreateYearColumns     NVARCHAR(MAX);
        DECLARE @SelectYearColumns     NVARCHAR(MAX);
        DECLARE @HeaderYearValues      NVARCHAR(MAX);
        DECLARE @NullYearValues        NVARCHAR(MAX);
        DECLARE @ReasonSummaryColumns  NVARCHAR(MAX);
        DECLARE @ReasonYearValues      NVARCHAR(MAX);
        DECLARE @TotalYearValues       NVARCHAR(MAX);

        DECLARE @CreateTableSQL        NVARCHAR(MAX);
        DECLARE @ReportSQL             NVARCHAR(MAX);
        DECLARE @DisplaySQL            NVARCHAR(MAX);


        /*======================================================================
        |-- Q#09
        |   `-- BUILD DYNAMIC YEAR DEFINITIONS
        ======================================================================*/

        SELECT
            @CreateYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        + N' NVARCHAR(100) NULL'
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;

        PRINT CONCAT(
            'Q#09 completed: Dynamic year definitions = ',
            @CreateYearColumns
        );


        /*======================================================================
        |-- Q#10
        |   `-- BUILD DYNAMIC YEAR COLUMN LIST
        ======================================================================*/

        SELECT
            @SelectYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;

        PRINT CONCAT(
            'Q#10 completed: Dynamic year columns = ',
            @SelectYearColumns
        );


        /*======================================================================
        |-- Q#11
        |   `-- BUILD DYNAMIC HEADER VALUES
        ======================================================================*/

        SELECT
            @HeaderYearValues =
                STRING_AGG
                (
                    CAST
                    (
                        N'N'''
                        + CONVERT(NVARCHAR(10), Y.InvYear)
                        + N''''
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#12
        |   `-- BUILD DYNAMIC NULL VALUES
        ======================================================================*/

        SELECT
            @NullYearValues =
                STRING_AGG
                (
                    CAST
                    (
                        N'NULL'
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#13
        |   `-- BUILD DYNAMIC REASON/YEAR SUM EXPRESSIONS
        ======================================================================*/

        SELECT
            @ReasonSummaryColumns =
                STRING_AGG
                (
                    CAST
                    (
                          N'SUM(CASE WHEN InvYear = '
                        + CONVERT(NVARCHAR(10), Y.InvYear)
                        + N' THEN Amount ELSE 0.00 END) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#14
        |   `-- BUILD DYNAMIC REASON YEAR VALUES
        ======================================================================*/

        SELECT
            @ReasonYearValues =
                STRING_AGG
                (
                    CAST
                    (
                          N'CONVERT(NVARCHAR(100), '
                        + N'CAST(ISNULL(R.'
                        + QUOTENAME(Y.InvYear)
                        + N', 0.00) AS DECIMAL(18,2)))'

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#15
        |   `-- BUILD DYNAMIC TOTAL YEAR VALUES
        ======================================================================*/

        SELECT
            @TotalYearValues =
                STRING_AGG
                (
                    CAST
                    (
                          N'CONVERT(NVARCHAR(100), '
                        + N'CAST(ISNULL(SUM(R.'
                        + QUOTENAME(Y.InvYear)
                        + N'), 0.00) AS DECIMAL(18,2)))'

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#16
        |   `-- VALIDATE DYNAMIC VALUES
        ======================================================================*/

        IF NULLIF(@CreateYearColumns, '') IS NULL
           OR NULLIF(@SelectYearColumns, '') IS NULL
           OR NULLIF(@HeaderYearValues, '') IS NULL
           OR NULLIF(@NullYearValues, '') IS NULL
           OR NULLIF(@ReasonSummaryColumns, '') IS NULL
           OR NULLIF(@ReasonYearValues, '') IS NULL
           OR NULLIF(@TotalYearValues, '') IS NULL
        BEGIN
            THROW 50004,
                  'Dynamic InvYear columns could not be generated.',
                  1;
        END;

        RAISERROR(
            'Q#16 completed: Dynamic expressions validated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#17
        |   `-- RECREATE TARGET TABLE IN SEPARATE BATCH
        ======================================================================*/

        SET @CreateTableSQL = N'
        DROP TABLE IF EXISTS dbo.DBs_Status;

        CREATE TABLE dbo.DBs_Status
        (
            Report_Order      INT            NOT NULL,
            Account_Order     INT            NOT NULL,
            Detail_Order      INT            NOT NULL,
            Row_Type          NVARCHAR(50)   NOT NULL,
            Account_Code      NVARCHAR(50)   NULL,
            [Report Line]     NVARCHAR(300)  NULL,

            ' + @CreateYearColumns + N',

            [Total Amount]    NVARCHAR(100)  NULL,
            [Dispute_Amount]  NVARCHAR(100)  NULL,
            [Write-up Sent]   NVARCHAR(100)  NULL
        );

        CREATE NONCLUSTERED INDEX IX_DBs_Status_ReportOrder
        ON dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order
        );
        ';

        RAISERROR(
            'Q#17 started: Recreating dbo.DBs_Status...',
            0,
            1
        ) WITH NOWAIT;

        EXEC sys.sp_executesql @CreateTableSQL;

        RAISERROR(
            'Q#17 completed: dbo.DBs_Status recreated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#18
        |   `-- BUILD AND INSERT COMPLETE REPORT
        ======================================================================*/

        SET @ReportSQL = N'

        /*======================================================================
        |-- DQ#01
        |   `-- CREATE REUSABLE REASON SUMMARY
        ======================================================================*/

        DROP TABLE IF EXISTS #ReasonSummary;

        SELECT
            Account_Order,
            Account_Code,
            Account_Title,
            Reason,

            ' + @ReasonSummaryColumns + N',

            [Total Amount] =
                SUM(Amount),

            [Dispute_Amount] =
                SUM(DisputeAmount),

            [Write-up Sent] =
                SUM(WriteUpSent)

        INTO #ReasonSummary

        FROM #DB_Source

        GROUP BY
            Account_Order,
            Account_Code,
            Account_Title,
            Reason;


        /*======================================================================
        |-- DQ#02
        |   `-- INSERT REPORT TITLE
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        VALUES
        (
            10,
            0,
            0,
            N''REPORT TITLE'',
            NULL,
            N''WALMART OPEN AGING (DB''''S) STATUS SUMMARY'',
            ' + @NullYearValues + N',
            NULL,
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#03
        |   `-- TWO NULL ROWS AFTER REPORT TITLE
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        VALUES
        (
            11,
            0,
            1,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL,
            NULL
        ),
        (
            12,
            0,
            2,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#04
        |   `-- INSERT SUMMARY HEADER
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        VALUES
        (
            20,
            0,
            0,
            N''COLUMN HEADER'',
            NULL,
            N''Summary'',
            ' + @HeaderYearValues + N',
            N''Total Amount'',
            N''Dispute_Amount'',
            N''Write-up Sent''
        );


        /*======================================================================
        |-- DQ#05
        |   `-- INSERT ALL ACCOUNTS TOTAL
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            21,
            0,
            0,
            N''ALL ACCOUNTS TOTAL'',
            NULL,
            N''All Accounts Total'',

            ' + @TotalYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Total Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Dispute_Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Write-up Sent]), 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R;


        /*======================================================================
        |-- DQ#06
        |   `-- TWO NULL ROWS AFTER ALL ACCOUNTS TOTAL
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        VALUES
        (
            22,
            0,
            1,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL,
            NULL
        ),
        (
            23,
            0,
            2,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#07
        |   `-- INSERT ACCOUNT TITLES
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            A.Account_Order * 100,
            A.Account_Order,
            0,
            N''ACCOUNT TITLE'',
            A.Account_Code,
            A.Account_Title,

            ' + @NullYearValues + N',

            NULL,
            NULL,
            NULL

        FROM #Accounts AS A;


        /*======================================================================
        |-- DQ#08
        |   `-- INSERT ACCOUNT COLUMN HEADERS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            (A.Account_Order * 100) + 1,
            A.Account_Order,
            1,
            N''COLUMN HEADER'',
            A.Account_Code,
            N''Reason'',

            ' + @HeaderYearValues + N',

            N''Total Amount'',
            N''Dispute_Amount'',
            N''Write-up Sent''

        FROM #Accounts AS A;


        /*======================================================================
        |-- DQ#09
        |   `-- INSERT REASON ROWS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            (R.Account_Order * 100) + 2,

            R.Account_Order,

            ROW_NUMBER() OVER
            (
                PARTITION BY R.Account_Order
                ORDER BY R.Reason
            ) + 1,

            N''REASON'',
            R.Account_Code,
            R.Reason,

            ' + @ReasonYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(R.[Total Amount], 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(R.[Dispute_Amount], 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(R.[Write-up Sent], 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R;


        /*======================================================================
        |-- DQ#10
        |   `-- INSERT ACCOUNT TOTALS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            (R.Account_Order * 100) + 90,
            R.Account_Order,
            999990,
            N''ACCOUNT TOTAL'',
            R.Account_Code,
            N''ACCOUNT TOTAL'',

            ' + @TotalYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Total Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Dispute_Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Write-up Sent]), 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R

        GROUP BY
            R.Account_Order,
            R.Account_Code;


        /*======================================================================
        |-- DQ#11
        |   `-- TWO NULL ROWS AFTER EACH ACCOUNT
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Dispute_Amount],
            [Write-up Sent]
        )
        SELECT
            (A.Account_Order * 100) + 91,
            A.Account_Order,
            999991,
            N''BLANK ROW'',
            A.Account_Code,
            NULL,

            ' + @NullYearValues + N',

            NULL,
            NULL,
            NULL

        FROM #Accounts AS A

        UNION ALL

        SELECT
            (A.Account_Order * 100) + 92,
            A.Account_Order,
            999992,
            N''BLANK ROW'',
            A.Account_Code,
            NULL,

            ' + @NullYearValues + N',

            NULL,
            NULL,
            NULL

        FROM #Accounts AS A;
        ';

        RAISERROR(
            'Q#18 started: Inserting report and Write-up values...',
            0,
            1
        ) WITH NOWAIT;

        EXEC sys.sp_executesql @ReportSQL;

        RAISERROR(
            'Q#18 completed: Report rows inserted.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#19
        |   `-- COUNT SAVED ROWS
        ======================================================================*/

        DECLARE @SavedRows INT;

        SELECT
            @SavedRows =
                COUNT(*)
        FROM dbo.DBs_Status;

        PRINT CONCAT(
            'Q#19 completed: dbo.DBs_Status saved rows = ',
            @SavedRows
        );


/*======================================================================
|-- Q#20
|   `-- SAVE FINAL ORDERED REPORT INTO dbo.DBs_Status
======================================================================*/

RAISERROR(
    'Q#20 started: Saving final ordered report into dbo.DBs_Status...',
    0,
    1
) WITH NOWAIT;


/*======================================================================
|-- Q#20.01
|   `-- SAVE TECHNICAL REPORT INTO dbo.DBs_Status_All
======================================================================*/

SET @DisplaySQL = N'
DROP TABLE IF EXISTS dbo.DBs_Status_All;

SELECT
    Report_Order,
    Account_Order,
    Detail_Order,
    Row_Type,
    Account_Code,
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Dispute_Amount],
    [Write-up Sent]

INTO dbo.DBs_Status_All

FROM dbo.DBs_Status;

CREATE CLUSTERED INDEX CX_DBs_Status_All_ReportOrder
ON dbo.DBs_Status_All
(
    Report_Order,
    Account_Order,
    Detail_Order
);
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.02
|   `-- DROP OLD FINAL DISPLAY TABLE
======================================================================*/

SET @DisplaySQL = N'
DROP TABLE IF EXISTS dbo.DBs_Status;
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.03
|   `-- CREATE FINAL CLEAN REPORT TABLE
======================================================================*/

SET @DisplaySQL = N'
CREATE TABLE dbo.DBs_Status
(
    Report_Sequence  INT            NOT NULL,
    [Report Line]    NVARCHAR(300)  NULL,

    ' + @CreateYearColumns + N',

    [Total Amount]   NVARCHAR(100)  NULL,
    [Dispute_Amount] NVARCHAR(100)  NULL,
    [Write-up Sent]  NVARCHAR(100)  NULL,

    CONSTRAINT PK_DBs_Status
        PRIMARY KEY CLUSTERED
        (
            Report_Sequence
        )
);
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.04
|   `-- INSERT REPORT IN REQUIRED SEQUENCE
======================================================================*/

SET @DisplaySQL = N'
INSERT INTO dbo.DBs_Status
(
    Report_Sequence,
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Dispute_Amount],
    [Write-up Sent]
)
SELECT
    Report_Sequence =
        ROW_NUMBER() OVER
        (
            ORDER BY
                Report_Order,
                Account_Order,
                Detail_Order
        ),

    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Dispute_Amount],
    [Write-up Sent]

FROM dbo.DBs_Status_All;
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.05
|   `-- COUNT FINAL SAVED ROWS
======================================================================*/

DECLARE @FinalDBsStatusRows INT;

SELECT
    @FinalDBsStatusRows = COUNT(*)
FROM dbo.DBs_Status;

PRINT CONCAT(
    'Q#20 info: Final dbo.DBs_Status rows = ',
    @FinalDBsStatusRows
);


/*======================================================================
|-- Q#20.06
|   `-- DISPLAY FINAL CLEAN REPORT
======================================================================*/

SET @DisplaySQL = N'
SELECT
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Dispute_Amount],
    [Write-up Sent]

FROM dbo.DBs_Status

ORDER BY
    Report_Sequence;
';

EXEC sys.sp_executesql @DisplaySQL;

RAISERROR(
    'Q#20 completed: Final ordered report saved in dbo.DBs_Status.',
    0,
    1
) WITH NOWAIT;

        END
        ELSE
        BEGIN
            RAISERROR(
                'Q#06B skipped: DB report tables were not generated because no valid DB source data was found.',
                10,
                1
            ) WITH NOWAIT;
        END;


        /*======================================================================
        |-- Q#21
        |   `-- COMPLETE PROCEDURE
        ======================================================================*/

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'V-15 completed successfully.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Dispute_Amount calculated from Dispute_Amount status.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Write-up Sent calculated from WriteStatus.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Technical and dynamic year columns saved in dbo.DBs_Status.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

    END TRY

    BEGIN CATCH

        DECLARE @CatchErrorNumber    INT;
        DECLARE @CatchErrorSeverity  INT;
        DECLARE @CatchErrorState     INT;
        DECLARE @CatchErrorLine      INT;
        DECLARE @CatchErrorProcedure NVARCHAR(300);
        DECLARE @CatchErrorMessage   NVARCHAR(4000);

        SET @CatchErrorNumber =
            ERROR_NUMBER();

        SET @CatchErrorSeverity =
            ERROR_SEVERITY();

        SET @CatchErrorState =
            ERROR_STATE();

        SET @CatchErrorLine =
            ERROR_LINE();

        SET @CatchErrorProcedure =
            ERROR_PROCEDURE();

        SET @CatchErrorMessage =
            ERROR_MESSAGE();

        PRINT '============================================================';
        PRINT 'V-15 DBs_Status generation failed.';

        PRINT CONCAT(
            'Error Number    : ',
            @CatchErrorNumber
        );

        PRINT CONCAT(
            'Error Severity  : ',
            @CatchErrorSeverity
        );

        PRINT CONCAT(
            'Error State     : ',
            @CatchErrorState
        );

        PRINT CONCAT(
            'Error Procedure : ',
            ISNULL(@CatchErrorProcedure, 'Dynamic SQL')
        );

        PRINT CONCAT(
            'Error Line      : ',
            @CatchErrorLine
        );

        PRINT CONCAT(
            'Error Message   : ',
            @CatchErrorMessage
        );

        PRINT '============================================================';

        THROW;

    END CATCH;
END;




--->>>>>>>>>>>>>>>>>>>>   33333333333333333333333333333333









USE [WallMartSummary]
GO
/****** Object:  StoredProcedure [dbo].[sp_WallMartSummary_Invoice_Status]    Script Date: 8/24/2026 8:52:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALMART SUMMARY V-06
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_Invoice_Status
|
|  OUTPUT TABLE
|  `-- dbo.Invoices_Status
|
|  SOURCE HANDLING
|  |-- Missing table          : Print and skip
|  |-- Missing source column  : Print and skip
|  |-- No valid source rows   : Print and skip
|  `-- No valid sources at all: Print and stop without error
|
|  DYNAMIC YEAR COLUMNS
|  `-- Generated from valid InvYear values in available source tables
|
==============================================================================*/

ALTER   PROCEDURE [dbo].[sp_WallMartSummary_Invoice_Status]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @SchemaName            SYSNAME,
        @TableName             SYSNAME,
        @FullTableName         NVARCHAR(517),
        @AccountCode           VARCHAR(20),
        @AccountName           VARCHAR(255),
        @SortOrder             INT,
        @MissingColumns        NVARCHAR(MAX),
        @YearDefinitions       NVARCHAR(MAX),
        @YearColumnList        NVARCHAR(MAX),
        @YearNullList          NVARCHAR(MAX),
        @YearAmountExpressions NVARCHAR(MAX),
        @YearTotalExpressions  NVARCHAR(MAX),
        @SQL                   NVARCHAR(MAX),
        @RowsAffected          INT = 0,
        @SourceRows            INT = 0,
        @ValidSourceCount      INT = 0;


    /*==========================================================================
    |-- Q#01 | START MESSAGE
    ==========================================================================*/

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROJECT       : WALMART SUMMARY',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROCEDURE     : dbo.sp_WallMartSummary_Invoice_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'TARGET TABLE  : dbo.Invoices_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'QUERY VERSION : V-06',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#02 | CREATE SOURCE CONFIGURATION
    ==========================================================================*/

    DROP TABLE IF EXISTS #SourceConfig;

    CREATE TABLE #SourceConfig
    (
        SortOrder   INT          NOT NULL,
        SchemaName  SYSNAME      NOT NULL,
        TableName   SYSNAME      NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );

    INSERT INTO #SourceConfig
    (
        SortOrder,
        SchemaName,
        TableName,
        AccountCode,
        AccountName
    )
    VALUES
        (
            4,
            N'dbo',
            N'WC9085_Invoices',
            'WC9085',
            'WC9085 (WAL-MART CANADA, INC.)'
        ),
        (
            5,
            N'dbo',
            N'WA9085_Invoices',
            'WA9085',
            'WA9085 (WAL-MART STORE, INC.)'
        ),
        (
            6,
            N'dbo',
            N'SA9200_Invoices',
            'SA9200',
            'SA9200 (SAM''S CLUB)'
        ),
        (
            7,
            N'dbo',
            N'WM9263_Invoices',
            'WM9263',
            'WM9263 (WAL-MART STORE #2306)'
        );

    RAISERROR(
        'Q#02 completed: Source configuration created.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#03 | CREATE VALID ACCOUNT LIST
    ==========================================================================*/

    DROP TABLE IF EXISTS #Accounts;

    CREATE TABLE #Accounts
    (
        SortOrder   INT          NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );


    /*==========================================================================
    |-- Q#04 | CREATE COMBINED SOURCE TABLE
    ==========================================================================*/

    DROP TABLE IF EXISTS #AllInvoiceData;

    CREATE TABLE #AllInvoiceData
    (
        SortOrder          INT           NOT NULL,
        AccountCode        VARCHAR(20)   NOT NULL,
        AccountName        VARCHAR(255)  NOT NULL,
        InvYear            INT           NULL,
        PAY_DAY            DECIMAL(38,2) NULL,
        Paid               NVARCHAR(255) NULL,
        PaidnFullyDeduct   NVARCHAR(255) NULL,
        RetailLinkStatus   NVARCHAR(255) NULL
    );


    /*==========================================================================
    |-- Q#05 | CHECK AND LOAD EACH SOURCE TABLE
    ==========================================================================*/

    DECLARE SourceCursor CURSOR LOCAL FAST_FORWARD
    FOR
        SELECT
            SchemaName,
            TableName,
            AccountCode,
            AccountName,
            SortOrder
        FROM #SourceConfig
        ORDER BY SortOrder;

    OPEN SourceCursor;

    FETCH NEXT FROM SourceCursor
    INTO
        @SchemaName,
        @TableName,
        @AccountCode,
        @AccountName,
        @SortOrder;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @FullTableName =
            QUOTENAME(@SchemaName)
            + N'.'
            + QUOTENAME(@TableName);

        SET @MissingColumns = N'';
        SET @SourceRows = 0;


        /*----------------------------------------------------------------------
        |-- TABLE NOT FOUND: PRINT AND SKIP
        ----------------------------------------------------------------------*/

        IF OBJECT_ID(@FullTableName, N'U') IS NULL
        BEGIN
            RAISERROR(
                'Q#05 skipped: Table %s not found.',
                0,
                1,
                @FullTableName
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN

            /*------------------------------------------------------------------
            |-- CHECK REQUIRED COLUMNS
            ------------------------------------------------------------------*/

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'InvYear'
            ) IS NULL
                SET @MissingColumns += N'InvYear; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PAY_DAY'
            ) IS NULL
                SET @MissingColumns += N'PAY_DAY; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'Paid'
            ) IS NULL
                SET @MissingColumns += N'Paid; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PaidnFullyDeduct'
            ) IS NULL
                SET @MissingColumns += N'PaidnFullyDeduct; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'RetailLinkStatus'
            ) IS NULL
                SET @MissingColumns += N'RetailLinkStatus; ';


            /*------------------------------------------------------------------
            |-- REQUIRED COLUMN MISSING: PRINT AND SKIP
            ------------------------------------------------------------------*/

            IF @MissingColumns <> N''
            BEGIN
                RAISERROR(
                    'Q#05 skipped: %s missing column(s): %s',
                    0,
                    1,
                    @FullTableName,
                    @MissingColumns
                ) WITH NOWAIT;
            END
            ELSE
            BEGIN

                /*--------------------------------------------------------------
                |-- LOAD VALID SOURCE ROWS
                --------------------------------------------------------------*/

                SET @SQL = N'
                    INSERT INTO #AllInvoiceData
                    (
                        SortOrder,
                        AccountCode,
                        AccountName,
                        InvYear,
                        PAY_DAY,
                        Paid,
                        PaidnFullyDeduct,
                        RetailLinkStatus
                    )
                    SELECT
                        @pSortOrder,
                        @pAccountCode,
                        @pAccountName,

                        TRY_CONVERT
                        (
                            INT,
                            InvYear
                        ),

                        TRY_CONVERT
                        (
                            DECIMAL(38,2),
                            PAY_DAY
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        Paid
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        PaidnFullyDeduct
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        RetailLinkStatus
                                    )
                                )
                            ),
                            N''''
                        )

                    FROM ' + @FullTableName + N'

                    WHERE TRY_CONVERT
                    (
                        INT,
                        InvYear
                    ) BETWEEN 1900 AND 2100;

                    SET @pRowsInserted = @@ROWCOUNT;
                ';

                EXEC sys.sp_executesql
                    @SQL,
                    N'
                        @pSortOrder INT,
                        @pAccountCode VARCHAR(20),
                        @pAccountName VARCHAR(255),
                        @pRowsInserted INT OUTPUT
                    ',
                    @pSortOrder = @SortOrder,
                    @pAccountCode = @AccountCode,
                    @pAccountName = @AccountName,
                    @pRowsInserted = @SourceRows OUTPUT;


                /*--------------------------------------------------------------
                |-- TABLE HAS NO VALID SOURCE ROWS
                --------------------------------------------------------------*/

                IF @SourceRows = 0
                BEGIN
                    RAISERROR(
                        'Q#05 skipped: %s has no valid InvYear source rows.',
                        0,
                        1,
                        @FullTableName
                    ) WITH NOWAIT;
                END
                ELSE
                BEGIN
                    INSERT INTO #Accounts
                    (
                        SortOrder,
                        AccountCode,
                        AccountName
                    )
                    VALUES
                    (
                        @SortOrder,
                        @AccountCode,
                        @AccountName
                    );

                    SET @ValidSourceCount += 1;

                    RAISERROR(
                        'Q#05 loaded: %s rows inserted = %d.',
                        0,
                        1,
                        @FullTableName,
                        @SourceRows
                    ) WITH NOWAIT;
                END;
            END;
        END;

        FETCH NEXT FROM SourceCursor
        INTO
            @SchemaName,
            @TableName,
            @AccountCode,
            @AccountName,
            @SortOrder;
    END;

    CLOSE SourceCursor;
    DEALLOCATE SourceCursor;


    SET @RowsAffected =
    (
        SELECT COUNT(*)
        FROM #AllInvoiceData
    );

    RAISERROR(
        'Q#05 completed: Valid sources = %d; combined rows = %d.',
        0,
        1,
        @ValidSourceCount,
        @RowsAffected
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#06 | NO VALID SOURCE DATA: PRINT AND STOP
    ==========================================================================*/

    IF NOT EXISTS
    (
        SELECT 1
        FROM #AllInvoiceData
    )
    BEGIN
        RAISERROR(
            'Q#06 info: No valid invoice source rows found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: No source table had valid data.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;


    /*==========================================================================
    |-- Q#07 | FIND DYNAMIC INVYEAR VALUES
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;

    CREATE TABLE #Years
    (
        InvYear INT NOT NULL
    );

    INSERT INTO #Years
    (
        InvYear
    )
    SELECT DISTINCT
        InvYear
    FROM #AllInvoiceData
    WHERE InvYear IS NOT NULL;


    IF NOT EXISTS
    (
        SELECT 1
        FROM #Years
    )
    BEGIN
        RAISERROR(
            'Q#07 info: No valid InvYear values found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: Dynamic year columns cannot be generated.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #Years;
        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;

    RAISERROR(
        'Q#07 completed: Dynamic InvYear values found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#08 | BUILD DYNAMIC YEAR EXPRESSIONS
    ==========================================================================*/

    SELECT
        @YearDefinitions =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    + N' DECIMAL(38,2) NULL'
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearColumnList =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearNullList =
            STRING_AGG
            (
                CAST
                (
                    N'NULL'
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearAmountExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + N'CASE '
                    + N'WHEN D.InvYear = '
                    + CONVERT
                      (
                          VARCHAR(10),
                          InvYear
                      )
                    + N' THEN COALESCE(D.PAY_DAY, 0) '
                    + N'ELSE 0 END'
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearTotalExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            )
    FROM #Years;

    RAISERROR(
        'Q#08 completed: Dynamic year expressions generated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#09 | DROP AND RECREATE OUTPUT TABLE
    ==========================================================================*/

    SET @SQL = N'
        IF OBJECT_ID
        (
            N''dbo.Invoices_Status'',
            N''U''
        ) IS NOT NULL
        BEGIN
            DROP TABLE dbo.Invoices_Status;
        END;

        CREATE TABLE dbo.Invoices_Status
        (
            ID INT IDENTITY(1,1) NOT NULL,

            SortOrder INT NOT NULL,

            [Row Type] VARCHAR(30) NULL,

            [Summary / Account Name] VARCHAR(255) NULL,

            ' + @YearDefinitions + N',

            [Total Amount] DECIMAL(38,2) NULL,

            [Paid#] DECIMAL(38,2) NULL,

            [Paid & Fully Deduct] DECIMAL(38,2) NULL,

            [RetailLinkStatus] DECIMAL(38,2) NULL,

            GeneratedDate DATETIME2(0) NULL,

            CONSTRAINT PK_Invoices_Status
                PRIMARY KEY CLUSTERED (ID)
        );
    ';

    EXEC sys.sp_executesql @SQL;

    RAISERROR(
        'Q#09 completed: dbo.Invoices_Status recreated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#10 | INSERT SUMMARY ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            1,
            ''SUMMARY'',
            ''Total Amount BY YEAR'',

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ),

            NULL,
            NULL,
            NULL,
            SYSDATETIME()

        FROM #AllInvoiceData AS D;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#11 | INSERT TWO FULL NULL ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        VALUES
        (
            2,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        ),
        (
            3,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        );
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#12 | INSERT AVAILABLE ACCOUNT ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            A.SortOrder,
            ''ACCOUNT'',
            A.AccountName,

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ) AS [Total Amount],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.Paid LIKE N''%InvPaid%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid#],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.PaidnFullyDeduct
                             LIKE N''%PaidnDeducted%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid & Fully Deduct],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.RetailLinkStatus
                             LIKE N''%NoRetailLink%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [RetailLinkStatus],

            SYSDATETIME()

        FROM #Accounts AS A

        INNER JOIN #AllInvoiceData AS D
            ON D.AccountCode = A.AccountCode

        GROUP BY
            A.SortOrder,
            A.AccountCode,
            A.AccountName;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#13 | INSERT FINAL TOTAL ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            999,
            ''TOTAL'',
            ''Total'',

            ' + @YearTotalExpressions + N',

            COALESCE(SUM([Total Amount]), 0),

            COALESCE(SUM([Paid#]), 0),

            COALESCE(SUM([Paid & Fully Deduct]), 0),

            COALESCE(SUM([RetailLinkStatus]), 0),

            SYSDATETIME()

        FROM dbo.Invoices_Status

        WHERE [Row Type] = ''ACCOUNT'';
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#14 | DISPLAY SAVED REPORT
    ==========================================================================*/

    SET @SQL = N'
        SELECT
            [Row Type],

            [Summary / Account Name],

            ' + @YearColumnList + N',

            [Total Amount],

            [Paid#],

            [Paid & Fully Deduct],

            [RetailLinkStatus]

        FROM dbo.Invoices_Status

        ORDER BY SortOrder;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#15 | CLEANUP
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;
    DROP TABLE IF EXISTS #AllInvoiceData;
    DROP TABLE IF EXISTS #Accounts;
    DROP TABLE IF EXISTS #SourceConfig;

    RAISERROR(
        'Invoice Status completed successfully.',
        0,
        1
    ) WITH NOWAIT;
END;



--->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>44444444444444444444444444444444444




USE [WallMartSummary]
GO
/****** Object:  StoredProcedure [dbo].[sp_WallMartSummary_Invoice_Status]    Script Date: 8/24/2026 8:52:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALMART SUMMARY V-06
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_Invoice_Status
|
|  OUTPUT TABLE
|  `-- dbo.Invoices_Status
|
|  SOURCE HANDLING
|  |-- Missing table          : Print and skip
|  |-- Missing source column  : Print and skip
|  |-- No valid source rows   : Print and skip
|  `-- No valid sources at all: Print and stop without error
|
|  DYNAMIC YEAR COLUMNS
|  `-- Generated from valid InvYear values in available source tables
|
==============================================================================*/

ALTER   PROCEDURE [dbo].[sp_WallMartSummary_Invoice_Status]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @SchemaName            SYSNAME,
        @TableName             SYSNAME,
        @FullTableName         NVARCHAR(517),
        @AccountCode           VARCHAR(20),
        @AccountName           VARCHAR(255),
        @SortOrder             INT,
        @MissingColumns        NVARCHAR(MAX),
        @YearDefinitions       NVARCHAR(MAX),
        @YearColumnList        NVARCHAR(MAX),
        @YearNullList          NVARCHAR(MAX),
        @YearAmountExpressions NVARCHAR(MAX),
        @YearTotalExpressions  NVARCHAR(MAX),
        @SQL                   NVARCHAR(MAX),
        @RowsAffected          INT = 0,
        @SourceRows            INT = 0,
        @ValidSourceCount      INT = 0;


    /*==========================================================================
    |-- Q#01 | START MESSAGE
    ==========================================================================*/

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROJECT       : WALMART SUMMARY',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROCEDURE     : dbo.sp_WallMartSummary_Invoice_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'TARGET TABLE  : dbo.Invoices_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'QUERY VERSION : V-06',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#02 | CREATE SOURCE CONFIGURATION
    ==========================================================================*/

    DROP TABLE IF EXISTS #SourceConfig;

    CREATE TABLE #SourceConfig
    (
        SortOrder   INT          NOT NULL,
        SchemaName  SYSNAME      NOT NULL,
        TableName   SYSNAME      NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );

    INSERT INTO #SourceConfig
    (
        SortOrder,
        SchemaName,
        TableName,
        AccountCode,
        AccountName
    )
    VALUES
        (
            4,
            N'dbo',
            N'WC9085_Invoices',
            'WC9085',
            'WC9085 (WAL-MART CANADA, INC.)'
        ),
        (
            5,
            N'dbo',
            N'WA9085_Invoices',
            'WA9085',
            'WA9085 (WAL-MART STORE, INC.)'
        ),
        (
            6,
            N'dbo',
            N'SA9200_Invoices',
            'SA9200',
            'SA9200 (SAM''S CLUB)'
        ),
        (
            7,
            N'dbo',
            N'WM9263_Invoices',
            'WM9263',
            'WM9263 (WAL-MART STORE #2306)'
        );

    RAISERROR(
        'Q#02 completed: Source configuration created.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#03 | CREATE VALID ACCOUNT LIST
    ==========================================================================*/

    DROP TABLE IF EXISTS #Accounts;

    CREATE TABLE #Accounts
    (
        SortOrder   INT          NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );


    /*==========================================================================
    |-- Q#04 | CREATE COMBINED SOURCE TABLE
    ==========================================================================*/

    DROP TABLE IF EXISTS #AllInvoiceData;

    CREATE TABLE #AllInvoiceData
    (
        SortOrder          INT           NOT NULL,
        AccountCode        VARCHAR(20)   NOT NULL,
        AccountName        VARCHAR(255)  NOT NULL,
        InvYear            INT           NULL,
        PAY_DAY            DECIMAL(38,2) NULL,
        Paid               NVARCHAR(255) NULL,
        PaidnFullyDeduct   NVARCHAR(255) NULL,
        RetailLinkStatus   NVARCHAR(255) NULL
    );


    /*==========================================================================
    |-- Q#05 | CHECK AND LOAD EACH SOURCE TABLE
    ==========================================================================*/

    DECLARE SourceCursor CURSOR LOCAL FAST_FORWARD
    FOR
        SELECT
            SchemaName,
            TableName,
            AccountCode,
            AccountName,
            SortOrder
        FROM #SourceConfig
        ORDER BY SortOrder;

    OPEN SourceCursor;

    FETCH NEXT FROM SourceCursor
    INTO
        @SchemaName,
        @TableName,
        @AccountCode,
        @AccountName,
        @SortOrder;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @FullTableName =
            QUOTENAME(@SchemaName)
            + N'.'
            + QUOTENAME(@TableName);

        SET @MissingColumns = N'';
        SET @SourceRows = 0;


        /*----------------------------------------------------------------------
        |-- TABLE NOT FOUND: PRINT AND SKIP
        ----------------------------------------------------------------------*/

        IF OBJECT_ID(@FullTableName, N'U') IS NULL
        BEGIN
            RAISERROR(
                'Q#05 skipped: Table %s not found.',
                0,
                1,
                @FullTableName
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN

            /*------------------------------------------------------------------
            |-- CHECK REQUIRED COLUMNS
            ------------------------------------------------------------------*/

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'InvYear'
            ) IS NULL
                SET @MissingColumns += N'InvYear; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PAY_DAY'
            ) IS NULL
                SET @MissingColumns += N'PAY_DAY; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'Paid'
            ) IS NULL
                SET @MissingColumns += N'Paid; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PaidnFullyDeduct'
            ) IS NULL
                SET @MissingColumns += N'PaidnFullyDeduct; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'RetailLinkStatus'
            ) IS NULL
                SET @MissingColumns += N'RetailLinkStatus; ';


            /*------------------------------------------------------------------
            |-- REQUIRED COLUMN MISSING: PRINT AND SKIP
            ------------------------------------------------------------------*/

            IF @MissingColumns <> N''
            BEGIN
                RAISERROR(
                    'Q#05 skipped: %s missing column(s): %s',
                    0,
                    1,
                    @FullTableName,
                    @MissingColumns
                ) WITH NOWAIT;
            END
            ELSE
            BEGIN

                /*--------------------------------------------------------------
                |-- LOAD VALID SOURCE ROWS
                --------------------------------------------------------------*/

                SET @SQL = N'
                    INSERT INTO #AllInvoiceData
                    (
                        SortOrder,
                        AccountCode,
                        AccountName,
                        InvYear,
                        PAY_DAY,
                        Paid,
                        PaidnFullyDeduct,
                        RetailLinkStatus
                    )
                    SELECT
                        @pSortOrder,
                        @pAccountCode,
                        @pAccountName,

                        TRY_CONVERT
                        (
                            INT,
                            InvYear
                        ),

                        TRY_CONVERT
                        (
                            DECIMAL(38,2),
                            PAY_DAY
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        Paid
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        PaidnFullyDeduct
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        RetailLinkStatus
                                    )
                                )
                            ),
                            N''''
                        )

                    FROM ' + @FullTableName + N'

                    WHERE TRY_CONVERT
                    (
                        INT,
                        InvYear
                    ) BETWEEN 1900 AND 2100;

                    SET @pRowsInserted = @@ROWCOUNT;
                ';

                EXEC sys.sp_executesql
                    @SQL,
                    N'
                        @pSortOrder INT,
                        @pAccountCode VARCHAR(20),
                        @pAccountName VARCHAR(255),
                        @pRowsInserted INT OUTPUT
                    ',
                    @pSortOrder = @SortOrder,
                    @pAccountCode = @AccountCode,
                    @pAccountName = @AccountName,
                    @pRowsInserted = @SourceRows OUTPUT;


                /*--------------------------------------------------------------
                |-- TABLE HAS NO VALID SOURCE ROWS
                --------------------------------------------------------------*/

                IF @SourceRows = 0
                BEGIN
                    RAISERROR(
                        'Q#05 skipped: %s has no valid InvYear source rows.',
                        0,
                        1,
                        @FullTableName
                    ) WITH NOWAIT;
                END
                ELSE
                BEGIN
                    INSERT INTO #Accounts
                    (
                        SortOrder,
                        AccountCode,
                        AccountName
                    )
                    VALUES
                    (
                        @SortOrder,
                        @AccountCode,
                        @AccountName
                    );

                    SET @ValidSourceCount += 1;

                    RAISERROR(
                        'Q#05 loaded: %s rows inserted = %d.',
                        0,
                        1,
                        @FullTableName,
                        @SourceRows
                    ) WITH NOWAIT;
                END;
            END;
        END;

        FETCH NEXT FROM SourceCursor
        INTO
            @SchemaName,
            @TableName,
            @AccountCode,
            @AccountName,
            @SortOrder;
    END;

    CLOSE SourceCursor;
    DEALLOCATE SourceCursor;


    SET @RowsAffected =
    (
        SELECT COUNT(*)
        FROM #AllInvoiceData
    );

    RAISERROR(
        'Q#05 completed: Valid sources = %d; combined rows = %d.',
        0,
        1,
        @ValidSourceCount,
        @RowsAffected
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#06 | NO VALID SOURCE DATA: PRINT AND STOP
    ==========================================================================*/

    IF NOT EXISTS
    (
        SELECT 1
        FROM #AllInvoiceData
    )
    BEGIN
        RAISERROR(
            'Q#06 info: No valid invoice source rows found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: No source table had valid data.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;


    /*==========================================================================
    |-- Q#07 | FIND DYNAMIC INVYEAR VALUES
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;

    CREATE TABLE #Years
    (
        InvYear INT NOT NULL
    );

    INSERT INTO #Years
    (
        InvYear
    )
    SELECT DISTINCT
        InvYear
    FROM #AllInvoiceData
    WHERE InvYear IS NOT NULL;


    IF NOT EXISTS
    (
        SELECT 1
        FROM #Years
    )
    BEGIN
        RAISERROR(
            'Q#07 info: No valid InvYear values found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: Dynamic year columns cannot be generated.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #Years;
        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;

    RAISERROR(
        'Q#07 completed: Dynamic InvYear values found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#08 | BUILD DYNAMIC YEAR EXPRESSIONS
    ==========================================================================*/

    SELECT
        @YearDefinitions =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    + N' DECIMAL(38,2) NULL'
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearColumnList =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearNullList =
            STRING_AGG
            (
                CAST
                (
                    N'NULL'
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearAmountExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + N'CASE '
                    + N'WHEN D.InvYear = '
                    + CONVERT
                      (
                          VARCHAR(10),
                          InvYear
                      )
                    + N' THEN COALESCE(D.PAY_DAY, 0) '
                    + N'ELSE 0 END'
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearTotalExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            )
    FROM #Years;

    RAISERROR(
        'Q#08 completed: Dynamic year expressions generated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#09 | DROP AND RECREATE OUTPUT TABLE
    ==========================================================================*/

    SET @SQL = N'
        IF OBJECT_ID
        (
            N''dbo.Invoices_Status'',
            N''U''
        ) IS NOT NULL
        BEGIN
            DROP TABLE dbo.Invoices_Status;
        END;

        CREATE TABLE dbo.Invoices_Status
        (
            ID INT IDENTITY(1,1) NOT NULL,

            SortOrder INT NOT NULL,

            [Row Type] VARCHAR(30) NULL,

            [Summary / Account Name] VARCHAR(255) NULL,

            ' + @YearDefinitions + N',

            [Total Amount] DECIMAL(38,2) NULL,

            [Paid#] DECIMAL(38,2) NULL,

            [Paid & Fully Deduct] DECIMAL(38,2) NULL,

            [RetailLinkStatus] DECIMAL(38,2) NULL,

            GeneratedDate DATETIME2(0) NULL,

            CONSTRAINT PK_Invoices_Status
                PRIMARY KEY CLUSTERED (ID)
        );
    ';

    EXEC sys.sp_executesql @SQL;

    RAISERROR(
        'Q#09 completed: dbo.Invoices_Status recreated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#10 | INSERT SUMMARY ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            1,
            ''SUMMARY'',
            ''Total Amount BY YEAR'',

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ),

            NULL,
            NULL,
            NULL,
            SYSDATETIME()

        FROM #AllInvoiceData AS D;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#11 | INSERT TWO FULL NULL ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        VALUES
        (
            2,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        ),
        (
            3,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        );
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#12 | INSERT AVAILABLE ACCOUNT ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            A.SortOrder,
            ''ACCOUNT'',
            A.AccountName,

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ) AS [Total Amount],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.Paid LIKE N''%InvPaid%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid#],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.PaidnFullyDeduct
                             LIKE N''%PaidnDeducted%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid & Fully Deduct],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.RetailLinkStatus
                             LIKE N''%NoRetailLink%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [RetailLinkStatus],

            SYSDATETIME()

        FROM #Accounts AS A

        INNER JOIN #AllInvoiceData AS D
            ON D.AccountCode = A.AccountCode

        GROUP BY
            A.SortOrder,
            A.AccountCode,
            A.AccountName;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#13 | INSERT FINAL TOTAL ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            999,
            ''TOTAL'',
            ''Total'',

            ' + @YearTotalExpressions + N',

            COALESCE(SUM([Total Amount]), 0),

            COALESCE(SUM([Paid#]), 0),

            COALESCE(SUM([Paid & Fully Deduct]), 0),

            COALESCE(SUM([RetailLinkStatus]), 0),

            SYSDATETIME()

        FROM dbo.Invoices_Status

        WHERE [Row Type] = ''ACCOUNT'';
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#14 | DISPLAY SAVED REPORT
    ==========================================================================*/

    SET @SQL = N'
        SELECT
            [Row Type],

            [Summary / Account Name],

            ' + @YearColumnList + N',

            [Total Amount],

            [Paid#],

            [Paid & Fully Deduct],

            [RetailLinkStatus]

        FROM dbo.Invoices_Status

        ORDER BY SortOrder;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#15 | CLEANUP
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;
    DROP TABLE IF EXISTS #AllInvoiceData;
    DROP TABLE IF EXISTS #Accounts;
    DROP TABLE IF EXISTS #SourceConfig;

    RAISERROR(
        'Invoice Status completed successfully.',
        0,
        1
    ) WITH NOWAIT;
END;


--->>>>>>>>>>>>>>>>>>>>>>>>>>>>>5555555555555555555555555555555555









