USE [WallMartSummary];
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALMART SUMMARY V-05
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_Invoice_Status
|
|  OUTPUT TABLE
|  `-- dbo.Invoices_Status
|
|  DYNAMIC YEAR COLUMNS
|  `-- Generated automatically from valid InvYear values
|
|  CALCULATION LOGIC
|  |-- Year Amount
|  |   `-- SUM(PAY_DAY) GROUP BY AccountCode, InvYear
|  |
|  |-- Total Amount
|  |   `-- SUM(PAY_DAY) GROUP BY AccountCode
|  |
|  |-- Paid#
|  |   `-- SUM(PAY_DAY) WHERE Paid LIKE '%InvPaid%'
|  |
|  |-- Paid & Fully Deduct
|  |   `-- SUM(PAY_DAY)
|  |       WHERE PaidnFullyDeduct LIKE '%PaidnDeducted%'
|  |
|  `-- RetailLinkStatus
|      `-- SUM(PAY_DAY)
|          WHERE RetailLinkStatus LIKE '%NoRetailLink%'
|
|  ROW ORDER
|  |-- SUMMARY
|  |-- NULL
|  |-- NULL
|  |-- WC9085
|  |-- WA9085
|  |-- SA9200
|  |-- WM9263
|  `-- TOTAL
|
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_Invoice_Status
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @MissingTables          NVARCHAR(MAX) = N'',
        @MissingColumns         NVARCHAR(MAX) = N'',
        @YearDefinitions        NVARCHAR(MAX),
        @YearColumnList         NVARCHAR(MAX),
        @YearNullList           NVARCHAR(MAX),
        @YearAmountExpressions  NVARCHAR(MAX),
        @YearTotalExpressions   NVARCHAR(MAX),
        @SQL                    NVARCHAR(MAX),
        @RowsAffected           INT = 0;


    /*==========================================================================
    |-- Q#01 | START MESSAGE
    ==========================================================================*/

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROJECT       : WALMART SUMMARY',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROCEDURE     : dbo.sp_WallMartSummary_Invoice_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'TARGET TABLE  : dbo.Invoices_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'QUERY VERSION : V-05',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#02 | VALIDATE REQUIRED SOURCE TABLES
    ==========================================================================*/

    IF OBJECT_ID(N'dbo.WC9085_Invoices', N'U') IS NULL
        SET @MissingTables += N'dbo.WC9085_Invoices; ';

    IF OBJECT_ID(N'dbo.WA9085_Invoices', N'U') IS NULL
        SET @MissingTables += N'dbo.WA9085_Invoices; ';

    IF OBJECT_ID(N'dbo.SA9200_Invoices', N'U') IS NULL
        SET @MissingTables += N'dbo.SA9200_Invoices; ';

    IF OBJECT_ID(N'dbo.WM9263_Invoices', N'U') IS NULL
        SET @MissingTables += N'dbo.WM9263_Invoices; ';


    IF @MissingTables <> N''
    BEGIN
        RAISERROR(
            'Required source table(s) not found: %s',
            16,
            1,
            @MissingTables
        );

        RETURN;
    END;


    RAISERROR(
        'Q#02 completed: Required source tables found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#03 | VALIDATE REQUIRED SOURCE COLUMNS
    ==========================================================================*/

    /*--------------------------------------------------------------------------
    |-- WC9085
    --------------------------------------------------------------------------*/

    IF COL_LENGTH(N'dbo.WC9085_Invoices', N'InvYear') IS NULL
        SET @MissingColumns += N'dbo.WC9085_Invoices.InvYear; ';

    IF COL_LENGTH(N'dbo.WC9085_Invoices', N'PAY_DAY') IS NULL
        SET @MissingColumns += N'dbo.WC9085_Invoices.PAY_DAY; ';

    IF COL_LENGTH(N'dbo.WC9085_Invoices', N'Paid') IS NULL
        SET @MissingColumns += N'dbo.WC9085_Invoices.Paid; ';

    IF COL_LENGTH(N'dbo.WC9085_Invoices', N'PaidnFullyDeduct') IS NULL
        SET @MissingColumns +=
            N'dbo.WC9085_Invoices.PaidnFullyDeduct; ';

    IF COL_LENGTH(N'dbo.WC9085_Invoices', N'RetailLinkStatus') IS NULL
        SET @MissingColumns +=
            N'dbo.WC9085_Invoices.RetailLinkStatus; ';


    /*--------------------------------------------------------------------------
    |-- WA9085
    --------------------------------------------------------------------------*/

    IF COL_LENGTH(N'dbo.WA9085_Invoices', N'InvYear') IS NULL
        SET @MissingColumns += N'dbo.WA9085_Invoices.InvYear; ';

    IF COL_LENGTH(N'dbo.WA9085_Invoices', N'PAY_DAY') IS NULL
        SET @MissingColumns += N'dbo.WA9085_Invoices.PAY_DAY; ';

    IF COL_LENGTH(N'dbo.WA9085_Invoices', N'Paid') IS NULL
        SET @MissingColumns += N'dbo.WA9085_Invoices.Paid; ';

    IF COL_LENGTH(N'dbo.WA9085_Invoices', N'PaidnFullyDeduct') IS NULL
        SET @MissingColumns +=
            N'dbo.WA9085_Invoices.PaidnFullyDeduct; ';

    IF COL_LENGTH(N'dbo.WA9085_Invoices', N'RetailLinkStatus') IS NULL
        SET @MissingColumns +=
            N'dbo.WA9085_Invoices.RetailLinkStatus; ';


    /*--------------------------------------------------------------------------
    |-- SA9200
    --------------------------------------------------------------------------*/

    IF COL_LENGTH(N'dbo.SA9200_Invoices', N'InvYear') IS NULL
        SET @MissingColumns += N'dbo.SA9200_Invoices.InvYear; ';

    IF COL_LENGTH(N'dbo.SA9200_Invoices', N'PAY_DAY') IS NULL
        SET @MissingColumns += N'dbo.SA9200_Invoices.PAY_DAY; ';

    IF COL_LENGTH(N'dbo.SA9200_Invoices', N'Paid') IS NULL
        SET @MissingColumns += N'dbo.SA9200_Invoices.Paid; ';

    IF COL_LENGTH(N'dbo.SA9200_Invoices', N'PaidnFullyDeduct') IS NULL
        SET @MissingColumns +=
            N'dbo.SA9200_Invoices.PaidnFullyDeduct; ';

    IF COL_LENGTH(N'dbo.SA9200_Invoices', N'RetailLinkStatus') IS NULL
        SET @MissingColumns +=
            N'dbo.SA9200_Invoices.RetailLinkStatus; ';


    /*--------------------------------------------------------------------------
    |-- WM9263
    --------------------------------------------------------------------------*/

    IF COL_LENGTH(N'dbo.WM9263_Invoices', N'InvYear') IS NULL
        SET @MissingColumns += N'dbo.WM9263_Invoices.InvYear; ';

    IF COL_LENGTH(N'dbo.WM9263_Invoices', N'PAY_DAY') IS NULL
        SET @MissingColumns += N'dbo.WM9263_Invoices.PAY_DAY; ';

    IF COL_LENGTH(N'dbo.WM9263_Invoices', N'Paid') IS NULL
        SET @MissingColumns += N'dbo.WM9263_Invoices.Paid; ';

    IF COL_LENGTH(N'dbo.WM9263_Invoices', N'PaidnFullyDeduct') IS NULL
        SET @MissingColumns +=
            N'dbo.WM9263_Invoices.PaidnFullyDeduct; ';

    IF COL_LENGTH(N'dbo.WM9263_Invoices', N'RetailLinkStatus') IS NULL
        SET @MissingColumns +=
            N'dbo.WM9263_Invoices.RetailLinkStatus; ';


    IF @MissingColumns <> N''
    BEGIN
        RAISERROR(
            'Required source column(s) not found: %s',
            16,
            1,
            @MissingColumns
        );

        RETURN;
    END;


    RAISERROR(
        'Q#03 completed: Required source columns found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#04 | CREATE ACCOUNT SETTINGS
    ==========================================================================*/

    DROP TABLE IF EXISTS #Accounts;

    CREATE TABLE #Accounts
    (
        SortOrder   INT          NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );


    INSERT INTO #Accounts
    (
        SortOrder,
        AccountCode,
        AccountName
    )
    VALUES
        (
            4,
            'WC9085',
            'WC9085 (WAL-MART CANADA, INC.)'
        ),
        (
            5,
            'WA9085',
            'WA9085 (WAL-MART STORE, INC.)'
        ),
        (
            6,
            'SA9200',
            'SA9200 (SAM''S CLUB)'
        ),
        (
            7,
            'WM9263',
            'WM9263 (WAL-MART STORE #2306)'
        );


    RAISERROR(
        'Q#04 completed: Account settings inserted = 4.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#05 | CREATE COMBINED SOURCE TABLE
    ==========================================================================*/

    DROP TABLE IF EXISTS #AllInvoiceData;

    CREATE TABLE #AllInvoiceData
    (
        SortOrder          INT             NOT NULL,
        AccountCode        VARCHAR(20)     NOT NULL,
        AccountName        VARCHAR(255)    NOT NULL,
        InvYear            INT             NULL,
        PAY_DAY            DECIMAL(38,2)   NULL,
        Paid               NVARCHAR(255)   NULL,
        PaidnFullyDeduct   NVARCHAR(255)   NULL,
        RetailLinkStatus   NVARCHAR(255)   NULL
    );


    /*--------------------------------------------------------------------------
    |-- WC9085 SOURCE
    --------------------------------------------------------------------------*/

    INSERT INTO #AllInvoiceData
    (
        SortOrder,
        AccountCode,
        AccountName,
        InvYear,
        PAY_DAY,
        Paid,
        PaidnFullyDeduct,
        RetailLinkStatus
    )
    SELECT
        4,

        'WC9085',

        'WC9085 (WAL-MART CANADA, INC.)',

        TRY_CONVERT(INT, InvYear),

        TRY_CONVERT(
            DECIMAL(38,2),
            PAY_DAY
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), Paid))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), PaidnFullyDeduct))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), RetailLinkStatus))),
            N''
        )

    FROM dbo.WC9085_Invoices

    WHERE TRY_CONVERT(INT, InvYear) BETWEEN 1900 AND 2100;


    /*--------------------------------------------------------------------------
    |-- WA9085 SOURCE
    --------------------------------------------------------------------------*/

    INSERT INTO #AllInvoiceData
    (
        SortOrder,
        AccountCode,
        AccountName,
        InvYear,
        PAY_DAY,
        Paid,
        PaidnFullyDeduct,
        RetailLinkStatus
    )
    SELECT
        5,

        'WA9085',

        'WA9085 (WAL-MART STORE, INC.)',

        TRY_CONVERT(INT, InvYear),

        TRY_CONVERT(
            DECIMAL(38,2),
            PAY_DAY
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), Paid))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), PaidnFullyDeduct))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), RetailLinkStatus))),
            N''
        )

    FROM dbo.WA9085_Invoices

    WHERE TRY_CONVERT(INT, InvYear) BETWEEN 1900 AND 2100;


    /*--------------------------------------------------------------------------
    |-- SA9200 SOURCE
    --------------------------------------------------------------------------*/

    INSERT INTO #AllInvoiceData
    (
        SortOrder,
        AccountCode,
        AccountName,
        InvYear,
        PAY_DAY,
        Paid,
        PaidnFullyDeduct,
        RetailLinkStatus
    )
    SELECT
        6,

        'SA9200',

        'SA9200 (SAM''S CLUB)',

        TRY_CONVERT(INT, InvYear),

        TRY_CONVERT(
            DECIMAL(38,2),
            PAY_DAY
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), Paid))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), PaidnFullyDeduct))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), RetailLinkStatus))),
            N''
        )

    FROM dbo.SA9200_Invoices

    WHERE TRY_CONVERT(INT, InvYear) BETWEEN 1900 AND 2100;


    /*--------------------------------------------------------------------------
    |-- WM9263 SOURCE
    --------------------------------------------------------------------------*/

    INSERT INTO #AllInvoiceData
    (
        SortOrder,
        AccountCode,
        AccountName,
        InvYear,
        PAY_DAY,
        Paid,
        PaidnFullyDeduct,
        RetailLinkStatus
    )
    SELECT
        7,

        'WM9263',

        'WM9263 (WAL-MART STORE #2306)',

        TRY_CONVERT(INT, InvYear),

        TRY_CONVERT(
            DECIMAL(38,2),
            PAY_DAY
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), Paid))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), PaidnFullyDeduct))),
            N''
        ),

        NULLIF(
            LTRIM(RTRIM(CONVERT(NVARCHAR(255), RetailLinkStatus))),
            N''
        )

    FROM dbo.WM9263_Invoices

    WHERE TRY_CONVERT(INT, InvYear) BETWEEN 1900 AND 2100;


    SET @RowsAffected =
    (
        SELECT COUNT(*)
        FROM #AllInvoiceData
    );


    RAISERROR(
        'Q#05 completed: Combined source rows = %d.',
        0,
        1,
        @RowsAffected
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#06 | FIND DYNAMIC INVYEAR VALUES
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;

    CREATE TABLE #Years
    (
        InvYear INT NOT NULL
    );


    INSERT INTO #Years
    (
        InvYear
    )
    SELECT DISTINCT
        InvYear
    FROM #AllInvoiceData
    WHERE InvYear IS NOT NULL;


    IF NOT EXISTS
    (
        SELECT 1
        FROM #Years
    )
    BEGIN
        RAISERROR(
            'No valid InvYear values found in invoice source tables.',
            16,
            1
        );

        RETURN;
    END;


    RAISERROR(
        'Q#06 completed: Dynamic InvYear values found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#07 | BUILD DYNAMIC YEAR EXPRESSIONS
    ==========================================================================*/

    SELECT
        @YearDefinitions =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME(
                        CONVERT(VARCHAR(10), InvYear)
                    )
                    + N' DECIMAL(38,2) NULL'
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearColumnList =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME(
                        CONVERT(VARCHAR(10), InvYear)
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearNullList =
            STRING_AGG
            (
                CAST(
                    N'NULL'
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearAmountExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + N'CASE '
                    + N'WHEN D.InvYear = '
                    + CONVERT(VARCHAR(10), InvYear)
                    + N' THEN COALESCE(D.PAY_DAY, 0) '
                    + N'ELSE 0 '
                    + N'END'
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME(
                        CONVERT(VARCHAR(10), InvYear)
                    )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearTotalExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + QUOTENAME(
                        CONVERT(VARCHAR(10), InvYear)
                    )
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME(
                        CONVERT(VARCHAR(10), InvYear)
                    )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            )

    FROM #Years;


    RAISERROR(
        'Q#07 completed: Dynamic year SQL generated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#08 | DROP AND RECREATE OUTPUT TABLE
    ==========================================================================*/

    SET @SQL = N'
        IF OBJECT_ID(
            N''dbo.Invoices_Status'',
            N''U''
        ) IS NOT NULL
        BEGIN
            DROP TABLE dbo.Invoices_Status;
        END;


        CREATE TABLE dbo.Invoices_Status
        (
            ID INT IDENTITY(1,1) NOT NULL,

            SortOrder INT NOT NULL,

            [Row Type] VARCHAR(30) NULL,

            [Summary / Account Name] VARCHAR(255) NULL,

            ' + @YearDefinitions + N',

            [Total Amount] DECIMAL(38,2) NULL,

            [Paid#] DECIMAL(38,2) NULL,

            [Paid & Fully Deduct] DECIMAL(38,2) NULL,

            [RetailLinkStatus] DECIMAL(38,2) NULL,

            GeneratedDate DATETIME2(0) NULL,

            CONSTRAINT PK_Invoices_Status
                PRIMARY KEY CLUSTERED (ID)
        );
    ';


    EXEC sys.sp_executesql @SQL;


    RAISERROR(
        'Q#08 completed: dbo.Invoices_Status recreated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#09 | INSERT SUMMARY ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            1,

            ''SUMMARY'',

            ''Total Amount BY YEAR'',

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ),

            NULL,

            NULL,

            NULL,

            SYSDATETIME()

        FROM #AllInvoiceData AS D;
    ';


    EXEC sys.sp_executesql @SQL;


    RAISERROR(
        'Q#09 completed: Summary row inserted.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#10 | INSERT TWO FULL NULL ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        VALUES
        (
            2,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        ),
        (
            3,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        );
    ';


    EXEC sys.sp_executesql @SQL;


    RAISERROR(
        'Q#10 completed: Two NULL rows inserted.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#11 | INSERT ACCOUNT ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            A.SortOrder,

            ''ACCOUNT'',

            A.AccountName,

            ' + @YearAmountExpressions + N',

            /*--------------------------------------------------------------
            |-- TOTAL AMOUNT
            --------------------------------------------------------------*/

            COALESCE
            (
                SUM
                (
                    COALESCE(D.PAY_DAY, 0)
                ),
                0
            ) AS [Total Amount],


            /*--------------------------------------------------------------
            |-- PAID#
            |   SUM(PAY_DAY) WHERE Paid LIKE ''%InvPaid%''
            --------------------------------------------------------------*/

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.Paid LIKE N''%InvPaid%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid#],


            /*--------------------------------------------------------------
            |-- PAID & FULLY DEDUCT
            |   SUM(PAY_DAY)
            |   WHERE PaidnFullyDeduct LIKE ''%PaidnDeducted%''
            --------------------------------------------------------------*/

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.PaidnFullyDeduct
                             LIKE N''%PaidnDeducted%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid & Fully Deduct],


            /*--------------------------------------------------------------
            |-- RETAIL LINK STATUS
            |   SUM(PAY_DAY)
            |   WHERE RetailLinkStatus LIKE ''%NoRetailLink%''
            --------------------------------------------------------------*/

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.RetailLinkStatus
                             LIKE N''%NoRetailLink%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [RetailLinkStatus],

            SYSDATETIME()

        FROM #Accounts AS A

        LEFT JOIN #AllInvoiceData AS D
            ON D.AccountCode = A.AccountCode

        GROUP BY
            A.SortOrder,
            A.AccountCode,
            A.AccountName;
    ';


    EXEC sys.sp_executesql @SQL;


    RAISERROR(
        'Q#11 completed: Account rows inserted.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#12 | INSERT FINAL TOTAL ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            8,

            ''TOTAL'',

            ''Total'',

            ' + @YearTotalExpressions + N',

            COALESCE
            (
                SUM([Total Amount]),
                0
            ),

            COALESCE
            (
                SUM([Paid#]),
                0
            ),

            COALESCE
            (
                SUM([Paid & Fully Deduct]),
                0
            ),

            COALESCE
            (
                SUM([RetailLinkStatus]),
                0
            ),

            SYSDATETIME()

        FROM dbo.Invoices_Status

        WHERE [Row Type] = ''ACCOUNT'';
    ';


    EXEC sys.sp_executesql @SQL;


    SET @RowsAffected =
    (
        SELECT COUNT(*)
        FROM dbo.Invoices_Status
    );


    RAISERROR(
        'Q#12 completed: Total rows saved = %d.',
        0,
        1,
        @RowsAffected
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#13 | DISPLAY SAVED REPORT
    ==========================================================================*/

    SET @SQL = N'
        SELECT
            [Row Type],

            [Summary / Account Name],

            ' + @YearColumnList + N',

            [Total Amount],

            [Paid#],

            [Paid & Fully Deduct],

            [RetailLinkStatus]

        FROM dbo.Invoices_Status

        ORDER BY SortOrder;
    ';


    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#14 | CLEANUP
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;
    DROP TABLE IF EXISTS #AllInvoiceData;
    DROP TABLE IF EXISTS #Accounts;


    RAISERROR(
        'Invoice Status completed successfully.',
        0,
        1
    ) WITH NOWAIT;
END;
GO


/*==============================================================================
|-- RUN PROCEDURE
==============================================================================*/

USE [WallMartSummary];
GO

-- EXEC dbo.sp_WallMartSummary_Invoice_Status;
GO


/*==============================================================================
|-- VIEW SAVED TABLE
==============================================================================*/

USE [WallMartSummary];
GO

SELECT
    *
FROM dbo.Invoices_Status
ORDER BY SortOrder;
GO