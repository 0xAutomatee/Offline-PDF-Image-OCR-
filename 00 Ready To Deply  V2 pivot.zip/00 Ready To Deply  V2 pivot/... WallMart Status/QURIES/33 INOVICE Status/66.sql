USE [WallMartSummary];
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALMART SUMMARY V-06
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_Invoice_Status
|
|  OUTPUT TABLE
|  `-- dbo.Invoices_Status
|
|  SOURCE HANDLING
|  |-- Missing table          : Print and skip
|  |-- Missing source column  : Print and skip
|  |-- No valid source rows   : Print and skip
|  `-- No valid sources at all: Print and stop without error
|
|  DYNAMIC YEAR COLUMNS
|  `-- Generated from valid InvYear values in available source tables
|
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_Invoice_Status
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @SchemaName            SYSNAME,
        @TableName             SYSNAME,
        @FullTableName         NVARCHAR(517),
        @AccountCode           VARCHAR(20),
        @AccountName           VARCHAR(255),
        @SortOrder             INT,
        @MissingColumns        NVARCHAR(MAX),
        @YearDefinitions       NVARCHAR(MAX),
        @YearColumnList        NVARCHAR(MAX),
        @YearNullList          NVARCHAR(MAX),
        @YearAmountExpressions NVARCHAR(MAX),
        @YearTotalExpressions  NVARCHAR(MAX),
        @SQL                   NVARCHAR(MAX),
        @RowsAffected          INT = 0,
        @SourceRows            INT = 0,
        @ValidSourceCount      INT = 0;


    /*==========================================================================
    |-- Q#01 | START MESSAGE
    ==========================================================================*/

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROJECT       : WALMART SUMMARY',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'PROCEDURE     : dbo.sp_WallMartSummary_Invoice_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'TARGET TABLE  : dbo.Invoices_Status',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        'QUERY VERSION : V-06',
        0,
        1
    ) WITH NOWAIT;

    RAISERROR(
        '============================================================',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#02 | CREATE SOURCE CONFIGURATION
    ==========================================================================*/

    DROP TABLE IF EXISTS #SourceConfig;

    CREATE TABLE #SourceConfig
    (
        SortOrder   INT          NOT NULL,
        SchemaName  SYSNAME      NOT NULL,
        TableName   SYSNAME      NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );

    INSERT INTO #SourceConfig
    (
        SortOrder,
        SchemaName,
        TableName,
        AccountCode,
        AccountName
    )
    VALUES
        (
            4,
            N'dbo',
            N'WC9085_Invoices',
            'WC9085',
            'WC9085 (WAL-MART CANADA, INC.)'
        ),
        (
            5,
            N'dbo',
            N'WA9085_Invoices',
            'WA9085',
            'WA9085 (WAL-MART STORE, INC.)'
        ),
        (
            6,
            N'dbo',
            N'SA9200_Invoices',
            'SA9200',
            'SA9200 (SAM''S CLUB)'
        ),
        (
            7,
            N'dbo',
            N'WM9263_Invoices',
            'WM9263',
            'WM9263 (WAL-MART STORE #2306)'
        );

    RAISERROR(
        'Q#02 completed: Source configuration created.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#03 | CREATE VALID ACCOUNT LIST
    ==========================================================================*/

    DROP TABLE IF EXISTS #Accounts;

    CREATE TABLE #Accounts
    (
        SortOrder   INT          NOT NULL,
        AccountCode VARCHAR(20)  NOT NULL,
        AccountName VARCHAR(255) NOT NULL
    );


    /*==========================================================================
    |-- Q#04 | CREATE COMBINED SOURCE TABLE
    ==========================================================================*/

    DROP TABLE IF EXISTS #AllInvoiceData;

    CREATE TABLE #AllInvoiceData
    (
        SortOrder          INT           NOT NULL,
        AccountCode        VARCHAR(20)   NOT NULL,
        AccountName        VARCHAR(255)  NOT NULL,
        InvYear            INT           NULL,
        PAY_DAY            DECIMAL(38,2) NULL,
        Paid               NVARCHAR(255) NULL,
        PaidnFullyDeduct   NVARCHAR(255) NULL,
        RetailLinkStatus   NVARCHAR(255) NULL
    );


    /*==========================================================================
    |-- Q#05 | CHECK AND LOAD EACH SOURCE TABLE
    ==========================================================================*/

    DECLARE SourceCursor CURSOR LOCAL FAST_FORWARD
    FOR
        SELECT
            SchemaName,
            TableName,
            AccountCode,
            AccountName,
            SortOrder
        FROM #SourceConfig
        ORDER BY SortOrder;

    OPEN SourceCursor;

    FETCH NEXT FROM SourceCursor
    INTO
        @SchemaName,
        @TableName,
        @AccountCode,
        @AccountName,
        @SortOrder;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @FullTableName =
            QUOTENAME(@SchemaName)
            + N'.'
            + QUOTENAME(@TableName);

        SET @MissingColumns = N'';
        SET @SourceRows = 0;


        /*----------------------------------------------------------------------
        |-- TABLE NOT FOUND: PRINT AND SKIP
        ----------------------------------------------------------------------*/

        IF OBJECT_ID(@FullTableName, N'U') IS NULL
        BEGIN
            RAISERROR(
                'Q#05 skipped: Table %s not found.',
                0,
                1,
                @FullTableName
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN

            /*------------------------------------------------------------------
            |-- CHECK REQUIRED COLUMNS
            ------------------------------------------------------------------*/

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'InvYear'
            ) IS NULL
                SET @MissingColumns += N'InvYear; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PAY_DAY'
            ) IS NULL
                SET @MissingColumns += N'PAY_DAY; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'Paid'
            ) IS NULL
                SET @MissingColumns += N'Paid; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'PaidnFullyDeduct'
            ) IS NULL
                SET @MissingColumns += N'PaidnFullyDeduct; ';

            IF COL_LENGTH(
                @SchemaName + N'.' + @TableName,
                N'RetailLinkStatus'
            ) IS NULL
                SET @MissingColumns += N'RetailLinkStatus; ';


            /*------------------------------------------------------------------
            |-- REQUIRED COLUMN MISSING: PRINT AND SKIP
            ------------------------------------------------------------------*/

            IF @MissingColumns <> N''
            BEGIN
                RAISERROR(
                    'Q#05 skipped: %s missing column(s): %s',
                    0,
                    1,
                    @FullTableName,
                    @MissingColumns
                ) WITH NOWAIT;
            END
            ELSE
            BEGIN

                /*--------------------------------------------------------------
                |-- LOAD VALID SOURCE ROWS
                --------------------------------------------------------------*/

                SET @SQL = N'
                    INSERT INTO #AllInvoiceData
                    (
                        SortOrder,
                        AccountCode,
                        AccountName,
                        InvYear,
                        PAY_DAY,
                        Paid,
                        PaidnFullyDeduct,
                        RetailLinkStatus
                    )
                    SELECT
                        @pSortOrder,
                        @pAccountCode,
                        @pAccountName,

                        TRY_CONVERT
                        (
                            INT,
                            InvYear
                        ),

                        TRY_CONVERT
                        (
                            DECIMAL(38,2),
                            PAY_DAY
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        Paid
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        PaidnFullyDeduct
                                    )
                                )
                            ),
                            N''''
                        ),

                        NULLIF
                        (
                            LTRIM
                            (
                                RTRIM
                                (
                                    CONVERT
                                    (
                                        NVARCHAR(255),
                                        RetailLinkStatus
                                    )
                                )
                            ),
                            N''''
                        )

                    FROM ' + @FullTableName + N'

                    WHERE TRY_CONVERT
                    (
                        INT,
                        InvYear
                    ) BETWEEN 1900 AND 2100;

                    SET @pRowsInserted = @@ROWCOUNT;
                ';

                EXEC sys.sp_executesql
                    @SQL,
                    N'
                        @pSortOrder INT,
                        @pAccountCode VARCHAR(20),
                        @pAccountName VARCHAR(255),
                        @pRowsInserted INT OUTPUT
                    ',
                    @pSortOrder = @SortOrder,
                    @pAccountCode = @AccountCode,
                    @pAccountName = @AccountName,
                    @pRowsInserted = @SourceRows OUTPUT;


                /*--------------------------------------------------------------
                |-- TABLE HAS NO VALID SOURCE ROWS
                --------------------------------------------------------------*/

                IF @SourceRows = 0
                BEGIN
                    RAISERROR(
                        'Q#05 skipped: %s has no valid InvYear source rows.',
                        0,
                        1,
                        @FullTableName
                    ) WITH NOWAIT;
                END
                ELSE
                BEGIN
                    INSERT INTO #Accounts
                    (
                        SortOrder,
                        AccountCode,
                        AccountName
                    )
                    VALUES
                    (
                        @SortOrder,
                        @AccountCode,
                        @AccountName
                    );

                    SET @ValidSourceCount += 1;

                    RAISERROR(
                        'Q#05 loaded: %s rows inserted = %d.',
                        0,
                        1,
                        @FullTableName,
                        @SourceRows
                    ) WITH NOWAIT;
                END;
            END;
        END;

        FETCH NEXT FROM SourceCursor
        INTO
            @SchemaName,
            @TableName,
            @AccountCode,
            @AccountName,
            @SortOrder;
    END;

    CLOSE SourceCursor;
    DEALLOCATE SourceCursor;


    SET @RowsAffected =
    (
        SELECT COUNT(*)
        FROM #AllInvoiceData
    );

    RAISERROR(
        'Q#05 completed: Valid sources = %d; combined rows = %d.',
        0,
        1,
        @ValidSourceCount,
        @RowsAffected
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#06 | NO VALID SOURCE DATA: PRINT AND STOP
    ==========================================================================*/

    IF NOT EXISTS
    (
        SELECT 1
        FROM #AllInvoiceData
    )
    BEGIN
        RAISERROR(
            'Q#06 info: No valid invoice source rows found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: No source table had valid data.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;


    /*==========================================================================
    |-- Q#07 | FIND DYNAMIC INVYEAR VALUES
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;

    CREATE TABLE #Years
    (
        InvYear INT NOT NULL
    );

    INSERT INTO #Years
    (
        InvYear
    )
    SELECT DISTINCT
        InvYear
    FROM #AllInvoiceData
    WHERE InvYear IS NOT NULL;


    IF NOT EXISTS
    (
        SELECT 1
        FROM #Years
    )
    BEGIN
        RAISERROR(
            'Q#07 info: No valid InvYear values found.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Invoice Status skipped: Dynamic year columns cannot be generated.',
            0,
            1
        ) WITH NOWAIT;

        DROP TABLE IF EXISTS #Years;
        DROP TABLE IF EXISTS #AllInvoiceData;
        DROP TABLE IF EXISTS #Accounts;
        DROP TABLE IF EXISTS #SourceConfig;

        RETURN;
    END;

    RAISERROR(
        'Q#07 completed: Dynamic InvYear values found.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#08 | BUILD DYNAMIC YEAR EXPRESSIONS
    ==========================================================================*/

    SELECT
        @YearDefinitions =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    + N' DECIMAL(38,2) NULL'
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearColumnList =
            STRING_AGG
            (
                CAST
                (
                    QUOTENAME
                    (
                        CONVERT
                        (
                            VARCHAR(10),
                            InvYear
                        )
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearNullList =
            STRING_AGG
            (
                CAST
                (
                    N'NULL'
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearAmountExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + N'CASE '
                    + N'WHEN D.InvYear = '
                    + CONVERT
                      (
                          VARCHAR(10),
                          InvYear
                      )
                    + N' THEN COALESCE(D.PAY_DAY, 0) '
                    + N'ELSE 0 END'
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            ),

        @YearTotalExpressions =
            STRING_AGG
            (
                CAST
                (
                    N'COALESCE'
                    + N'('
                    + N'SUM'
                    + N'('
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    + N'),'
                    + N'0'
                    + N') AS '
                    + QUOTENAME
                      (
                          CONVERT
                          (
                              VARCHAR(10),
                              InvYear
                          )
                      )
                    AS NVARCHAR(MAX)
                ),
                N','
                + CHAR(13)
                + CHAR(10)
                + N'            '
            ) WITHIN GROUP
            (
                ORDER BY InvYear
            )
    FROM #Years;

    RAISERROR(
        'Q#08 completed: Dynamic year expressions generated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#09 | DROP AND RECREATE OUTPUT TABLE
    ==========================================================================*/

    SET @SQL = N'
        IF OBJECT_ID
        (
            N''dbo.Invoices_Status'',
            N''U''
        ) IS NOT NULL
        BEGIN
            DROP TABLE dbo.Invoices_Status;
        END;

        CREATE TABLE dbo.Invoices_Status
        (
            ID INT IDENTITY(1,1) NOT NULL,

            SortOrder INT NOT NULL,

            [Row Type] VARCHAR(30) NULL,

            [Summary / Account Name] VARCHAR(255) NULL,

            ' + @YearDefinitions + N',

            [Total Amount] DECIMAL(38,2) NULL,

            [Paid#] DECIMAL(38,2) NULL,

            [Paid & Fully Deduct] DECIMAL(38,2) NULL,

            [RetailLinkStatus] DECIMAL(38,2) NULL,

            GeneratedDate DATETIME2(0) NULL,

            CONSTRAINT PK_Invoices_Status
                PRIMARY KEY CLUSTERED (ID)
        );
    ';

    EXEC sys.sp_executesql @SQL;

    RAISERROR(
        'Q#09 completed: dbo.Invoices_Status recreated.',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#10 | INSERT SUMMARY ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            1,
            ''SUMMARY'',
            ''Total Amount BY YEAR'',

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ),

            NULL,
            NULL,
            NULL,
            SYSDATETIME()

        FROM #AllInvoiceData AS D;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#11 | INSERT TWO FULL NULL ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        VALUES
        (
            2,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        ),
        (
            3,
            NULL,
            NULL,
            ' + @YearNullList + N',
            NULL,
            NULL,
            NULL,
            NULL,
            NULL
        );
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#12 | INSERT AVAILABLE ACCOUNT ROWS
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            A.SortOrder,
            ''ACCOUNT'',
            A.AccountName,

            ' + @YearAmountExpressions + N',

            COALESCE
            (
                SUM(COALESCE(D.PAY_DAY, 0)),
                0
            ) AS [Total Amount],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.Paid LIKE N''%InvPaid%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid#],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.PaidnFullyDeduct
                             LIKE N''%PaidnDeducted%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [Paid & Fully Deduct],

            COALESCE
            (
                SUM
                (
                    CASE
                        WHEN D.RetailLinkStatus
                             LIKE N''%NoRetailLink%''
                        THEN COALESCE(D.PAY_DAY, 0)
                        ELSE 0
                    END
                ),
                0
            ) AS [RetailLinkStatus],

            SYSDATETIME()

        FROM #Accounts AS A

        INNER JOIN #AllInvoiceData AS D
            ON D.AccountCode = A.AccountCode

        GROUP BY
            A.SortOrder,
            A.AccountCode,
            A.AccountName;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#13 | INSERT FINAL TOTAL ROW
    ==========================================================================*/

    SET @SQL = N'
        INSERT INTO dbo.Invoices_Status
        (
            SortOrder,
            [Row Type],
            [Summary / Account Name],
            ' + @YearColumnList + N',
            [Total Amount],
            [Paid#],
            [Paid & Fully Deduct],
            [RetailLinkStatus],
            GeneratedDate
        )
        SELECT
            999,
            ''TOTAL'',
            ''Total'',

            ' + @YearTotalExpressions + N',

            COALESCE(SUM([Total Amount]), 0),

            COALESCE(SUM([Paid#]), 0),

            COALESCE(SUM([Paid & Fully Deduct]), 0),

            COALESCE(SUM([RetailLinkStatus]), 0),

            SYSDATETIME()

        FROM dbo.Invoices_Status

        WHERE [Row Type] = ''ACCOUNT'';
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#14 | DISPLAY SAVED REPORT
    ==========================================================================*/

    SET @SQL = N'
        SELECT
            [Row Type],

            [Summary / Account Name],

            ' + @YearColumnList + N',

            [Total Amount],

            [Paid#],

            [Paid & Fully Deduct],

            [RetailLinkStatus]

        FROM dbo.Invoices_Status

        ORDER BY SortOrder;
    ';

    EXEC sys.sp_executesql @SQL;


    /*==========================================================================
    |-- Q#15 | CLEANUP
    ==========================================================================*/

    DROP TABLE IF EXISTS #Years;
    DROP TABLE IF EXISTS #AllInvoiceData;
    DROP TABLE IF EXISTS #Accounts;
    DROP TABLE IF EXISTS #SourceConfig;

    RAISERROR(
        'Invoice Status completed successfully.',
        0,
        1
    ) WITH NOWAIT;
END;
GO


/*==============================================================================
|-- RUN PROCEDURE
==============================================================================*/

USE [WallMartSummary];
GO

-- EXEC dbo.sp_WallMartSummary_Invoice_Status;
GO


/*==============================================================================
|-- VIEW SAVED TABLE
==============================================================================*/

USE [WallMartSummary];
GO

IF OBJECT_ID(N'dbo.Invoices_Status', N'U') IS NOT NULL
BEGIN
    SELECT *
    FROM dbo.Invoices_Status
    ORDER BY SortOrder;
END
ELSE
BEGIN
    PRINT 'dbo.Invoices_Status was not generated because no valid source data was found.';
END;
GO