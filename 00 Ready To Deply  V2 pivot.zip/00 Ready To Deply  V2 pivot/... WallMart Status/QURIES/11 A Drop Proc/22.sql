USE [WallMartSummary];
GO

/*==============================================================================
    PROJECT       : WALMART SUMMARY
    PROCEDURE     : dbo.sp_WallMartSummary_Drop_Report_Tables
    VERSION       : V-02
    UPDATED ON    : 2026-08-01
    DESCRIPTION   : Truncate Walmart summary and report tables if they exist

    RUN COMMAND:
        EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_Drop_Report_Tables
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @TruncatedTables INT = 0;

    RAISERROR(
        'Walmart table cleanup started...',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#01 | TRUNCATE FINAL REPORT TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.Invoices_Status', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.Invoices_Status;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.Invoices_Status';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.Invoices_Status';
    END;


    IF OBJECT_ID('dbo.DBs_Status', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.DBs_Status;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.DBs_Status';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.DBs_Status';
    END;


    /*==========================================================================
    |-- Q#02 | TRUNCATE WC9085 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WC9085_Invoices', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WC9085_Invoices;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WC9085_Invoices';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WC9085_Invoices';
    END;


    IF OBJECT_ID('dbo.WC9085_DBs', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WC9085_DBs;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WC9085_DBs';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WC9085_DBs';
    END;


    /*==========================================================================
    |-- Q#03 | TRUNCATE WA9085 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WA9085_Invoices', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WA9085_Invoices;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WA9085_Invoices';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WA9085_Invoices';
    END;


    IF OBJECT_ID('dbo.WA9085_DBs', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WA9085_DBs;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WA9085_DBs';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WA9085_DBs';
    END;


    /*==========================================================================
    |-- Q#04 | TRUNCATE SA9200 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.SA9200_Invoices', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.SA9200_Invoices;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.SA9200_Invoices';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.SA9200_Invoices';
    END;


    IF OBJECT_ID('dbo.SA9200_DBs', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.SA9200_DBs;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.SA9200_DBs';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.SA9200_DBs';
    END;


    /*==========================================================================
    |-- Q#05 | TRUNCATE WM9263 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WM9263_Invoices', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WM9263_Invoices;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WM9263_Invoices';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WM9263_Invoices';
    END;


    IF OBJECT_ID('dbo.WM9263_DBs', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WM9263_DBs;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WM9263_DBs';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WM9263_DBs';
    END;


    /*==========================================================================
    |-- Q#06 | TRUNCATE MAIN STAGING TABLE
    ==========================================================================*/

    IF OBJECT_ID('dbo.WallMartSummary_Sheet', 'U') IS NOT NULL
    BEGIN
        TRUNCATE TABLE dbo.WallMartSummary_Sheet;

        SET @TruncatedTables += 1;

        PRINT 'Truncated: dbo.WallMartSummary_Sheet';
    END
    ELSE
    BEGIN
        PRINT 'Not found: dbo.WallMartSummary_Sheet';
    END;


    /*==========================================================================
    |-- Q#07 | COMPLETION MESSAGE
    ==========================================================================*/

    RAISERROR(
        'Walmart table cleanup completed. Total tables truncated: %d.',
        0,
        1,
        @TruncatedTables
    ) WITH NOWAIT;
END;
GO


/*==============================================================================
    EXECUTE PROCEDURE
==============================================================================*/

-- EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;
GO