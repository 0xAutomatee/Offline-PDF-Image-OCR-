USE [WallMartSummary];
GO

/*==============================================================================
    PROJECT       : WALMART SUMMARY
    PROCEDURE     : dbo.sp_WallMartSummary_Drop_Report_Tables
    VERSION       : V-01
    UPDATED ON    : 2026-08-01
    DESCRIPTION   : Drop Walmart summary and report tables if they exist

    RUN COMMAND:
        EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_WallMartSummary_Drop_Report_Tables
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @DroppedTables INT = 0;

    RAISERROR(
        'Walmart table cleanup started...',
        0,
        1
    ) WITH NOWAIT;


    /*==========================================================================
    |-- Q#01 | DROP FINAL REPORT TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.Invoices_Status', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.Invoices_Status;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.Invoices_Status';
    END
    ELSE
        PRINT 'Not found: dbo.Invoices_Status';


    IF OBJECT_ID('dbo.DBs_Status', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.DBs_Status;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.DBs_Status';
    END
    ELSE
        PRINT 'Not found: dbo.DBs_Status';


    /*==========================================================================
    |-- Q#02 | DROP WC9085 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WC9085_Invoices', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WC9085_Invoices;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WC9085_Invoices';
    END
    ELSE
        PRINT 'Not found: dbo.WC9085_Invoices';


    IF OBJECT_ID('dbo.WC9085_DBs', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WC9085_DBs;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WC9085_DBs';
    END
    ELSE
        PRINT 'Not found: dbo.WC9085_DBs';


    /*==========================================================================
    |-- Q#03 | DROP WA9085 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WA9085_Invoices', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WA9085_Invoices;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WA9085_Invoices';
    END
    ELSE
        PRINT 'Not found: dbo.WA9085_Invoices';


    IF OBJECT_ID('dbo.WA9085_DBs', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WA9085_DBs;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WA9085_DBs';
    END
    ELSE
        PRINT 'Not found: dbo.WA9085_DBs';


    /*==========================================================================
    |-- Q#04 | DROP SA9200 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.SA9200_Invoices', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.SA9200_Invoices;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.SA9200_Invoices';
    END
    ELSE
        PRINT 'Not found: dbo.SA9200_Invoices';


    IF OBJECT_ID('dbo.SA9200_DBs', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.SA9200_DBs;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.SA9200_DBs';
    END
    ELSE
        PRINT 'Not found: dbo.SA9200_DBs';


    /*==========================================================================
    |-- Q#05 | DROP WM9263 TABLES
    ==========================================================================*/

    IF OBJECT_ID('dbo.WM9263_Invoices', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WM9263_Invoices;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WM9263_Invoices';
    END
    ELSE
        PRINT 'Not found: dbo.WM9263_Invoices';


    IF OBJECT_ID('dbo.WM9263_DBs', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WM9263_DBs;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WM9263_DBs';
    END
    ELSE
        PRINT 'Not found: dbo.WM9263_DBs';


    /*==========================================================================
    |-- Q#06 | DROP MAIN STAGING TABLE
    ==========================================================================*/

    IF OBJECT_ID('dbo.WallMartSummary_Sheet', 'U') IS NOT NULL
    BEGIN
        DROP TABLE dbo.WallMartSummary_Sheet;
        SET @DroppedTables += 1;
        PRINT 'Dropped: dbo.WallMartSummary_Sheet';
    END
    ELSE
        PRINT 'Not found: dbo.WallMartSummary_Sheet';


    /*==========================================================================
    |-- Q#07 | COMPLETION MESSAGE
    ==========================================================================*/

    RAISERROR(
        'Walmart table cleanup completed. Total tables dropped: %d.',
        0,
        1,
        @DroppedTables
    ) WITH NOWAIT;
END;
GO


/*==============================================================================
    EXECUTE PROCEDURE
==============================================================================*/

-- EXEC dbo.sp_WallMartSummary_Drop_Report_Tables;
GO