USE [WallMartSummary];
GO

/*==============================================================================
|
|  PROJECT
|  `-- WALLMART SUMMARY
|
|  REPORT
|  `-- WALMART OPEN AGING (DB'S) STATUS SUMMARY
|
|  PROCEDURE
|  `-- dbo.sp_WallMartSummary_gen_DBs_Status
|
|  QUERY VERSION
|  `-- V-14
|
|  SOURCE
|  `-- dbo.WallMartSummary_Sheet
|
|  TARGET
|  `-- dbo.DBs_Status
|
|  YEAR COLUMNS
|  `-- Generated dynamically from DISTINCT InvYear
|
|  TOTAL AMOUNT
|  `-- SUM(pay_day) by Account + Reason
|
|  WRITE-UP SENT
|  `-- SUM(pay_day) where WriteStatus LIKE '%Write-up Sent%'
|
==============================================================================*/


/*==============================================================================
|-- STEP 01
|   `-- DROP OLD PROCEDURE
==============================================================================*/

DROP PROCEDURE IF EXISTS dbo.sp_WallMartSummary_gen_DBs_Status;
GO


/*==============================================================================
|-- STEP 02
|   `-- CREATE V-14 PROCEDURE
==============================================================================*/

CREATE PROCEDURE dbo.sp_WallMartSummary_gen_DBs_Status
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY

        /*======================================================================
        |-- Q#01
        |   `-- START PROCEDURE
        ======================================================================*/

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

        RAISERROR('PROJECT       : WALLMART SUMMARY', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'PROCEDURE     : dbo.sp_WallMartSummary_gen_DBs_Status',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('QUERY VERSION : V-14', 0, 1)
        WITH NOWAIT;

        RAISERROR('SOURCE TABLE  : dbo.WallMartSummary_Sheet', 0, 1)
        WITH NOWAIT;

        RAISERROR('TARGET TABLE  : dbo.DBs_Status', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'WRITE-UP RULE : SUM(pay_day) WHERE WriteStatus LIKE %%Write-up Sent%%',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;


        /*======================================================================
        |-- Q#02
        |   `-- VALIDATE SOURCE TABLE
        ======================================================================*/

        IF OBJECT_ID('dbo.WallMartSummary_Sheet', 'U') IS NULL
        BEGIN
            THROW 50001,
                  'Required table dbo.WallMartSummary_Sheet was not found.',
                  1;
        END;

        RAISERROR(
            'Q#02 completed: Source table found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#03
        |   `-- VALIDATE REQUIRED SOURCE COLUMNS
        ======================================================================*/

        DECLARE @MissingColumns NVARCHAR(MAX);
        DECLARE @ErrorMessage   NVARCHAR(2048);

        ;WITH RequiredColumns AS
        (
            SELECT Column_Name
            FROM
            (
                VALUES
                    ('acct'),
                    ('order'),
                    ('InvYear'),
                    ('pay_day'),
                    ('ref_type'),
                    ('WriteStatus')
            ) AS C(Column_Name)
        )
        SELECT
            @MissingColumns =
                STRING_AGG
                (
                    QUOTENAME(R.Column_Name),
                    ', '
                )
        FROM RequiredColumns AS R
        WHERE COL_LENGTH
              (
                  'dbo.WallMartSummary_Sheet',
                  R.Column_Name
              ) IS NULL;

        IF @MissingColumns IS NOT NULL
        BEGIN
            SET @ErrorMessage =
                N'Missing columns in dbo.WallMartSummary_Sheet: '
                + @MissingColumns;

            THROW 50002,
                  @ErrorMessage,
                  1;
        END;

        RAISERROR(
            'Q#03 completed: Required source columns found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#04
        |   `-- PREPARE ACCOUNT SETTINGS
        ======================================================================*/

        DROP TABLE IF EXISTS #Accounts;

        CREATE TABLE #Accounts
        (
            Account_Order INT           NOT NULL,
            Account_Code  NVARCHAR(50)  NOT NULL,
            Account_Title NVARCHAR(300) NOT NULL
        );

        INSERT INTO #Accounts
        (
            Account_Order,
            Account_Code,
            Account_Title
        )
        VALUES
            (
                1,
                N'WC9085',
                N'WC9085 - WAL-MART CANADA, INC. (Open DB''s)'
            ),
            (
                2,
                N'WA9085',
                N'WA9085 - WAL-MART STORE, INC. (Open DB''s)'
            ),
            (
                3,
                N'SA9200',
                N'SA9200 - SAM''S CLUB (Open DB''s)'
            );

        PRINT CONCAT(
            'Q#04 completed: Account settings inserted = ',
            @@ROWCOUNT
        );


        /*======================================================================
        |-- Q#05
        |   `-- PREPARE CLEAN SOURCE DATA
        ======================================================================*/

        DROP TABLE IF EXISTS #DB_Source;

        SELECT
            A.Account_Order,
            A.Account_Code,
            A.Account_Title,

            Reason =
                COALESCE
                (
                    NULLIF
                    (
                        LTRIM(RTRIM(CONVERT(NVARCHAR(300), S.[order]))),
                        ''
                    ),
                    N'NO REASON'
                ),

            InvYear =
                TRY_CONVERT
                (
                    INT,
                    S.InvYear
                ),

            Amount =
                V.CleanAmount,

            WriteUpSent =
                CASE
                    WHEN S.WriteStatus IS NOT NULL
                     AND LTRIM
                         (
                             RTRIM
                             (
                                 CONVERT
                                 (
                                     NVARCHAR(4000),
                                     S.WriteStatus
                                 )
                             )
                         ) LIKE N'%Write-up Sent%'
                        THEN V.CleanAmount
                    ELSE CAST(0.00 AS DECIMAL(18,2))
                END

        INTO #DB_Source

        FROM dbo.WallMartSummary_Sheet AS S

        INNER JOIN #Accounts AS A
            ON A.Account_Code =
               LTRIM
               (
                   RTRIM
                   (
                       CONVERT
                       (
                           NVARCHAR(50),
                           S.acct
                       )
                   )
               )

        CROSS APPLY
        (
            SELECT
                CleanAmount =
                    ISNULL
                    (
                        TRY_CONVERT
                        (
                            DECIMAL(18,2),

                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE
                                        (
                                            LTRIM
                                            (
                                                RTRIM
                                                (
                                                    CONVERT
                                                    (
                                                        NVARCHAR(100),
                                                        S.pay_day
                                                    )
                                                )
                                            ),
                                            '$',
                                            ''
                                        ),
                                        ',',
                                        ''
                                    ),
                                    '(',
                                    '-'
                                ),
                                ')',
                                ''
                            )
                        ),
                        0.00
                    )
        ) AS V

        WHERE UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          CONVERT
                          (
                              NVARCHAR(50),
                              S.ref_type
                          )
                      )
                  )
              ) = 'DB'

          AND TRY_CONVERT(INT, S.InvYear) IS NOT NULL

          AND S.[order] IS NOT NULL

          AND LTRIM
              (
                  RTRIM
                  (
                      CONVERT
                      (
                          NVARCHAR(300),
                          S.[order]
                      )
                  )
              ) <> '';

        DECLARE @SourceRows INT = @@ROWCOUNT;

        PRINT CONCAT(
            'Q#05 completed: Clean source rows = ',
            @SourceRows
        );


        /*======================================================================
        |-- Q#06
        |   `-- VALIDATE CLEAN SOURCE DATA WITHOUT STOPPING PROCEDURE
        ======================================================================*/

        DECLARE @HasValidDBSource BIT = 0;

        IF EXISTS
        (
            SELECT 1
            FROM #DB_Source
        )
        BEGIN
            SET @HasValidDBSource = 1;

            RAISERROR(
                'Q#06 completed: Valid DB source data found.',
                0,
                1
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN
            SET @HasValidDBSource = 0;

            RAISERROR(
                'Q#06 skipped: No valid DB source rows were found.',
                10,
                1
            ) WITH NOWAIT;

            RAISERROR(
                'Q#06 info: dbo.DBs_Status generation skipped; procedure will continue.',
                10,
                1
            ) WITH NOWAIT;
        END;


        /*======================================================================
        |-- Q#06B
        |   `-- RUN DB REPORT ONLY WHEN VALID DB SOURCE EXISTS
        ======================================================================*/

        IF @HasValidDBSource = 1
        BEGIN


        /*======================================================================
        |-- Q#07
        |   `-- PREVIEW WRITE-UP SOURCE DATA
        ======================================================================*/

        SELECT
            Account_Code,
            Reason,
            InvYear,

            Total_Amount =
                CAST
                (
                    SUM(Amount)
                    AS DECIMAL(18,2)
                ),

            [Write-up Sent] =
                CAST
                (
                    SUM(WriteUpSent)
                    AS DECIMAL(18,2)
                )

        FROM #DB_Source

        GROUP BY
            Account_Code,
            Reason,
            InvYear

        ORDER BY
            Account_Code,
            Reason,
            InvYear;

        RAISERROR(
            'Q#07 completed: Amount and Write-up preview generated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#08
        |   `-- DECLARE DYNAMIC VARIABLES
        ======================================================================*/

        DECLARE @CreateYearColumns     NVARCHAR(MAX);
        DECLARE @SelectYearColumns     NVARCHAR(MAX);
        DECLARE @HeaderYearValues      NVARCHAR(MAX);
        DECLARE @NullYearValues        NVARCHAR(MAX);
        DECLARE @ReasonSummaryColumns  NVARCHAR(MAX);
        DECLARE @ReasonYearValues      NVARCHAR(MAX);
        DECLARE @TotalYearValues       NVARCHAR(MAX);

        DECLARE @CreateTableSQL        NVARCHAR(MAX);
        DECLARE @ReportSQL             NVARCHAR(MAX);
        DECLARE @DisplaySQL            NVARCHAR(MAX);


        /*======================================================================
        |-- Q#09
        |   `-- BUILD DYNAMIC YEAR DEFINITIONS
        ======================================================================*/

        SELECT
            @CreateYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        + N' NVARCHAR(100) NULL'
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;

        PRINT CONCAT(
            'Q#09 completed: Dynamic year definitions = ',
            @CreateYearColumns
        );


        /*======================================================================
        |-- Q#10
        |   `-- BUILD DYNAMIC YEAR COLUMN LIST
        ======================================================================*/

        SELECT
            @SelectYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;

        PRINT CONCAT(
            'Q#10 completed: Dynamic year columns = ',
            @SelectYearColumns
        );


        /*======================================================================
        |-- Q#11
        |   `-- BUILD DYNAMIC HEADER VALUES
        ======================================================================*/

        SELECT
            @HeaderYearValues =
                STRING_AGG
                (
                    CAST
                    (
                        N'N'''
                        + CONVERT(NVARCHAR(10), Y.InvYear)
                        + N''''
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#12
        |   `-- BUILD DYNAMIC NULL VALUES
        ======================================================================*/

        SELECT
            @NullYearValues =
                STRING_AGG
                (
                    CAST
                    (
                        N'NULL'
                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#13
        |   `-- BUILD DYNAMIC REASON/YEAR SUM EXPRESSIONS
        ======================================================================*/

        SELECT
            @ReasonSummaryColumns =
                STRING_AGG
                (
                    CAST
                    (
                          N'SUM(CASE WHEN InvYear = '
                        + CONVERT(NVARCHAR(10), Y.InvYear)
                        + N' THEN Amount ELSE 0.00 END) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#14
        |   `-- BUILD DYNAMIC REASON YEAR VALUES
        ======================================================================*/

        SELECT
            @ReasonYearValues =
                STRING_AGG
                (
                    CAST
                    (
                          N'CONVERT(NVARCHAR(100), '
                        + N'CAST(ISNULL(R.'
                        + QUOTENAME(Y.InvYear)
                        + N', 0.00) AS DECIMAL(18,2)))'

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#15
        |   `-- BUILD DYNAMIC TOTAL YEAR VALUES
        ======================================================================*/

        SELECT
            @TotalYearValues =
                STRING_AGG
                (
                    CAST
                    (
                          N'CONVERT(NVARCHAR(100), '
                        + N'CAST(ISNULL(SUM(R.'
                        + QUOTENAME(Y.InvYear)
                        + N'), 0.00) AS DECIMAL(18,2)))'

                        AS NVARCHAR(MAX)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |-- Q#16
        |   `-- VALIDATE DYNAMIC VALUES
        ======================================================================*/

        IF NULLIF(@CreateYearColumns, '') IS NULL
           OR NULLIF(@SelectYearColumns, '') IS NULL
           OR NULLIF(@HeaderYearValues, '') IS NULL
           OR NULLIF(@NullYearValues, '') IS NULL
           OR NULLIF(@ReasonSummaryColumns, '') IS NULL
           OR NULLIF(@ReasonYearValues, '') IS NULL
           OR NULLIF(@TotalYearValues, '') IS NULL
        BEGIN
            THROW 50004,
                  'Dynamic InvYear columns could not be generated.',
                  1;
        END;

        RAISERROR(
            'Q#16 completed: Dynamic expressions validated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#17
        |   `-- RECREATE TARGET TABLE IN SEPARATE BATCH
        ======================================================================*/

        SET @CreateTableSQL = N'
        DROP TABLE IF EXISTS dbo.DBs_Status;

        CREATE TABLE dbo.DBs_Status
        (
            Report_Order      INT            NOT NULL,
            Account_Order     INT            NOT NULL,
            Detail_Order      INT            NOT NULL,
            Row_Type          NVARCHAR(50)   NOT NULL,
            Account_Code      NVARCHAR(50)   NULL,
            [Report Line]     NVARCHAR(300)  NULL,

            ' + @CreateYearColumns + N',

            [Total Amount]    NVARCHAR(100)  NULL,
            [Write-up Sent]   NVARCHAR(100)  NULL
        );

        CREATE NONCLUSTERED INDEX IX_DBs_Status_ReportOrder
        ON dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order
        );
        ';

        RAISERROR(
            'Q#17 started: Recreating dbo.DBs_Status...',
            0,
            1
        ) WITH NOWAIT;

        EXEC sys.sp_executesql @CreateTableSQL;

        RAISERROR(
            'Q#17 completed: dbo.DBs_Status recreated.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#18
        |   `-- BUILD AND INSERT COMPLETE REPORT
        ======================================================================*/

        SET @ReportSQL = N'

        /*======================================================================
        |-- DQ#01
        |   `-- CREATE REUSABLE REASON SUMMARY
        ======================================================================*/

        DROP TABLE IF EXISTS #ReasonSummary;

        SELECT
            Account_Order,
            Account_Code,
            Account_Title,
            Reason,

            ' + @ReasonSummaryColumns + N',

            [Total Amount] =
                SUM(Amount),

            [Write-up Sent] =
                SUM(WriteUpSent)

        INTO #ReasonSummary

        FROM #DB_Source

        GROUP BY
            Account_Order,
            Account_Code,
            Account_Title,
            Reason;


        /*======================================================================
        |-- DQ#02
        |   `-- INSERT REPORT TITLE
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        VALUES
        (
            10,
            0,
            0,
            N''REPORT TITLE'',
            NULL,
            N''WALMART OPEN AGING (DB''''S) STATUS SUMMARY'',
            ' + @NullYearValues + N',
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#03
        |   `-- TWO NULL ROWS AFTER REPORT TITLE
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        VALUES
        (
            11,
            0,
            1,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL
        ),
        (
            12,
            0,
            2,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#04
        |   `-- INSERT SUMMARY HEADER
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        VALUES
        (
            20,
            0,
            0,
            N''COLUMN HEADER'',
            NULL,
            N''Summary'',
            ' + @HeaderYearValues + N',
            N''Total Amount'',
            N''Write-up Sent''
        );


        /*======================================================================
        |-- DQ#05
        |   `-- INSERT ALL ACCOUNTS TOTAL
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            21,
            0,
            0,
            N''ALL ACCOUNTS TOTAL'',
            NULL,
            N''All Accounts Total'',

            ' + @TotalYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Total Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Write-up Sent]), 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R;


        /*======================================================================
        |-- DQ#06
        |   `-- TWO NULL ROWS AFTER ALL ACCOUNTS TOTAL
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        VALUES
        (
            22,
            0,
            1,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL
        ),
        (
            23,
            0,
            2,
            N''BLANK ROW'',
            NULL,
            NULL,
            ' + @NullYearValues + N',
            NULL,
            NULL
        );


        /*======================================================================
        |-- DQ#07
        |   `-- INSERT ACCOUNT TITLES
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            A.Account_Order * 100,
            A.Account_Order,
            0,
            N''ACCOUNT TITLE'',
            A.Account_Code,
            A.Account_Title,

            ' + @NullYearValues + N',

            NULL,
            NULL

        FROM #Accounts AS A;


        /*======================================================================
        |-- DQ#08
        |   `-- INSERT ACCOUNT COLUMN HEADERS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            (A.Account_Order * 100) + 1,
            A.Account_Order,
            1,
            N''COLUMN HEADER'',
            A.Account_Code,
            N''Reason'',

            ' + @HeaderYearValues + N',

            N''Total Amount'',
            N''Write-up Sent''

        FROM #Accounts AS A;


        /*======================================================================
        |-- DQ#09
        |   `-- INSERT REASON ROWS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            (R.Account_Order * 100) + 2,

            R.Account_Order,

            ROW_NUMBER() OVER
            (
                PARTITION BY R.Account_Order
                ORDER BY R.Reason
            ) + 1,

            N''REASON'',
            R.Account_Code,
            R.Reason,

            ' + @ReasonYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(R.[Total Amount], 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(R.[Write-up Sent], 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R;


        /*======================================================================
        |-- DQ#10
        |   `-- INSERT ACCOUNT TOTALS
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            (R.Account_Order * 100) + 90,
            R.Account_Order,
            999990,
            N''ACCOUNT TOTAL'',
            R.Account_Code,
            N''ACCOUNT TOTAL'',

            ' + @TotalYearValues + N',

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Total Amount]), 0.00)
                    AS DECIMAL(18,2)
                )
            ),

            CONVERT
            (
                NVARCHAR(100),
                CAST
                (
                    ISNULL(SUM(R.[Write-up Sent]), 0.00)
                    AS DECIMAL(18,2)
                )
            )

        FROM #ReasonSummary AS R

        GROUP BY
            R.Account_Order,
            R.Account_Code;


        /*======================================================================
        |-- DQ#11
        |   `-- TWO NULL ROWS AFTER EACH ACCOUNT
        ======================================================================*/

        INSERT INTO dbo.DBs_Status
        (
            Report_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @SelectYearColumns + N',
            [Total Amount],
            [Write-up Sent]
        )
        SELECT
            (A.Account_Order * 100) + 91,
            A.Account_Order,
            999991,
            N''BLANK ROW'',
            A.Account_Code,
            NULL,

            ' + @NullYearValues + N',

            NULL,
            NULL

        FROM #Accounts AS A

        UNION ALL

        SELECT
            (A.Account_Order * 100) + 92,
            A.Account_Order,
            999992,
            N''BLANK ROW'',
            A.Account_Code,
            NULL,

            ' + @NullYearValues + N',

            NULL,
            NULL

        FROM #Accounts AS A;
        ';

        RAISERROR(
            'Q#18 started: Inserting report and Write-up values...',
            0,
            1
        ) WITH NOWAIT;

        EXEC sys.sp_executesql @ReportSQL;

        RAISERROR(
            'Q#18 completed: Report rows inserted.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |-- Q#19
        |   `-- COUNT SAVED ROWS
        ======================================================================*/

        DECLARE @SavedRows INT;

        SELECT
            @SavedRows =
                COUNT(*)
        FROM dbo.DBs_Status;

        PRINT CONCAT(
            'Q#19 completed: dbo.DBs_Status saved rows = ',
            @SavedRows
        );


/*======================================================================
|-- Q#20
|   `-- SAVE FINAL ORDERED REPORT INTO dbo.DBs_Status
======================================================================*/

RAISERROR(
    'Q#20 started: Saving final ordered report into dbo.DBs_Status...',
    0,
    1
) WITH NOWAIT;


/*======================================================================
|-- Q#20.01
|   `-- SAVE TECHNICAL REPORT INTO dbo.DBs_Status_All
======================================================================*/

SET @DisplaySQL = N'
DROP TABLE IF EXISTS dbo.DBs_Status_All;

SELECT
    Report_Order,
    Account_Order,
    Detail_Order,
    Row_Type,
    Account_Code,
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Write-up Sent]

INTO dbo.DBs_Status_All

FROM dbo.DBs_Status;

CREATE CLUSTERED INDEX CX_DBs_Status_All_ReportOrder
ON dbo.DBs_Status_All
(
    Report_Order,
    Account_Order,
    Detail_Order
);
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.02
|   `-- DROP OLD FINAL DISPLAY TABLE
======================================================================*/

SET @DisplaySQL = N'
DROP TABLE IF EXISTS dbo.DBs_Status;
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.03
|   `-- CREATE FINAL CLEAN REPORT TABLE
======================================================================*/

SET @DisplaySQL = N'
CREATE TABLE dbo.DBs_Status
(
    Report_Sequence  INT            NOT NULL,
    [Report Line]    NVARCHAR(300)  NULL,

    ' + @CreateYearColumns + N',

    [Total Amount]   NVARCHAR(100)  NULL,
    [Write-up Sent]  NVARCHAR(100)  NULL,

    CONSTRAINT PK_DBs_Status
        PRIMARY KEY CLUSTERED
        (
            Report_Sequence
        )
);
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.04
|   `-- INSERT REPORT IN REQUIRED SEQUENCE
======================================================================*/

SET @DisplaySQL = N'
INSERT INTO dbo.DBs_Status
(
    Report_Sequence,
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Write-up Sent]
)
SELECT
    Report_Sequence =
        ROW_NUMBER() OVER
        (
            ORDER BY
                Report_Order,
                Account_Order,
                Detail_Order
        ),

    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Write-up Sent]

FROM dbo.DBs_Status_All;
';

EXEC sys.sp_executesql @DisplaySQL;


/*======================================================================
|-- Q#20.05
|   `-- COUNT FINAL SAVED ROWS
======================================================================*/

DECLARE @FinalDBsStatusRows INT;

SELECT
    @FinalDBsStatusRows = COUNT(*)
FROM dbo.DBs_Status;

PRINT CONCAT(
    'Q#20 info: Final dbo.DBs_Status rows = ',
    @FinalDBsStatusRows
);


/*======================================================================
|-- Q#20.06
|   `-- DISPLAY FINAL CLEAN REPORT
======================================================================*/

SET @DisplaySQL = N'
SELECT
    [Report Line],
    ' + @SelectYearColumns + N',
    [Total Amount],
    [Write-up Sent]

FROM dbo.DBs_Status

ORDER BY
    Report_Sequence;
';

EXEC sys.sp_executesql @DisplaySQL;

RAISERROR(
    'Q#20 completed: Final ordered report saved in dbo.DBs_Status.',
    0,
    1
) WITH NOWAIT;

        END
        ELSE
        BEGIN
            RAISERROR(
                'Q#06B skipped: DB report tables were not generated because no valid DB source data was found.',
                10,
                1
            ) WITH NOWAIT;
        END;


        /*======================================================================
        |-- Q#21
        |   `-- COMPLETE PROCEDURE
        ======================================================================*/

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

        RAISERROR(
            'V-14 completed successfully.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Write-up Sent calculated from WriteStatus.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR(
            'Technical and dynamic year columns saved in dbo.DBs_Status.',
            0,
            1
        ) WITH NOWAIT;

        RAISERROR('============================================================', 0, 1)
        WITH NOWAIT;

    END TRY

    BEGIN CATCH

        DECLARE @CatchErrorNumber    INT;
        DECLARE @CatchErrorSeverity  INT;
        DECLARE @CatchErrorState     INT;
        DECLARE @CatchErrorLine      INT;
        DECLARE @CatchErrorProcedure NVARCHAR(300);
        DECLARE @CatchErrorMessage   NVARCHAR(4000);

        SET @CatchErrorNumber =
            ERROR_NUMBER();

        SET @CatchErrorSeverity =
            ERROR_SEVERITY();

        SET @CatchErrorState =
            ERROR_STATE();

        SET @CatchErrorLine =
            ERROR_LINE();

        SET @CatchErrorProcedure =
            ERROR_PROCEDURE();

        SET @CatchErrorMessage =
            ERROR_MESSAGE();

        PRINT '============================================================';
        PRINT 'V-14 DBs_Status generation failed.';

        PRINT CONCAT(
            'Error Number    : ',
            @CatchErrorNumber
        );

        PRINT CONCAT(
            'Error Severity  : ',
            @CatchErrorSeverity
        );

        PRINT CONCAT(
            'Error State     : ',
            @CatchErrorState
        );

        PRINT CONCAT(
            'Error Procedure : ',
            ISNULL(@CatchErrorProcedure, 'Dynamic SQL')
        );

        PRINT CONCAT(
            'Error Line      : ',
            @CatchErrorLine
        );

        PRINT CONCAT(
            'Error Message   : ',
            @CatchErrorMessage
        );

        PRINT '============================================================';

        THROW;

    END CATCH;
END;
GO


/*==============================================================================
|-- STEP 03
|   `-- RUN V-14 PROCEDURE
==============================================================================*/

-- EXEC dbo.sp_WallMartSummary_gen_DBs_Status;
GO