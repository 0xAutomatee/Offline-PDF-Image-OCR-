/*==============================================================================
|
|  PROJECT
|  `-- WALLMARTS
|
|  PROCEDURE
|  `-- dbo.sp_WallMarts_gen_DBs_Status
|
|  TARGET TABLE
|  `-- dbo.DBs_Status
|
|  SOURCE TABLE
|  `-- dbo.step_01_inquiry_rows
|
|  REPORT
|  `-- WALMART OPEN AGING (DB'S) STATUS SUMMARY
|
|  ACCOUNTS
|  |-- WC9085 - WAL-MART CANADA, INC.
|  |-- WA9085 - WAL-MART STORE, INC.
|  `-- SA9200 - SAM'S CLUB
|
|  STRUCTURE
|  |-- Overall report title
|  |-- All Accounts Total
|  |
|  |-- Account title
|  |-- Column-label row
|  |-- Reason rows
|  `-- Account total
|
|  DYNAMIC COLUMNS
|  `-- DISTINCT InvYear
|
|  AMOUNT
|  `-- SUM(pay_day) by account, reason and InvYear
|
==============================================================================*/

CREATE OR ALTER PROCEDURE dbo.sp_WallMarts_gen_DBs_Status
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY

        /*======================================================================
        |
        |  Q#01
        |  `-- START PROCEDURE
        |
        ======================================================================*/

        RAISERROR(
            'Q#01 started: Generating dbo.DBs_Status...',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |
        |  Q#02
        |  `-- CHECK SOURCE TABLE
        |
        ======================================================================*/

        IF OBJECT_ID('dbo.step_01_inquiry_rows', 'U') IS NULL
        BEGIN
            THROW 50001,
                  'Required table dbo.step_01_inquiry_rows was not found.',
                  1;
        END;

        RAISERROR(
            'Q#02 completed: Source table found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |
        |  Q#03
        |  `-- CHECK REQUIRED SOURCE COLUMNS
        |
        ======================================================================*/

        DECLARE @MissingColumns NVARCHAR(MAX);
        DECLARE @ErrorMessage   NVARCHAR(2048);

        ;WITH RequiredColumns AS
        (
            SELECT ColumnName
            FROM
            (
                VALUES
                    ('acct'),
                    ('order'),
                    ('InvYear'),
                    ('pay_day'),
                    ('ref_type')
            ) AS C(ColumnName)
        )
        SELECT
            @MissingColumns =
                STRING_AGG
                (
                    QUOTENAME(R.ColumnName),
                    ', '
                )
        FROM RequiredColumns AS R
        WHERE COL_LENGTH
              (
                  'dbo.step_01_inquiry_rows',
                  R.ColumnName
              ) IS NULL;

        IF @MissingColumns IS NOT NULL
        BEGIN
            SET @ErrorMessage =
                N'Missing required columns in dbo.step_01_inquiry_rows: '
                + @MissingColumns;

            THROW 50002,
                  @ErrorMessage,
                  1;
        END;

        RAISERROR(
            'Q#03 completed: Required columns found.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |
        |  Q#04
        |  `-- PREPARE ACCOUNT SETTINGS
        |
        ======================================================================*/

        DROP TABLE IF EXISTS #Account_Settings;

        CREATE TABLE #Account_Settings
        (
            Account_Order INT           NOT NULL,
            Account_Code  NVARCHAR(50)  NOT NULL,
            Account_Title NVARCHAR(300) NOT NULL
        );

        INSERT INTO #Account_Settings
        (
            Account_Order,
            Account_Code,
            Account_Title
        )
        VALUES
            (
                1,
                N'WC9085',
                N'WC9085 - WAL-MART CANADA, INC. (Open DB''s)'
            ),
            (
                2,
                N'WA9085',
                N'WA9085 - WAL-MART STORE, INC. (Open DB''s)'
            ),
            (
                3,
                N'SA9200',
                N'SA9200 - SAM''S CLUB (Open DB''s)'
            );

        RAISERROR(
            'Q#04 completed: Account settings prepared.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |
        |  Q#05
        |  `-- PREPARE CLEAN DB SOURCE
        |
        ======================================================================*/

        DROP TABLE IF EXISTS #DB_Source;

        SELECT
            A.Account_Order,

            Account_Code =
                A.Account_Code,

            Account_Title =
                A.Account_Title,

            DB_Reason =
                COALESCE
                (
                    NULLIF(LTRIM(RTRIM(S.[order])), ''),
                    N'NO REASON'
                ),

            InvYear =
                TRY_CONVERT(INT, S.InvYear),

            DB_Amount =
                ISNULL
                (
                    TRY_CONVERT
                    (
                        DECIMAL(18,2),

                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        LTRIM(RTRIM(S.pay_day)),
                                        '$',
                                        ''
                                    ),
                                    ',',
                                    ''
                                ),
                                '(',
                                '-'
                            ),
                            ')',
                            ''
                        )
                    ),
                    0.00
                ),

            Write_Up_Sent =
                CAST(0.00 AS DECIMAL(18,2))

        INTO #DB_Source

        FROM dbo.step_01_inquiry_rows AS S

        INNER JOIN #Account_Settings AS A
            ON A.Account_Code = LTRIM(RTRIM(S.acct))

        WHERE UPPER(LTRIM(RTRIM(S.ref_type))) = 'DB'
          AND TRY_CONVERT(INT, S.InvYear) IS NOT NULL
          AND S.[order] IS NOT NULL
          AND LTRIM(RTRIM(S.[order])) <> '';

        DECLARE @SourceRows INT = @@ROWCOUNT;

        RAISERROR(
            'Q#05 completed: Clean DB source prepared.',
            0,
            1
        ) WITH NOWAIT;

        PRINT CONCAT(
            'Q#05 rows prepared: ',
            @SourceRows
        );


        /*======================================================================
        |
        |  Q#06
        |  `-- STOP IF NO VALID SOURCE ROWS EXIST
        |
        ======================================================================*/

        IF NOT EXISTS
        (
            SELECT 1
            FROM #DB_Source
        )
        BEGIN
            THROW 50003,
                  'No valid DB rows were found for the configured accounts.',
                  1;
        END;


        /*======================================================================
        |
        |  Q#07
        |  `-- DECLARE DYNAMIC SQL VARIABLES
        |
        ======================================================================*/

        DECLARE @YearColumns             NVARCHAR(MAX);
        DECLARE @YearColumnsAsText       NVARCHAR(MAX);
        DECLARE @ReasonYearColumns       NVARCHAR(MAX);
        DECLARE @AccountTotalYearColumns NVARCHAR(MAX);
        DECLARE @TitleNullColumns        NVARCHAR(MAX);
        DECLARE @HeaderYearColumns       NVARCHAR(MAX);
        DECLARE @TotalExpression         NVARCHAR(MAX);
        DECLARE @SQL                     NVARCHAR(MAX);


        /*======================================================================
        |
        |  Q#08
        |  `-- BUILD DYNAMIC YEAR COLUMN LIST
        |
        |  EXAMPLE
        |  `-- [2022], [2023], [2024], [2025], [2026]
        |
        ======================================================================*/

        SELECT
            @YearColumns =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#09
        |  `-- BUILD FINAL YEAR SELECT LIST
        |
        ======================================================================*/

        SELECT
            @YearColumnsAsText =
                STRING_AGG
                (
                    CAST
                    (
                        QUOTENAME(Y.InvYear)
                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#10
        |  `-- BUILD REASON-ROW YEAR VALUES
        |
        ======================================================================*/

        SELECT
            @ReasonYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                          'CONVERT(NVARCHAR(100), '
                        + 'CAST(ISNULL('
                        + QUOTENAME(Y.InvYear)
                        + ', 0.00) AS DECIMAL(18,2))) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#11
        |  `-- BUILD ACCOUNT-TOTAL YEAR VALUES
        |
        ======================================================================*/

        SELECT
            @AccountTotalYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                          'CONVERT(NVARCHAR(100), '
                        + 'CAST(SUM(ISNULL('
                        + QUOTENAME(Y.InvYear)
                        + ', 0.00)) AS DECIMAL(18,2))) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#12
        |  `-- BUILD NULL YEAR CELLS FOR TITLE ROWS
        |
        ======================================================================*/

        SELECT
            @TitleNullColumns =
                STRING_AGG
                (
                    CAST
                    (
                          'CAST(NULL AS NVARCHAR(100)) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#13
        |  `-- BUILD YEAR LABEL CELLS
        |
        ======================================================================*/

        SELECT
            @HeaderYearColumns =
                STRING_AGG
                (
                    CAST
                    (
                          'CAST('''
                        + CONVERT(VARCHAR(10), Y.InvYear)
                        + ''' AS NVARCHAR(100)) AS '
                        + QUOTENAME(Y.InvYear)

                        AS NVARCHAR(MAX)
                    ),
                    ', '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#14
        |  `-- BUILD TOTAL-AMOUNT EXPRESSION
        |
        ======================================================================*/

        SELECT
            @TotalExpression =
                STRING_AGG
                (
                    CAST
                    (
                          'ISNULL('
                        + QUOTENAME(Y.InvYear)
                        + ', 0.00)'

                        AS NVARCHAR(MAX)
                    ),
                    ' + '
                )
                WITHIN GROUP
                (
                    ORDER BY Y.InvYear
                )
        FROM
        (
            SELECT DISTINCT
                InvYear
            FROM #DB_Source
        ) AS Y;


        /*======================================================================
        |
        |  Q#15
        |  `-- VALIDATE DYNAMIC SQL COMPONENTS
        |
        ======================================================================*/

        IF NULLIF(@YearColumns, '') IS NULL
           OR NULLIF(@ReasonYearColumns, '') IS NULL
           OR NULLIF(@AccountTotalYearColumns, '') IS NULL
           OR NULLIF(@TitleNullColumns, '') IS NULL
           OR NULLIF(@HeaderYearColumns, '') IS NULL
           OR NULLIF(@TotalExpression, '') IS NULL
        BEGIN
            THROW 50004,
                  'Dynamic DBs_Status columns could not be generated.',
                  1;
        END;


        /*======================================================================
        |
        |  Q#16
        |  `-- DROP OLD TARGET TABLE
        |
        ======================================================================*/

        IF OBJECT_ID('dbo.DBs_Status', 'U') IS NOT NULL
        BEGIN
            DROP TABLE dbo.DBs_Status;

            RAISERROR(
                'Q#16 completed: Old dbo.DBs_Status dropped.',
                0,
                1
            ) WITH NOWAIT;
        END
        ELSE
        BEGIN
            RAISERROR(
                'Q#16 completed: No old dbo.DBs_Status table found.',
                0,
                1
            ) WITH NOWAIT;
        END;


        /*======================================================================
        |
        |  Q#17
        |  `-- BUILD AND SAVE FINAL DB STATUS TABLE
        |
        ======================================================================*/

        SET @SQL = N'
        ;WITH Reason_Year_Summary AS
        (
            SELECT
                Account_Order,
                Account_Code,
                Account_Title,
                DB_Reason,
                InvYear,

                DB_Amount =
                    SUM(DB_Amount),

                Write_Up_Sent =
                    SUM(Write_Up_Sent)

            FROM #DB_Source

            GROUP BY
                Account_Order,
                Account_Code,
                Account_Title,
                DB_Reason,
                InvYear
        ),

        Pivot_Data AS
        (
            SELECT
                Account_Order,
                Account_Code,
                Account_Title,
                DB_Reason,
                ' + @YearColumns + N'

            FROM
            (
                SELECT
                    Account_Order,
                    Account_Code,
                    Account_Title,
                    DB_Reason,
                    InvYear,
                    DB_Amount

                FROM Reason_Year_Summary
            ) AS S

            PIVOT
            (
                SUM(DB_Amount)

                FOR InvYear IN
                (
                    ' + @YearColumns + N'
                )
            ) AS P
        ),

        Account_WriteUp AS
        (
            SELECT
                Account_Code,
                DB_Reason,

                Write_Up_Sent =
                    SUM(Write_Up_Sent)

            FROM Reason_Year_Summary

            GROUP BY
                Account_Code,
                DB_Reason
        ),

        Final_Dashboard AS
        (
            /*==================================================================
            |-- 01. REPORT TITLE
            ==================================================================*/

            SELECT
                Main_Order    = 0,
                Account_Order = 0,
                Detail_Order  = 0,

                Row_Type =
                    CAST(''REPORT TITLE'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(NULL AS NVARCHAR(50)),

                [Report Line] =
                    CAST
                    (
                        ''WALMART OPEN AGING (DB''''S) STATUS SUMMARY''
                        AS NVARCHAR(300)
                    ),

                ' + @TitleNullColumns + N',

                [Total Amount] =
                    CAST(NULL AS NVARCHAR(100)),

                [Write-up Sent] =
                    CAST(NULL AS NVARCHAR(100))


            UNION ALL


            /*==================================================================
            |-- 02. OVERALL LABEL ROW
            ==================================================================*/

            SELECT
                Main_Order    = 0,
                Account_Order = 0,
                Detail_Order  = 1,

                Row_Type =
                    CAST(''COLUMN HEADER'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(NULL AS NVARCHAR(50)),

                [Report Line] =
                    CAST(''Summary'' AS NVARCHAR(300)),

                ' + @HeaderYearColumns + N',

                [Total Amount] =
                    CAST(''Total Amount'' AS NVARCHAR(100)),

                [Write-up Sent] =
                    CAST(''Write-up Sent'' AS NVARCHAR(100))


            UNION ALL


            /*==================================================================
            |-- 03. ALL-ACCOUNTS TOTAL
            ==================================================================*/

            SELECT
                Main_Order    = 0,
                Account_Order = 0,
                Detail_Order  = 2,

                Row_Type =
                    CAST(''ALL ACCOUNTS TOTAL'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(NULL AS NVARCHAR(50)),

                [Report Line] =
                    CAST(''All Accounts Total'' AS NVARCHAR(300)),

                ' + @AccountTotalYearColumns + N',

                [Total Amount] =
                    CONVERT
                    (
                        NVARCHAR(100),

                        CAST
                        (
                            SUM
                            (
                                ' + @TotalExpression + N'
                            )
                            AS DECIMAL(18,2)
                        )
                    ),

                [Write-up Sent] =
                    CAST(''0.00'' AS NVARCHAR(100))

            FROM Pivot_Data


            UNION ALL


            /*==================================================================
            |-- 04. ACCOUNT TITLE ROWS
            ==================================================================*/

            SELECT DISTINCT
                Main_Order    = 1,
                P.Account_Order,
                Detail_Order  = 0,

                Row_Type =
                    CAST(''ACCOUNT TITLE'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(P.Account_Code AS NVARCHAR(50)),

                [Report Line] =
                    CAST(P.Account_Title AS NVARCHAR(300)),

                ' + @TitleNullColumns + N',

                [Total Amount] =
                    CAST(NULL AS NVARCHAR(100)),

                [Write-up Sent] =
                    CAST(NULL AS NVARCHAR(100))

            FROM Pivot_Data AS P


            UNION ALL


            /*==================================================================
            |-- 05. ACCOUNT COLUMN-LABEL ROWS
            ==================================================================*/

            SELECT DISTINCT
                Main_Order    = 1,
                P.Account_Order,
                Detail_Order  = 1,

                Row_Type =
                    CAST(''COLUMN HEADER'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(P.Account_Code AS NVARCHAR(50)),

                [Report Line] =
                    CAST(''Reason'' AS NVARCHAR(300)),

                ' + @HeaderYearColumns + N',

                [Total Amount] =
                    CAST(''Total Amount'' AS NVARCHAR(100)),

                [Write-up Sent] =
                    CAST(''Write-up Sent'' AS NVARCHAR(100))

            FROM Pivot_Data AS P


            UNION ALL


            /*==================================================================
            |-- 06. ACCOUNT REASON ROWS
            ==================================================================*/

            SELECT
                Main_Order    = 1,
                P.Account_Order,
                Detail_Order  = 2,

                Row_Type =
                    CAST(''REASON'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(P.Account_Code AS NVARCHAR(50)),

                [Report Line] =
                    CAST(P.DB_Reason AS NVARCHAR(300)),

                ' + @ReasonYearColumns + N',

                [Total Amount] =
                    CONVERT
                    (
                        NVARCHAR(100),

                        CAST
                        (
                            ' + @TotalExpression + N'
                            AS DECIMAL(18,2)
                        )
                    ),

                [Write-up Sent] =
                    CONVERT
                    (
                        NVARCHAR(100),

                        CAST
                        (
                            ISNULL(W.Write_Up_Sent, 0.00)
                            AS DECIMAL(18,2)
                        )
                    )

            FROM Pivot_Data AS P

            LEFT JOIN Account_WriteUp AS W
                ON W.Account_Code = P.Account_Code
               AND W.DB_Reason    = P.DB_Reason


            UNION ALL


            /*==================================================================
            |-- 07. ACCOUNT TOTAL ROWS
            ==================================================================*/

            SELECT
                Main_Order    = 1,
                P.Account_Order,
                Detail_Order  = 3,

                Row_Type =
                    CAST(''ACCOUNT TOTAL'' AS NVARCHAR(50)),

                Account_Code =
                    CAST(P.Account_Code AS NVARCHAR(50)),

                [Report Line] =
                    CAST(''ACCOUNT TOTAL'' AS NVARCHAR(300)),

                ' + @AccountTotalYearColumns + N',

                [Total Amount] =
                    CONVERT
                    (
                        NVARCHAR(100),

                        CAST
                        (
                            SUM
                            (
                                ' + @TotalExpression + N'
                            )
                            AS DECIMAL(18,2)
                        )
                    ),

                [Write-up Sent] =
                    CAST(''0.00'' AS NVARCHAR(100))

            FROM Pivot_Data AS P

            GROUP BY
                P.Account_Order,
                P.Account_Code
        )

        SELECT
            Main_Order,
            Account_Order,
            Detail_Order,
            Row_Type,
            Account_Code,
            [Report Line],
            ' + @YearColumnsAsText + N',
            [Total Amount],
            [Write-up Sent]

        INTO dbo.DBs_Status

        FROM Final_Dashboard;
        ';


        EXEC sys.sp_executesql @SQL;

        DECLARE @RowsCreated INT =
        (
            SELECT COUNT(*)
            FROM dbo.DBs_Status
        );

        PRINT CONCAT(
            'Q#17 completed: dbo.DBs_Status rows created = ',
            @RowsCreated
        );


        /*======================================================================
        |
        |  Q#18
        |  `-- CREATE REPORT-SORT INDEX
        |
        ======================================================================*/

        CREATE NONCLUSTERED INDEX IX_DBs_Status_ReportOrder
        ON dbo.DBs_Status
        (
            Main_Order,
            Account_Order,
            Detail_Order
        );

        RAISERROR(
            'Q#18 completed: Report-order index created.',
            0,
            1
        ) WITH NOWAIT;


        /*======================================================================
        |
        |  Q#19
        |  `-- DISPLAY FINAL DB STATUS TABLE
        |
        ======================================================================*/

        SELECT *
        FROM dbo.DBs_Status
        ORDER BY
            Main_Order,
            Account_Order,
            Detail_Order,

            CASE
                WHEN Row_Type = 'REASON' THEN 1
                WHEN Row_Type = 'ACCOUNT TOTAL' THEN 2
                ELSE 0
            END,

            [Report Line];

        RAISERROR(
            'Q#19 completed: DBs_Status report generated successfully.',
            0,
            1
        ) WITH NOWAIT;

    END TRY

    BEGIN CATCH

        DECLARE @CatchErrorNumber  INT            = ERROR_NUMBER();
        DECLARE @CatchErrorLine    INT            = ERROR_LINE();
        DECLARE @CatchErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();

        PRINT '============================================================';
        PRINT 'DBs_Status generation failed.';
        PRINT CONCAT('Error Number : ', @CatchErrorNumber);
        PRINT CONCAT('Error Line   : ', @CatchErrorLine);
        PRINT CONCAT('Error Message: ', @CatchErrorMessage);
        PRINT '============================================================';

        THROW;

    END CATCH;
END;
GO
--   EXEC dbo.sp_WallMarts_gen_DBs_Status;