/*==============================================================================
|
|  WALMART OPEN AGEING
|  `-- WC9085 OPEN DB STATUS TEMPLATE
|
|  REASON
|  `-- DISTINCT dbo.WC9085_DBs.[order]
|
|  WRITE-UP
|  `-- SUM(pay_day) GROUP BY [order]
|
==============================================================================*/

SET NOCOUNT ON;


/*==============================================================================
|-- Q#01
|   `-- Drop old dashboard template
==============================================================================*/

DROP TABLE IF EXISTS dbo.WC9085_DB_Status_Summary;


/*==============================================================================
|-- Q#02
|   `-- Create reason-wise zero-value template
==============================================================================*/

;WITH Reason_List AS
(
    SELECT DISTINCT
        DB_Reason =
            COALESCE
            (
                NULLIF(LTRIM(RTRIM(D.[order])), ''),
                'NO REASON'
            )
    FROM dbo.WC9085_DBs AS D
    WHERE UPPER(LTRIM(RTRIM(D.ref_type))) = 'DB'
),

WriteUp_Summary AS
(
    SELECT
        DB_Reason =
            COALESCE
            (
                NULLIF(LTRIM(RTRIM(D.[order])), ''),
                'NO REASON'
            ),

        Write_Up_DBs_Sent =
            SUM
            (
                ISNULL
                (
                    TRY_CONVERT
                    (
                        DECIMAL(18,2),
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        LTRIM(RTRIM(D.pay_day)),
                                        '$',
                                        ''
                                    ),
                                    ',',
                                    ''
                                ),
                                '(',
                                '-'
                            ),
                            ')',
                            ''
                        )
                    ),
                    0.00
                )
            )

    FROM dbo.WC9085_DBs AS D
    WHERE UPPER(LTRIM(RTRIM(D.ref_type))) = 'DB'
    GROUP BY
        COALESCE
        (
            NULLIF(LTRIM(RTRIM(D.[order])), ''),
            'NO REASON'
        )
),

Template_Rows AS
(
    SELECT
        Sort_Order = 1,

        [Reason (Order# Column)] =
            R.DB_Reason,

        [2022] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2023] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2024] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2025] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2026] =
            CAST(0.00 AS DECIMAL(18,2)),

        [Total Amount] =
            CAST(0.00 AS DECIMAL(18,2)),

        [Write up DB's sent] =
            CAST
            (
                ISNULL(W.Write_Up_DBs_Sent, 0.00)
                AS DECIMAL(18,2)
            )

    FROM Reason_List AS R
    LEFT JOIN WriteUp_Summary AS W
        ON W.DB_Reason = R.DB_Reason
),

Final_Template AS
(
    SELECT
        Sort_Order,
        [Reason (Order# Column)],
        [2022],
        [2023],
        [2024],
        [2025],
        [2026],
        [Total Amount],
        [Write up DB's sent]
    FROM Template_Rows

    UNION ALL

    SELECT
        Sort_Order = 2,

        [Reason (Order# Column)] =
            'TOTAL',

        [2022] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2023] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2024] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2025] =
            CAST(0.00 AS DECIMAL(18,2)),

        [2026] =
            CAST(0.00 AS DECIMAL(18,2)),

        [Total Amount] =
            CAST(0.00 AS DECIMAL(18,2)),

        [Write up DB's sent] =
            CAST
            (
                ISNULL
                (
                    (
                        SELECT SUM(T.[Write up DB's sent])
                        FROM Template_Rows AS T
                    ),
                    0.00
                )
                AS DECIMAL(18,2)
            )
)

SELECT
    Sort_Order,
    [Reason (Order# Column)],
    [2022],
    [2023],
    [2024],
    [2025],
    [2026],
    [Total Amount],
    [Write up DB's sent]
INTO dbo.WC9085_DB_Status_Summary
FROM Final_Template;


/*==============================================================================
|-- Q#03
|   `-- Display final template
==============================================================================*/

SELECT
    [Reason (Order# Column)],
    [2022],
    [2023],
    [2024],
    [2025],
    [2026],
    [Total Amount],
    [Write up DB's sent]
FROM dbo.WC9085_DB_Status_Summary
ORDER BY
    Sort_Order,
    [Reason (Order# Column)];