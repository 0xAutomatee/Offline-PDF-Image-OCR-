/*==============================================================================
|
|  PROJECT
|  `-- WALMART OPEN AGING
|
|  REPORT
|  `-- DB STATUS SUMMARY
|
|  SOURCE
|  `-- dbo.step_01_inquiry_rows
|
|  ACCOUNTS
|  |-- WC9085
|  |-- WA9085
|  `-- SA9200
|
|  ROW LOGIC
|  |-- SUMMARY
|  |   `-- All Accounts Total
|  |
|  |-- ACCOUNT SECTION
|  |   |-- Account title
|  |   |-- Distinct DB reasons
|  |   `-- Account total
|  |
|  `-- VALUES
|      |-- Dynamic columns from InvYear
|      |-- SUM(pay_day) by account, reason and year
|      |-- Total Amount = Sum of all years
|      `-- Write-up Sent = 0.00
|
==============================================================================*/

SET NOCOUNT ON;


/*==============================================================================
|-- Q#01
|   `-- CHECK SOURCE TABLE
==============================================================================*/

IF OBJECT_ID('dbo.step_01_inquiry_rows', 'U') IS NULL
BEGIN
    THROW 50001,
          'Required table dbo.step_01_inquiry_rows was not found.',
          1;
END;

PRINT 'Q#01 completed: Source table found.';


/*==============================================================================
|-- Q#02
|   `-- CHECK REQUIRED COLUMNS
==============================================================================*/

DECLARE @MissingColumns NVARCHAR(MAX);
DECLARE @ErrorMessage   NVARCHAR(2048);

;WITH RequiredColumns AS
(
    SELECT ColumnName
    FROM
    (
        VALUES
            ('acct'),
            ('name'),
            ('order'),
            ('InvYear'),
            ('pay_day'),
            ('ref_type')
    ) AS C(ColumnName)
)
SELECT
    @MissingColumns =
        STRING_AGG
        (
            QUOTENAME(R.ColumnName),
            ', '
        )
FROM RequiredColumns AS R
WHERE COL_LENGTH
      (
          'dbo.step_01_inquiry_rows',
          R.ColumnName
      ) IS NULL;

IF @MissingColumns IS NOT NULL
BEGIN
    SET @ErrorMessage =
        N'Missing required columns: ' + @MissingColumns;

    THROW 50002,
          @ErrorMessage,
          1;
END;

PRINT 'Q#02 completed: Required columns found.';


/*==============================================================================
|-- Q#03
|   `-- PREPARE ACCOUNT SETTINGS
==============================================================================*/

DROP TABLE IF EXISTS #Account_Settings;

CREATE TABLE #Account_Settings
(
    Account_Order INT           NOT NULL,
    Account_Code  NVARCHAR(50)  NOT NULL,
    Account_Title NVARCHAR(300) NOT NULL
);

INSERT INTO #Account_Settings
(
    Account_Order,
    Account_Code,
    Account_Title
)
VALUES
    (
        1,
        'WC9085',
        'WC9085 - WAL-MART CANADA, INC. (Open DB''s)'
    ),
    (
        2,
        'WA9085',
        'WA9085 - WAL-MART STORE, INC. (Open DB''s)'
    ),
    (
        3,
        'SA9200',
        'SA9200 - SAM''S CLUB (Open DB''s)'
    );

PRINT 'Q#03 completed: Account settings prepared.';


/*==============================================================================
|-- Q#04
|   `-- PREPARE CLEAN DB SOURCE
==============================================================================*/

DROP TABLE IF EXISTS #DB_Source;

SELECT
    A.Account_Order,

    Account_Code =
        A.Account_Code,

    Account_Title =
        A.Account_Title,

    DB_Reason =
        COALESCE
        (
            NULLIF(LTRIM(RTRIM(S.[order])), ''),
            'NO REASON'
        ),

    InvYear =
        TRY_CONVERT(INT, S.InvYear),

    DB_Amount =
        ISNULL
        (
            TRY_CONVERT
            (
                DECIMAL(18,2),

                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                LTRIM(RTRIM(S.pay_day)),
                                '$',
                                ''
                            ),
                            ',',
                            ''
                        ),
                        '(',
                        '-'
                    ),
                    ')',
                    ''
                )
            ),
            0.00
        ),

    Write_Up_Sent =
        CAST(0.00 AS DECIMAL(18,2))

INTO #DB_Source

FROM dbo.step_01_inquiry_rows AS S

INNER JOIN #Account_Settings AS A
    ON A.Account_Code = LTRIM(RTRIM(S.acct))

WHERE UPPER(LTRIM(RTRIM(S.ref_type))) = 'DB'
  AND TRY_CONVERT(INT, S.InvYear) IS NOT NULL
  AND S.[order] IS NOT NULL
  AND LTRIM(RTRIM(S.[order])) <> '';

DECLARE @SourceRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#04 completed: DB source rows prepared = ',
    @SourceRows
);


/*==============================================================================
|-- Q#05
|   `-- STOP IF NO SOURCE DATA EXISTS
==============================================================================*/

IF NOT EXISTS
(
    SELECT 1
    FROM #DB_Source
)
BEGIN
    THROW 50003,
          'No valid DB records were found for the selected accounts.',
          1;
END;


/*==============================================================================
|-- Q#06
|   `-- DECLARE DYNAMIC SQL VARIABLES
==============================================================================*/

DECLARE @YearColumns             NVARCHAR(MAX);
DECLARE @ReasonYearColumns       NVARCHAR(MAX);
DECLARE @AccountTotalYearColumns NVARCHAR(MAX);
DECLARE @AllTotalYearColumns     NVARCHAR(MAX);
DECLARE @TitleNullColumns        NVARCHAR(MAX);
DECLARE @TotalExpression         NVARCHAR(MAX);
DECLARE @SQL                     NVARCHAR(MAX);


/*==============================================================================
|-- Q#07
|   `-- BUILD DYNAMIC YEAR COLUMN NAMES
|
|  EXAMPLE
|  `-- [2022], [2023], [2024], [2025], [2026]
==============================================================================*/

SELECT
    @YearColumns =
        STRING_AGG
        (
            CAST
            (
                QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #DB_Source
) AS Y;


/*==============================================================================
|-- Q#08
|   `-- BUILD REASON ROW YEAR COLUMNS
==============================================================================*/

SELECT
    @ReasonYearColumns =
        STRING_AGG
        (
            CAST
            (
                  'CAST(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00) AS DECIMAL(18,2)) AS '
                + QUOTENAME(Y.InvYear)

                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #DB_Source
) AS Y;


/*==============================================================================
|-- Q#09
|   `-- BUILD ACCOUNT TOTAL YEAR COLUMNS
==============================================================================*/

SELECT
    @AccountTotalYearColumns =
        STRING_AGG
        (
            CAST
            (
                  'CAST(SUM(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)) AS DECIMAL(18,2)) AS '
                + QUOTENAME(Y.InvYear)

                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #DB_Source
) AS Y;


/*==============================================================================
|-- Q#10
|   `-- BUILD ALL-ACCOUNT TOTAL YEAR COLUMNS
==============================================================================*/

SET @AllTotalYearColumns =
    @AccountTotalYearColumns;


/*==============================================================================
|-- Q#11
|   `-- BUILD EMPTY CELLS FOR SECTION TITLE ROWS
==============================================================================*/

SELECT
    @TitleNullColumns =
        STRING_AGG
        (
            CAST
            (
                  'CAST(NULL AS DECIMAL(18,2)) AS '
                + QUOTENAME(Y.InvYear)

                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #DB_Source
) AS Y;


/*==============================================================================
|-- Q#12
|   `-- BUILD TOTAL AMOUNT EXPRESSION
==============================================================================*/

SELECT
    @TotalExpression =
        STRING_AGG
        (
            CAST
            (
                  'ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)'

                AS NVARCHAR(MAX)
            ),
            ' + '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #DB_Source
) AS Y;


/*==============================================================================
|-- Q#13
|   `-- VALIDATE DYNAMIC EXPRESSIONS
==============================================================================*/

IF NULLIF(@YearColumns, '') IS NULL
   OR NULLIF(@ReasonYearColumns, '') IS NULL
   OR NULLIF(@AccountTotalYearColumns, '') IS NULL
   OR NULLIF(@TitleNullColumns, '') IS NULL
   OR NULLIF(@TotalExpression, '') IS NULL
BEGIN
    THROW 50004,
          'Dynamic year expressions could not be generated.',
          1;
END;


/*==============================================================================
|-- Q#14
|   `-- BUILD COMBINED WALMART DB DASHBOARD
==============================================================================*/

SET @SQL = N'
;WITH Reason_Year_Summary AS
(
    SELECT
        Account_Order,
        Account_Code,
        Account_Title,
        DB_Reason,
        InvYear,

        DB_Amount =
            SUM(DB_Amount),

        Write_Up_Sent =
            SUM(Write_Up_Sent)

    FROM #DB_Source

    GROUP BY
        Account_Order,
        Account_Code,
        Account_Title,
        DB_Reason,
        InvYear
),

Pivot_Data AS
(
    SELECT
        Account_Order,
        Account_Code,
        Account_Title,
        DB_Reason,
        ' + @YearColumns + N'

    FROM
    (
        SELECT
            Account_Order,
            Account_Code,
            Account_Title,
            DB_Reason,
            InvYear,
            DB_Amount

        FROM Reason_Year_Summary
    ) AS S

    PIVOT
    (
        SUM(DB_Amount)

        FOR InvYear IN
        (
            ' + @YearColumns + N'
        )
    ) AS P
),

Account_WriteUp AS
(
    SELECT
        Account_Code,
        DB_Reason,

        Write_Up_Sent =
            SUM(Write_Up_Sent)

    FROM Reason_Year_Summary

    GROUP BY
        Account_Code,
        DB_Reason
),

Final_Dashboard AS
(
    /*======================================================================
    |-- 01. OVERALL REPORT TITLE
    ======================================================================*/

    SELECT
        Main_Order    = 0,
        Detail_Order  = 0,
        Account_Order = 0,

        [Report Line] =
            CAST(
                ''WALMART OPEN AGING (DB''''S) STATUS SUMMARY''
                AS NVARCHAR(300)
            ),

        ' + @TitleNullColumns + N',

        [Total Amount] =
            CAST(NULL AS DECIMAL(18,2)),

        [Write-up Sent] =
            CAST(NULL AS DECIMAL(18,2))


    UNION ALL


    /*======================================================================
    |-- 02. ALL ACCOUNTS TOTAL
    ======================================================================*/

    SELECT
        Main_Order    = 1,
        Detail_Order  = 0,
        Account_Order = 0,

        [Report Line] =
            CAST(
                ''All Accounts Total''
                AS NVARCHAR(300)
            ),

        ' + @AllTotalYearColumns + N',

        [Total Amount] =
            CAST
            (
                SUM
                (
                    ' + @TotalExpression + N'
                )
                AS DECIMAL(18,2)
            ),

        [Write-up Sent] =
            CAST(0.00 AS DECIMAL(18,2))

    FROM Pivot_Data


    UNION ALL


    /*======================================================================
    |-- 03. ACCOUNT SECTION TITLE
    ======================================================================*/

    SELECT DISTINCT
        Main_Order    = 2,
        Detail_Order  = 0,
        Account_Order,

        [Report Line] =
            CAST(
                Account_Title
                AS NVARCHAR(300)
            ),

        ' + @TitleNullColumns + N',

        [Total Amount] =
            CAST(NULL AS DECIMAL(18,2)),

        [Write-up Sent] =
            CAST(NULL AS DECIMAL(18,2))

    FROM Pivot_Data


    UNION ALL


    /*======================================================================
    |-- 04. ACCOUNT REASON ROWS
    ======================================================================*/

    SELECT
        Main_Order    = 2,
        Detail_Order  = 1,
        P.Account_Order,

        [Report Line] =
            CAST(
                P.DB_Reason
                AS NVARCHAR(300)
            ),

        ' + @ReasonYearColumns + N',

        [Total Amount] =
            CAST
            (
                ' + @TotalExpression + N'
                AS DECIMAL(18,2)
            ),

        [Write-up Sent] =
            CAST
            (
                ISNULL(W.Write_Up_Sent, 0.00)
                AS DECIMAL(18,2)
            )

    FROM Pivot_Data AS P

    LEFT JOIN Account_WriteUp AS W
        ON W.Account_Code = P.Account_Code
       AND W.DB_Reason    = P.DB_Reason


    UNION ALL


    /*======================================================================
    |-- 05. ACCOUNT TOTAL ROW
    ======================================================================*/

    SELECT
        Main_Order    = 2,
        Detail_Order  = 2,
        Account_Order,

        [Report Line] =
            CAST(
                ''ACCOUNT TOTAL''
                AS NVARCHAR(300)
            ),

        ' + @AccountTotalYearColumns + N',

        [Total Amount] =
            CAST
            (
                SUM
                (
                    ' + @TotalExpression + N'
                )
                AS DECIMAL(18,2)
            ),

        [Write-up Sent] =
            CAST(0.00 AS DECIMAL(18,2))

    FROM Pivot_Data

    GROUP BY
        Account_Order
)

SELECT
    [Report Line],
    ' + @YearColumns + N',
    [Total Amount],
    [Write-up Sent]

FROM Final_Dashboard

ORDER BY
    Main_Order,
    Account_Order,
    Detail_Order,

    CASE
        WHEN [Report Line] = ''ACCOUNT TOTAL'' THEN 2
        ELSE 1
    END,

    [Report Line];
';


/*==============================================================================
|-- Q#15
|   `-- EXECUTE FINAL DASHBOARD
==============================================================================*/

EXEC sys.sp_executesql @SQL;

PRINT 'Q#15 completed: Walmart DB dashboard generated.';