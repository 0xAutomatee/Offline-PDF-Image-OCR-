/*==============================================================================
|
|  PROJECT
|  `-- WALMART OPEN AGEING
|
|  DASHBOARD
|  `-- WC9085 OPEN DB STATUS SUMMARY
|
|  SOURCE
|  `-- dbo.WC9085_DBs
|
|  ROWS
|  `-- DISTINCT [order]
|
|  DYNAMIC COLUMNS
|  `-- DISTINCT InvYear
|
|  VALUES
|  `-- SUM(pay_day)
|
|  TOTAL AMOUNT
|  `-- SUM of all dynamic year columns
|
|  WRITE-UP DB'S SENT
|  `-- Initialized as 0.00
|
==============================================================================*/

SET NOCOUNT ON;


/*==============================================================================
|-- Q#01
|   `-- DROP OLD TEMP SOURCE
==============================================================================*/

DROP TABLE IF EXISTS #WC9085_DB_Source;


/*==============================================================================
|-- Q#02
|   `-- PREPARE CLEAN REASON / YEAR / AMOUNT DATA
==============================================================================*/

SELECT
    DB_Reason =
        LTRIM(RTRIM(D.[order])),

    InvYear =
        TRY_CONVERT(INT, D.InvYear),

    DB_Amount =
        ISNULL
        (
            TRY_CONVERT
            (
                DECIMAL(18,2),

                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                LTRIM(RTRIM(D.pay_day)),
                                '$',
                                ''
                            ),
                            ',',
                            ''
                        ),
                        '(',
                        '-'
                    ),
                    ')',
                    ''
                )
            ),
            0.00
        )

INTO #WC9085_DB_Source

FROM dbo.WC9085_DBs AS D

WHERE D.[order] IS NOT NULL
  AND LTRIM(RTRIM(D.[order])) <> ''
  AND TRY_CONVERT(INT, D.InvYear) IS NOT NULL
  AND UPPER(LTRIM(RTRIM(D.ref_type))) = 'DB';


DECLARE @Q02_Rows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#02 completed: #WC9085_DB_Source rows = ',
    @Q02_Rows
);


/*==============================================================================
|-- Q#03
|   `-- PREVIEW CLEAN SOURCE DATA
==============================================================================*/

SELECT
    DB_Reason,
    InvYear,
    SUM(DB_Amount) AS DB_Amount
FROM #WC9085_DB_Source
GROUP BY
    DB_Reason,
    InvYear
ORDER BY
    DB_Reason,
    InvYear;


/*==============================================================================
|-- Q#04
|   `-- DECLARE DYNAMIC SQL VARIABLES
==============================================================================*/

DECLARE @YearColumns           NVARCHAR(MAX);
DECLARE @ReasonYearColumns     NVARCHAR(MAX);
DECLARE @TotalYearColumns      NVARCHAR(MAX);
DECLARE @TotalAmountExpression NVARCHAR(MAX);
DECLARE @SQL                   NVARCHAR(MAX);


/*==============================================================================
|-- Q#05
|   `-- BUILD DYNAMIC PIVOT YEAR COLUMN LIST
|
|  EXAMPLE
|  `-- [2022],[2023],[2024],[2025],[2026]
==============================================================================*/

SELECT
    @YearColumns =
        STRING_AGG
        (
            CAST
            (
                QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ','
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear ASC
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#06
|   `-- BUILD REASON ROW YEAR COLUMNS
|
|  EXAMPLE
|  `-- CAST(ISNULL([2022],0.00) AS DECIMAL(18,2)) AS [2022]
==============================================================================*/

SELECT
    @ReasonYearColumns =
        STRING_AGG
        (
            CAST
            (
                'CAST(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00) AS DECIMAL(18,2)) AS '
                + QUOTENAME(Y.InvYear)

                AS NVARCHAR(MAX)
            ),
            ','
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear ASC
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#07
|   `-- BUILD TOTAL ROW YEAR COLUMNS
|
|  EXAMPLE
|  `-- CAST(SUM(ISNULL([2022],0.00)) AS DECIMAL(18,2)) AS [2022]
==============================================================================*/

SELECT
    @TotalYearColumns =
        STRING_AGG
        (
            CAST
            (
                'CAST(SUM(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)) AS DECIMAL(18,2)) AS '
                + QUOTENAME(Y.InvYear)

                AS NVARCHAR(MAX)
            ),
            ','
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear ASC
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#08
|   `-- BUILD TOTAL AMOUNT EXPRESSION
|
|  EXAMPLE
|  `-- ISNULL([2022],0) + ISNULL([2023],0) + ...
==============================================================================*/

SELECT
    @TotalAmountExpression =
        STRING_AGG
        (
            CAST
            (
                'ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)'

                AS NVARCHAR(MAX)
            ),
            ' + '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear ASC
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#09
|   `-- VALIDATE DYNAMIC YEAR COLUMNS
==============================================================================*/

IF NULLIF(@YearColumns, '') IS NULL
BEGIN
    THROW 50001,
          'No valid InvYear values found in dbo.WC9085_DBs.',
          1;
END;


/*==============================================================================
|-- Q#10
|   `-- GENERATE DYNAMIC WC9085 DB DASHBOARD
==============================================================================*/

SET @SQL = N'
;WITH Reason_Year_Summary AS
(
    SELECT
        DB_Reason,
        InvYear,

        DB_Amount =
            SUM(DB_Amount)

    FROM #WC9085_DB_Source

    GROUP BY
        DB_Reason,
        InvYear
),

Pivot_Data AS
(
    SELECT
        DB_Reason,
        ' + @YearColumns + N'

    FROM Reason_Year_Summary

    PIVOT
    (
        SUM(DB_Amount)

        FOR InvYear IN
        (
            ' + @YearColumns + N'
        )
    ) AS P
),

Final_Dashboard AS
(
    /*======================================================================
    |-- REASON ROWS
    ======================================================================*/

    SELECT
        Sort_Order = 1,

        [Reason (Order# Column)] =
            DB_Reason,

        ' + @ReasonYearColumns + N',

        [Total Amount] =
            CAST
            (
                ' + @TotalAmountExpression + N'
                AS DECIMAL(18,2)
            ),

        [Write up DB''s sent] =
            CAST(0.00 AS DECIMAL(18,2))

    FROM Pivot_Data


    UNION ALL


    /*======================================================================
    |-- TOTAL ROW
    ======================================================================*/

    SELECT
        Sort_Order = 2,

        [Reason (Order# Column)] =
            ''TOTAL'',

        ' + @TotalYearColumns + N',

        [Total Amount] =
            CAST
            (
                SUM
                (
                    ' + @TotalAmountExpression + N'
                )
                AS DECIMAL(18,2)
            ),

        [Write up DB''s sent] =
            CAST(0.00 AS DECIMAL(18,2))

    FROM Pivot_Data
)

SELECT
    [Reason (Order# Column)],
    ' + @YearColumns + N',
    [Total Amount],
    [Write up DB''s sent]

FROM Final_Dashboard

ORDER BY
    Sort_Order,
    [Reason (Order# Column)];
';


/*==============================================================================
|-- Q#11
|   `-- EXECUTE DYNAMIC DASHBOARD
==============================================================================*/

EXEC sys.sp_executesql @SQL;

PRINT 'Q#11 completed: WC9085 DB dashboard generated.';