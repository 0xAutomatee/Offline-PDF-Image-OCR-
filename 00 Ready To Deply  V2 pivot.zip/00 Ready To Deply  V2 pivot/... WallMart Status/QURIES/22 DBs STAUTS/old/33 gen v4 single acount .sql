/*==============================================================================
|
|  PROJECT
|  `-- WALMART OPEN AGEING
|
|  DASHBOARD
|  `-- WC9085 OPEN DB STATUS SUMMARY
|
|  OUTPUT ROWS
|  |-- 01 : WC9085 WAL-MART CANADA,INC. Open DB's
|  |-- 02 : Reason | Dynamic Years | Total Amount | Write up DB's sent
|  |-- 03+: Reason-wise values
|  `-- LAST: TOTAL
|
|  SOURCE
|  `-- dbo.WC9085_DBs
|
|  ROWS
|  `-- DISTINCT [order]
|
|  YEAR COLUMNS
|  `-- DISTINCT InvYear
|
|  VALUES
|  `-- SUM(pay_day)
|
==============================================================================*/

SET NOCOUNT ON;


/*==============================================================================
|-- Q#01
|   `-- CHECK SOURCE TABLE
==============================================================================*/

IF OBJECT_ID('dbo.WC9085_DBs', 'U') IS NULL
BEGIN
    THROW 50001,
          'Required table dbo.WC9085_DBs was not found.',
          1;
END;

PRINT 'Q#01 completed: dbo.WC9085_DBs found.';


/*==============================================================================
|-- Q#02
|   `-- CHECK REQUIRED COLUMNS
==============================================================================*/

DECLARE @MissingColumns NVARCHAR(MAX);
DECLARE @ErrorMessage   NVARCHAR(2048);

;WITH RequiredColumns AS
(
    SELECT ColumnName
    FROM
    (
        VALUES
            ('order'),
            ('InvYear'),
            ('pay_day'),
            ('ref_type')
    ) AS C(ColumnName)
)
SELECT
    @MissingColumns =
        STRING_AGG
        (
            QUOTENAME(R.ColumnName),
            ', '
        )
FROM RequiredColumns AS R
WHERE COL_LENGTH
      (
          'dbo.WC9085_DBs',
          R.ColumnName
      ) IS NULL;

IF @MissingColumns IS NOT NULL
BEGIN
    SET @ErrorMessage =
        N'Missing required columns in dbo.WC9085_DBs: '
        + @MissingColumns;

    THROW 50002,
          @ErrorMessage,
          1;
END;

PRINT 'Q#02 completed: All required columns found.';


/*==============================================================================
|-- Q#03
|   `-- PREPARE CLEAN SOURCE DATA
==============================================================================*/

DROP TABLE IF EXISTS #WC9085_DB_Source;

SELECT
    DB_Reason =
        LTRIM(RTRIM(D.[order])),

    InvYear =
        TRY_CONVERT(INT, D.InvYear),

    DB_Amount =
        ISNULL
        (
            TRY_CONVERT
            (
                DECIMAL(18,2),
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                LTRIM(RTRIM(D.pay_day)),
                                '$',
                                ''
                            ),
                            ',',
                            ''
                        ),
                        '(',
                        '-'
                    ),
                    ')',
                    ''
                )
            ),
            0.00
        )

INTO #WC9085_DB_Source

FROM dbo.WC9085_DBs AS D

WHERE D.[order] IS NOT NULL
  AND LTRIM(RTRIM(D.[order])) <> ''
  AND TRY_CONVERT(INT, D.InvYear) IS NOT NULL
  AND UPPER(LTRIM(RTRIM(D.ref_type))) = 'DB';

DECLARE @SourceRows INT = @@ROWCOUNT;

PRINT CONCAT(
    'Q#03 completed: Source rows prepared = ',
    @SourceRows
);


/*==============================================================================
|-- Q#04
|   `-- STOP IF NO VALID DATA EXISTS
==============================================================================*/

IF NOT EXISTS
(
    SELECT 1
    FROM #WC9085_DB_Source
)
BEGIN
    THROW 50003,
          'No valid WC9085 DB rows were found.',
          1;
END;


/*==============================================================================
|-- Q#05
|   `-- DECLARE ALL DYNAMIC VARIABLES
==============================================================================*/

DECLARE @YearColumns           NVARCHAR(MAX);
DECLARE @TitleNullColumns      NVARCHAR(MAX);
DECLARE @HeaderYearValues      NVARCHAR(MAX);
DECLARE @DataYearValues        NVARCHAR(MAX);
DECLARE @TotalYearValues       NVARCHAR(MAX);
DECLARE @TotalAmountExpression NVARCHAR(MAX);
DECLARE @SQL                   NVARCHAR(MAX);


/*==============================================================================
|-- Q#06
|   `-- BUILD DYNAMIC YEAR COLUMN LIST
|
|  EXAMPLE
|  `-- [2022], [2023], [2024], [2025], [2026]
==============================================================================*/

SELECT
    @YearColumns =
        STRING_AGG
        (
            CAST
            (
                QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#07
|   `-- BUILD EMPTY CELLS FOR TITLE ROW
==============================================================================*/

SELECT
    @TitleNullColumns =
        STRING_AGG
        (
            CAST
            (
                  'CAST(NULL AS NVARCHAR(100)) AS '
                + QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#08
|   `-- BUILD YEAR LABELS FOR SECOND ROW
==============================================================================*/

SELECT
    @HeaderYearValues =
        STRING_AGG
        (
            CAST
            (
                  'CAST('''
                + CONVERT(VARCHAR(10), Y.InvYear)
                + ''' AS NVARCHAR(100)) AS '
                + QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#09
|   `-- BUILD REASON ROW YEAR VALUES
==============================================================================*/

SELECT
    @DataYearValues =
        STRING_AGG
        (
            CAST
            (
                  'CONVERT(NVARCHAR(100), '
                + 'CAST(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00) AS DECIMAL(18,2))) AS '
                + QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#10
|   `-- BUILD TOTAL ROW YEAR VALUES
==============================================================================*/

SELECT
    @TotalYearValues =
        STRING_AGG
        (
            CAST
            (
                  'CONVERT(NVARCHAR(100), '
                + 'CAST(SUM(ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)) AS DECIMAL(18,2))) AS '
                + QUOTENAME(Y.InvYear)
                AS NVARCHAR(MAX)
            ),
            ', '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#11
|   `-- BUILD TOTAL AMOUNT EXPRESSION
==============================================================================*/

SELECT
    @TotalAmountExpression =
        STRING_AGG
        (
            CAST
            (
                  'ISNULL('
                + QUOTENAME(Y.InvYear)
                + ', 0.00)'
                AS NVARCHAR(MAX)
            ),
            ' + '
        )
        WITHIN GROUP
        (
            ORDER BY Y.InvYear
        )
FROM
(
    SELECT DISTINCT
        InvYear
    FROM #WC9085_DB_Source
) AS Y;


/*==============================================================================
|-- Q#12
|   `-- VALIDATE GENERATED VARIABLES
==============================================================================*/

IF NULLIF(@YearColumns, '') IS NULL
   OR NULLIF(@TitleNullColumns, '') IS NULL
   OR NULLIF(@HeaderYearValues, '') IS NULL
   OR NULLIF(@DataYearValues, '') IS NULL
   OR NULLIF(@TotalYearValues, '') IS NULL
   OR NULLIF(@TotalAmountExpression, '') IS NULL
BEGIN
    THROW 50004,
          'Dynamic dashboard columns could not be generated.',
          1;
END;


/*==============================================================================
|-- Q#13
|   `-- BUILD COMPLETE DYNAMIC DASHBOARD
==============================================================================*/

SET @SQL = N'
;WITH Reason_Year_Summary AS
(
    SELECT
        DB_Reason,
        InvYear,

        DB_Amount =
            SUM(DB_Amount)

    FROM #WC9085_DB_Source

    GROUP BY
        DB_Reason,
        InvYear
),

Pivot_Data AS
(
    SELECT
        DB_Reason,
        ' + @YearColumns + N'

    FROM Reason_Year_Summary

    PIVOT
    (
        SUM(DB_Amount)

        FOR InvYear IN
        (
            ' + @YearColumns + N'
        )
    ) AS P
),

Final_Dashboard AS
(
    /*======================================================================
    |-- ROW 01
    |   `-- STATIC ACCOUNT TITLE
    ======================================================================*/

    SELECT
        Sort_Order = 0,

        [Reason (Order# Column)] =
            CAST(
                ''WC9085 WAL-MART CANADA,INC. Open DB''''s''
                AS NVARCHAR(300)
            ),

        ' + @TitleNullColumns + N',

        [Total Amount] =
            CAST(NULL AS NVARCHAR(100)),

        [Write up DB''s sent] =
            CAST(NULL AS NVARCHAR(100))


    UNION ALL


    /*======================================================================
    |-- ROW 02
    |   `-- DASHBOARD LABEL ROW
    ======================================================================*/

    SELECT
        Sort_Order = 1,

        [Reason (Order# Column)] =
            CAST(
                ''Reason (Order# Column)''
                AS NVARCHAR(300)
            ),

        ' + @HeaderYearValues + N',

        [Total Amount] =
            CAST(
                ''Total Amount''
                AS NVARCHAR(100)
            ),

        [Write up DB''s sent] =
            CAST(
                ''Write up DB''''s sent''
                AS NVARCHAR(100)
            )


    UNION ALL


    /*======================================================================
    |-- ROW 03+
    |   `-- REASON-WISE VALUES
    ======================================================================*/

    SELECT
        Sort_Order = 2,

        [Reason (Order# Column)] =
            CAST(
                DB_Reason
                AS NVARCHAR(300)
            ),

        ' + @DataYearValues + N',

        [Total Amount] =
            CONVERT
            (
                NVARCHAR(100),

                CAST
                (
                    ' + @TotalAmountExpression + N'
                    AS DECIMAL(18,2)
                )
            ),

        [Write up DB''s sent] =
            CAST(
                ''0.00''
                AS NVARCHAR(100)
            )

    FROM Pivot_Data


    UNION ALL


    /*======================================================================
    |-- LAST ROW
    |   `-- TOTAL
    ======================================================================*/

    SELECT
        Sort_Order = 3,

        [Reason (Order# Column)] =
            CAST(
                ''TOTAL''
                AS NVARCHAR(300)
            ),

        ' + @TotalYearValues + N',

        [Total Amount] =
            CONVERT
            (
                NVARCHAR(100),

                CAST
                (
                    SUM
                    (
                        ' + @TotalAmountExpression + N'
                    )
                    AS DECIMAL(18,2)
                )
            ),

        [Write up DB''s sent] =
            CAST(
                ''0.00''
                AS NVARCHAR(100)
            )

    FROM Pivot_Data
)

SELECT
    [Reason (Order# Column)],
    ' + @YearColumns + N',
    [Total Amount],
    [Write up DB''s sent]

FROM Final_Dashboard

ORDER BY
    Sort_Order,
    [Reason (Order# Column)];
';


/*==============================================================================
|-- Q#14
|   `-- EXECUTE DASHBOARD
==============================================================================*/

EXEC sys.sp_executesql @SQL;

PRINT 'Q#14 completed: WC9085 DB dashboard generated.';