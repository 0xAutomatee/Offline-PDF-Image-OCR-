# Ready To Deploy V2 — Wal Mart, Amazon, and Regular Accounts Summary

```text
00 Ready To Deply  V2 pivot/
├── app/                         Application code
├── templates/                   Web user interface
├── companies/                   Wal Mart/Amazon/Regular Accounts configuration and report style templates
├── output/                      Empty runtime output location
├── requirements.txt             Python dependencies
├── app_runtime.env              Runtime settings (edit SQL Server / host if needed)
├── start_wallmartsummary_app.bat
└── stop_wallmartsummary_app.bat

python -m pip install -r requirements.txt



python -m pip install -r requirements.txt


python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8080 --reload
```

## Deploy

1. Copy this complete folder to the target computer.
2. Install the Python packages from `requirements.txt`.
3. Edit `app_runtime.env` for the target host and Python path. SQL settings are retained only for legacy SQL export features.
4. Run `start_wallmartsummary_app.bat`.
5. Open `http://<HOST>:<PORT>` in a browser.

## Included behavior

- `Wal Mart Summary` is file-only: it uses Python to read the upload, generate/refresh Ref Type, calculate ageing totals, apply comment-status rules, and build the formatted status workbook. Its upload/report flow does not open SQL Server.
- `Amazon Accounts` is file-only and does not open a database connection.
- `Regular Accounts` is file-only: it reads Full Ageing and Account Analyst List from one upload.
- Wal Mart and Amazon status formatting templates are included in
  `companies/wallmartsummary/wallmart_status_style_template.xlsx` and
  `companies/amazonaccounts/amazon_status_style_template.xlsx`.
- Every generated XLSX stores `AnsSys & openpyxl` as Creator and Last Modified By metadata.

## Not included

- Generated output workbooks
- User uploads and staging data
- Backup copies
- Edit history and development documentation
- Git repository files
