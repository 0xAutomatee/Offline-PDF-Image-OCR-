@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "CONFIG_FILE=app_runtime.env"
set "PORT=8040"

if exist "%CONFIG_FILE%" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%CONFIG_FILE%") do (
        if /I "%%A"=="PORT" set "PORT=%%B"
    )
)

for /f "tokens=5" %%A in ('netstat -ano ^| findstr :!PORT! ^| findstr LISTENING') do (
    taskkill /PID %%A /F
)

endlocal
