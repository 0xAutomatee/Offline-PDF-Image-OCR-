﻿from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


CONFIG_FILE_NAME = "app_runtime.env"

DEFAULTS = {
    "APP_TITLE": "WallMartSummary SQL FastAPI",
    "SQL_SERVER": r"localhost\SQLEXPRESS",
    "SQL_DATABASE": "WallMartSummary",
    "SQL_DRIVER": "ODBC Driver 17 for SQL Server",
    "TRUSTED_CONNECTION": "yes",
    "OUTPUT_DIR": "output",
    "TEMPLATES_DIR": "templates",
    "HOST": "192.168.2.123",
    "PORT": "8040",
    "PYTHON_EXE": "",
    "DEFAULT_COMPANY_CODE": "wallmartsummary",
}


@dataclass(frozen=True)
class RuntimeConfig:
    base_dir: Path
    config_path: Path
    app_title: str
    sql_server: str
    sql_database: str
    sql_driver: str
    trusted_connection: str
    output_dir_name: str
    templates_dir_name: str
    host: str
    port: int
    python_exe: str
    default_company_code: str

    @property
    def output_dir(self) -> Path:
        return self.base_dir / self.output_dir_name

    @property
    def templates_dir(self) -> Path:
        return self.base_dir / self.templates_dir_name


def _parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        values[key.strip().upper()] = value.strip()

    return values


@lru_cache(maxsize=1)
def load_runtime_config() -> RuntimeConfig:
    base_dir = Path(__file__).resolve().parent.parent
    config_path = base_dir / CONFIG_FILE_NAME
    values = DEFAULTS | _parse_env_file(config_path)

    return RuntimeConfig(
        base_dir=base_dir,
        config_path=config_path,
        app_title=values["APP_TITLE"],
        sql_server=values["SQL_SERVER"],
        sql_database=values["SQL_DATABASE"],
        sql_driver=values["SQL_DRIVER"],
        trusted_connection=values["TRUSTED_CONNECTION"],
        output_dir_name=values["OUTPUT_DIR"],
        templates_dir_name=values["TEMPLATES_DIR"],
        host=values["HOST"],
        port=int(values["PORT"]),
        python_exe=values["PYTHON_EXE"],
        default_company_code=values["DEFAULT_COMPANY_CODE"],
    )

