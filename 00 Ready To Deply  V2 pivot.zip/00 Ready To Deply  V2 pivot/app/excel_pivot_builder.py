from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import pandas as pd


_REQUIRED_FIELDS = (
    "Order#",
    "Name",
    "Ref Type",
    "Total",
    "Current",
    "1-30 Days",
    "31-60 Days",
    "61-90 Days",
    "Over 90 Days",
)
_VALUE_FIELDS = ("Total", "Current", "1-30 Days", "31-60 Days", "61-90 Days", "Over 90 Days")


def _column_key(value: object) -> str:
    return " ".join(str(value).strip().casefold().split())


def _powershell_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def run_regular_accounts_pivot_process(workbook_path: Path, ageing_rows: pd.DataFrame) -> None:
    """Finish a saved Regular Accounts workbook in a separate hidden Excel process.

    This runs after report generation and before the browser download. The app-host's
    Excel opens the temporary XLSX, adds the INV/DB summary and DB reason native
    PivotTables, saves the same file, then closes.
    """
    header_lookup = {_column_key(column): str(column) for column in ageing_rows.columns}
    missing_fields = [field for field in _REQUIRED_FIELDS if _column_key(field) not in header_lookup]
    if missing_fields:
        raise ValueError(
            "Regular Accounts PivotTables require these AGEING SHEET columns: "
            + ", ".join(missing_fields)
            + "."
        )

    source_address = f"'AGEING SHEET'!R1C1:R{len(ageing_rows) + 1}C{len(ageing_rows.columns)}"
    workbook_literal = _powershell_literal(str(workbook_path.resolve()))
    source_address_literal = _powershell_literal(source_address)
    script = f"""
$ErrorActionPreference = 'Stop'
$excel = $null
$workbook = $null
$pivotCache = $null

function Add-RegularAccountsPivot {{
    param(
        [object]$worksheet,
        [string]$destination,
        [string]$pivotName,
        [string]$rowFieldName,
        [string]$refTypeValue,
        [string]$title = '',
        [bool]$includeName = $false,
        [bool]$showRefTypeInRows = $false,
        [bool]$useRefTypeFilter = $true
    )
    if ($title) {{
        $worksheet.Range($destination).Offset(-2, 0).Value2 = $title
        $worksheet.Range($destination).Offset(-2, 0).Font.Bold = $true
        $worksheet.Range($destination).Offset(-2, 0).Font.Size = 14
    }}
    [void]$pivotCache.CreatePivotTable($worksheet.Range($destination), $pivotName)
    $pivot = $worksheet.PivotTables().Item($pivotName)
    $pivot.ManualUpdate = $true
    $rowField = $pivot.PivotFields().Item($rowFieldName)
    $rowField.Orientation = 1
    $rowField.Position = 1
    $rowField.LayoutForm = 1
    $rowField.RepeatLabels = $true
    $rowField.Subtotals = @($false) * 12
    if ($includeName) {{
        $nameField = $pivot.PivotFields().Item('Name')
        $nameField.Orientation = 1
        $nameField.Position = 2
        $nameField.LayoutForm = 1
        $nameField.RepeatLabels = $true
        $nameField.Subtotals = @($false) * 12
    }}
    $refTypeField = $pivot.PivotFields().Item('Ref Type')
    if ($showRefTypeInRows) {{
        $refTypeField.Orientation = 1
        $refTypeField.Position = if ($includeName) {{ 3 }} else {{ 2 }}
        $refTypeField.LayoutForm = 1
        $refTypeField.RepeatLabels = $true
        $refTypeField.Subtotals = @($false) * 12
    }} elseif ($useRefTypeFilter) {{
        $refTypeField.Orientation = 3
        $refTypeField.Position = 1
        $refTypeField.CurrentPage = $refTypeValue
    }}
    foreach ($valueFieldName in @('Current', '1-30 Days', '31-60 Days', '61-90 Days', 'Over 90 Days', 'Total')) {{
        $dataField = $pivot.AddDataField($pivot.PivotFields().Item($valueFieldName), "Sum of $valueFieldName", -4157)
        $dataField.NumberFormat = '$#,##0.00;[Red]($#,##0.00)'
    }}
    $pivot.RowGrand = $true
    $pivot.ColumnGrand = $true
    $pivot.RowAxisLayout(1)
    $pivot.ShowDrillIndicators = $true
    $pivot.EnableDrilldown = $true
    $pivot.TableStyle2 = 'PivotStyleMedium9'
    $pivot.ManualUpdate = $false
    $tableRange = $pivot.TableRange1
    $pivotHeaderRange = $tableRange.Rows.Item(1)
    $pivotGrandTotalRange = $tableRange.Rows.Item($tableRange.Rows.Count)
    $pivotGrandTotalRange.Interior.Color = $pivotHeaderRange.Interior.Color
    $pivotGrandTotalRange.Font.Color = $pivotHeaderRange.Font.Color
    $pivotGrandTotalRange.Font.Bold = $true
    if ($showRefTypeInRows) {{
        foreach ($pivotItem in @($refTypeField.PivotItems())) {{
            if ([string]$pivotItem.Name -ne $refTypeValue) {{
                $pivotItem.Visible = $false
            }}
        }}
    }}
}}

function New-RegularAccountsPivotSource {{
    param([object]$sourceSheet, [string]$sheetName, [string]$refTypeValue)
    $sourceLastRow = $sourceSheet.Cells($sourceSheet.Rows.Count, 1).End(-4162).Row
    $sourceLastColumn = $sourceSheet.Cells(1, $sourceSheet.Columns.Count).End(-4159).Column
    $refTypeColumn = 0
    for ($columnNumber = 1; $columnNumber -le $sourceLastColumn; $columnNumber++) {{
        if ([string]$sourceSheet.Cells(1, $columnNumber).Value2 -eq 'Ref Type') {{
            $refTypeColumn = $columnNumber
            break
        }}
    }}
    if ($refTypeColumn -eq 0) {{ throw "AGEING SHEET is missing Ref Type." }}
    $targetSheet = $workbook.Worksheets.Add()
    $targetSheet.Name = $sheetName
    $targetSheet.Range($targetSheet.Cells(1, 1), $targetSheet.Cells(1, $sourceLastColumn)).Value2 =
        $sourceSheet.Range($sourceSheet.Cells(1, 1), $sourceSheet.Cells(1, $sourceLastColumn)).Value2
    $targetRow = 2
    for ($sourceRow = 2; $sourceRow -le $sourceLastRow; $sourceRow++) {{
        if ([string]$sourceSheet.Cells($sourceRow, $refTypeColumn).Value2 -eq $refTypeValue) {{
            $targetSheet.Range($targetSheet.Cells($targetRow, 1), $targetSheet.Cells($targetRow, $sourceLastColumn)).Value2 =
                $sourceSheet.Range($sourceSheet.Cells($sourceRow, 1), $sourceSheet.Cells($sourceRow, $sourceLastColumn)).Value2
            $targetRow++
        }}
    }}
    $targetSheet.Visible = 2
    return "'$sheetName'!R1C1:R$($targetRow - 1)C$sourceLastColumn"
}}

function Set-RegularAccountsPivotGrandTotalStyle {{
    param([object]$worksheet, [object]$pivot, [int]$lastColumn = 0)
    # Excel's PivotTable style can reset TableRange formatting. Find the visible
    # Grand Total row after the PivotTable has finished and format that row directly.
    $tableRange = $pivot.TableRange2
    $firstColumn = $tableRange.Column
    $finalColumn = $tableRange.Column + $tableRange.Columns.Count - 1
    if ($lastColumn -gt $finalColumn) {{ $finalColumn = $lastColumn }}
    $firstRow = $tableRange.Row + 1
    $lastRow = $tableRange.Row + $tableRange.Rows.Count + 2
    for ($rowNumber = $firstRow; $rowNumber -le $lastRow; $rowNumber++) {{
        if ([string]$worksheet.Cells($rowNumber, $firstColumn).Value2 -eq 'Grand Total') {{
            $grandTotalRange = $worksheet.Range(
                $worksheet.Cells($rowNumber, $firstColumn),
                $worksheet.Cells($rowNumber, $finalColumn)
            )
            $grandTotalRange.Interior.Color = 14994616  # Dark Blue, Text 2, Lighter 60% (#B8CCE4).
            $grandTotalRange.Font.Color = 0
            $grandTotalRange.Font.Bold = $true
            return
        }}
    }}
}}

function Get-RegularAccountsInvExtras {{
    param([object]$worksheet)
    $extras = @{{}}
    $lastRow = $worksheet.Cells($worksheet.Rows.Count, 1).End(-4162).Row
    for ($rowNumber = 8; $rowNumber -le $lastRow; $rowNumber++) {{
        $account = [string]$worksheet.Cells($rowNumber, 1).Value2
        if (-not $account -or $account -eq 'Grand Total') {{ continue }}
        $extras[$account] = @{{
            Terms = $worksheet.Cells($rowNumber, 10).Value2
            Salesman = $worksheet.Cells($rowNumber, 11).Value2
        }}
    }}
    return $extras
}}

function Restore-RegularAccountsInvExtras {{
    param([object]$worksheet, [object]$pivot, [hashtable]$extras)
    # TableRange1 starts on the visible Acct/Name/Ref Type table header.
    # Companion columns begin immediately after the PivotTable data.
    $tableRange = $pivot.TableRange1
    $headerRow = $tableRange.Row
    $lastPivotRow = $headerRow + $tableRange.Rows.Count - 1
    $companionStartColumn = $tableRange.Column + $tableRange.Columns.Count
    $termsColumn = $companionStartColumn
    $salesmanColumn = $companionStartColumn + 1
    $pivotHeaderStyleCell = $worksheet.Cells($headerRow, $companionStartColumn - 1)
    foreach ($columnNumber in $termsColumn..$salesmanColumn) {{
        $headerCell = $worksheet.Cells($headerRow, $columnNumber)
        $pivotHeaderStyleCell.Copy($headerCell)
    }}
    $worksheet.Cells($headerRow, $termsColumn).Value2 = 'TERMS#'
    $worksheet.Cells($headerRow, $salesmanColumn).Value2 = 'SALEMAN'
    $worksheet.Columns($termsColumn).AutoFit() | Out-Null
    $worksheet.Columns($salesmanColumn).AutoFit() | Out-Null

    for ($rowNumber = $headerRow + 1; $rowNumber -le $lastPivotRow; $rowNumber++) {{
        $account = [string]$worksheet.Cells($rowNumber, 1).Value2
        if ($account -eq 'Grand Total') {{
            $grandTotalExtrasRange = $worksheet.Range($worksheet.Cells($rowNumber, $termsColumn), $worksheet.Cells($rowNumber, $salesmanColumn))
            $grandTotalExtrasRange.Interior.Color = $pivotHeaderStyleCell.Interior.Color
            $grandTotalExtrasRange.Font.Color = $pivotHeaderStyleCell.Font.Color
            $grandTotalExtrasRange.Font.Bold = $true
            continue
        }}
        if (-not $extras.ContainsKey($account)) {{ continue }}
        $entry = $extras[$account]
        $worksheet.Cells($rowNumber, $termsColumn).Value2 = $entry.Terms
        $worksheet.Cells($rowNumber, $salesmanColumn).Value2 = $entry.Salesman
    }}
}}

try {{
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false
    $workbook = $excel.Workbooks.Open({workbook_literal}, 0, $false)

    $invSheet = $workbook.Worksheets.Item('INV SUMMARY')
    $invExtras = Get-RegularAccountsInvExtras $invSheet
    $invLastRow = $invSheet.Cells($invSheet.Rows.Count, 1).End(-4162).Row
    if ($invLastRow -ge 6) {{
        $invSheet.Range("A6:L$invLastRow").Clear()
    }}

    $crSheet = $workbook.Worksheets.Item("CR'S SUMMARY")
    $crLastRow = $crSheet.Cells($crSheet.Rows.Count, 1).End(-4162).Row
    if ($crLastRow -ge 6) {{
        $crSheet.Range("A6:I$crLastRow").Clear()
    }}

    $dbSheet = $workbook.Worksheets.Item("DB'S SUMMARY")
    $dbReasonTitleRow = 0
    $dbUsedLastRow = $dbSheet.Cells($dbSheet.Rows.Count, 2).End(-4162).Row
    for ($rowNumber = 1; $rowNumber -le $dbUsedLastRow; $rowNumber++) {{
        if ($dbSheet.Cells($rowNumber, 2).Value2 -eq "DB'S BY REASON") {{
            $dbReasonTitleRow = $rowNumber
            break
        }}
    }}
    $dbClearLastRow = if ($dbReasonTitleRow -gt 0) {{ $dbReasonTitleRow - 1 }} else {{ $dbSheet.Cells($dbSheet.Rows.Count, 1).End(-4162).Row }}
    if ($dbClearLastRow -ge 7) {{
        $dbSheet.Range("A7:I$dbClearLastRow").Clear()
    }}
    if ($dbReasonTitleRow -gt 0) {{
        # Preserve the existing title and spacer row, then replace only the
        # former static DB'S BY REASON table with its native PivotTable.
        $dbReasonHeaderRow = $dbReasonTitleRow + 3
        $dbReasonLastRow = $dbSheet.Cells($dbSheet.Rows.Count, 1).End(-4162).Row
        if ($dbReasonLastRow -ge $dbReasonHeaderRow) {{
            $dbSheet.Range("A$($dbReasonHeaderRow):I$($dbReasonLastRow)").Clear()
        }}
    }}

    $ageingSourceSheet = $workbook.Worksheets.Item('AGEING SHEET')
    $invSourceAddress = New-RegularAccountsPivotSource $ageingSourceSheet '_RegularAccounts_IN_Pivot' 'IN'
    $crSourceAddress = New-RegularAccountsPivotSource $ageingSourceSheet '_RegularAccounts_CR_Pivot' 'CR'
    $dbSourceAddress = New-RegularAccountsPivotSource $ageingSourceSheet '_RegularAccounts_DB_Pivot' 'DB'

    $pivotCache = $workbook.PivotCaches().Create(1, $invSourceAddress)
    $pivotCache.RefreshOnFileOpen = $true
    Add-RegularAccountsPivot $invSheet 'A7' 'InvSummaryPivot' 'Acct' 'IN' '' $true $true $false
    $invPivot = $invSheet.PivotTables().Item('InvSummaryPivot')
    Restore-RegularAccountsInvExtras $invSheet $invPivot $invExtras
    Set-RegularAccountsPivotGrandTotalStyle $invSheet $invPivot 11
    $invSheet.Activate()
    $excel.ActiveWindow.FreezePanes = $false
    $excel.ActiveWindow.SplitColumn = 0
    $excel.ActiveWindow.SplitRow = 0
    $pivotCache = $workbook.PivotCaches().Create(1, $crSourceAddress)
    $pivotCache.RefreshOnFileOpen = $true
    Add-RegularAccountsPivot $crSheet 'A7' 'CrSummaryPivot' 'Acct' 'CR' '' $true $true $false
    Set-RegularAccountsPivotGrandTotalStyle $crSheet ($crSheet.PivotTables().Item('CrSummaryPivot'))
    $crSheet.Activate()
    $excel.ActiveWindow.FreezePanes = $false
    $excel.ActiveWindow.SplitColumn = 0
    $excel.ActiveWindow.SplitRow = 0
    $pivotCache = $workbook.PivotCaches().Create(1, $dbSourceAddress)
    $pivotCache.RefreshOnFileOpen = $true
    Add-RegularAccountsPivot $dbSheet 'A7' 'DbSummaryPivot' 'Acct' 'DB' '' $true $true $false
    Set-RegularAccountsPivotGrandTotalStyle $dbSheet ($dbSheet.PivotTables().Item('DbSummaryPivot'))
    $dbSheet.Activate()
    $excel.ActiveWindow.FreezePanes = $false
    $excel.ActiveWindow.SplitColumn = 0
    $excel.ActiveWindow.SplitRow = 0
    if ($dbReasonTitleRow -gt 0) {{
        $pivotCache = $workbook.PivotCaches().Create(1, {source_address_literal})
        $pivotCache.RefreshOnFileOpen = $true
        Add-RegularAccountsPivot $dbSheet "A$($dbReasonTitleRow + 3)" 'DBsByReasonPivot' 'Order#' 'DB' '' $false $true
        $dbReasonPivot = $dbSheet.PivotTables().Item('DBsByReasonPivot')
        $dbReasonRange = $dbReasonPivot.TableRange1
        $dbSheet.Range(
            $dbSheet.Cells($dbReasonRange.Row + 1, $dbReasonRange.Column),
            $dbSheet.Cells($dbReasonRange.Row + $dbReasonRange.Rows.Count - 1, $dbReasonRange.Column)
        ).Font.Bold = $true
        Set-RegularAccountsPivotGrandTotalStyle $dbSheet $dbReasonPivot
    }}
    $workbook.Save()
}}
finally {{
    if ($workbook -ne $null) {{ $workbook.Close($false) }}
    if ($excel -ne $null) {{ $excel.Quit() }}
}}
"""
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".ps1", prefix="regular_accounts_pivot_", encoding="utf-8-sig", delete=False
    ) as script_file:
        script_file.write(script)
        script_path = Path(script_file.name)
    try:
        result = subprocess.run(
            [
                r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
            ],
            capture_output=True,
            text=True,
            timeout=120,
            creationflags=creationflags,
            check=False,
        )
    finally:
        script_path.unlink(missing_ok=True)
    if result.returncode != 0:
        message = (result.stderr or result.stdout or "Unknown Excel automation error.").strip()
        raise RuntimeError(f"Excel could not complete the Regular Accounts PivotTable process: {message}")
