import os
import re
import traceback
import csv
from pathlib import Path
from typing import Optional

import pandas as pd

from app.adapters.company_loader import CompanyProfile
from app.adapters.mapping_engine import find_sheet_name, rename_with_aliases
from app.adapters.validation_engine import ensure_required_columns
from app.DbConfigLogger import Logger
from app.workbook_metadata import prepare_pivot_source_sheet, set_workbook_author_metadata

STEP_02_OUTPUT_FILE = "STEP_02_COMBINED_INVOICE.xlsx"
STEP_02_SHEETS = ("Farooq", "Yasar AR")
STEP_01_OUTPUT_FILE = "STEP_01_NORMALIZED_INQUIRY.xlsx"
STEP_01A_OUTPUT_FILE = "STEP_01A_CR_IN_DB_GEN.xlsx"
STEP_03_OUTPUT_FILE = "STEP_03_DETAIL_COMBINED.xlsx"
STEP_03_SOURCE_SHEET = "Remittance payments"
STEP_03_RENAMED_SHEET = "step_03_detial_combined"
STEP_03_SQL_COLUMN_ORDER = (
    "invoice_number",
    "keyrec_number",
    "doc_type",
    "transaction_value",
    "cash_discount_amount",
    "clearing_document_number",
    "payment_chargeback_date",
    "comments",
    "reason_code",
    "sap_company_code",
    "po_number",
    "reference_check_number",
    "invoice_date",
    "posting_date",
    "payment_number",
    "source_file",
    "sum_total",
    "invoice_db_number",
    "cr_issue",
    "total_payment",
)
STEP_03_DECIMAL_COLUMNS = (
    "transaction_value",
    "cash_discount_amount",
    "sum_total",
    "total_payment",
)
STEP_03_DATE_COLUMNS = (
    "payment_chargeback_date",
    "invoice_date",
    "posting_date",
)
STEP_03_TEXT_COLUMNS = (
    "invoice_number",
    "keyrec_number",
    "doc_type",
    "clearing_document_number",
    "comments",
    "reason_code",
    "sap_company_code",
    "po_number",
    "reference_check_number",
    "payment_number",
    "source_file",
    "invoice_db_number",
    "cr_issue",
)


def _normalize_column_label(column_name: object) -> str:
    text = "" if pd.isna(column_name) else str(column_name).strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    if not text:
        return "column"
    if text[0].isdigit():
        return f"col_{text}"
    return text


def _step_03_match_score(columns: list[object], step_config: dict) -> tuple[int, int]:
    normalized_columns = {_normalize_column_label(column_name) for column_name in columns}
    target_columns = set(step_config.get("detail_column_aliases", {}).keys()) or set(STEP_03_SQL_COLUMN_ORDER)
    key_columns = set(step_config.get("sheet_match_columns", [])) or {"invoice_number", "payment_number", "po_number"}
    overlap = len(normalized_columns & target_columns)
    key_overlap = len(normalized_columns & key_columns)
    return key_overlap, overlap


def _looks_like_step_03_schema(columns: list[object], step_config: dict) -> bool:
    key_overlap, overlap = _step_03_match_score(columns, step_config)
    return key_overlap >= 2 or overlap >= 4


def _find_step_03_header_row(raw_lines: list[str], step_config: dict) -> int:
    for index, raw_line in enumerate(raw_lines):
        parsed_values = next(csv.reader([raw_line]))
        if _looks_like_step_03_schema(parsed_values, step_config):
            return int(index)
    return 0


def _normalize_claim_value(value: object) -> str:
    if pd.isna(value):
        return ""

    if isinstance(value, (int, float)):
        numeric_value = float(value)
        if numeric_value.is_integer():
            return str(int(numeric_value))
        return str(value).strip()

    text_value = str(value).strip()
    integer_match = re.fullmatch(r"(\d+)\.0+", text_value)
    if integer_match:
        return integer_match.group(1)

    return text_value


def _normalize_payment_amount_value(value: object) -> object:
    if pd.isna(value):
        return None

    if isinstance(value, (int, float)):
        return value

    text_value = str(value).strip()
    if not text_value:
        return None

    is_parentheses_negative = text_value.startswith("(") and text_value.endswith(")")
    if is_parentheses_negative:
        text_value = text_value[1:-1].strip()

    text_value = text_value.replace("$", "").replace(",", "").replace(" ", "")

    if is_parentheses_negative and not text_value.startswith("-"):
        text_value = f"-{text_value}"

    return text_value


def _prepare_step_01_inquiry_columns(data_frame: pd.DataFrame, logger: Logger) -> tuple[pd.DataFrame, list[str]]:
    prepared = data_frame.copy()
    added_columns: list[str] = []

    if "claim" in prepared.columns:
        prepared["claim"] = prepared["claim"].map(_normalize_claim_value)

    if "order" in prepared.columns and "Ndatee" not in prepared.columns:
        order_text = prepared["order"].astype(str).str.strip()
        extracted = order_text.str.slice(6, 12)
        parsed_dates = pd.to_datetime(extracted, format="%m%d%y", errors="coerce")
        prepared["Ndatee"] = parsed_dates.dt.date
        added_columns.append("Ndatee")

    if "pay_day" not in prepared.columns:
        aging_columns = [
            "current",
            "col_1_30_days",
            "col_31_60_days",
            "col_61_90_days",
            "over_90_days",
        ]
        selected_pay_day = pd.Series(0.0, index=prepared.index, dtype="float64")
        has_selected_value = pd.Series(False, index=prepared.index)

        for column_name in aging_columns:
            if column_name not in prepared.columns:
                continue

            column_values = pd.to_numeric(prepared[column_name], errors="coerce")
            column_has_value = column_values.notna() & column_values.ne(0)
            rows_to_update = (~has_selected_value) & column_has_value
            selected_pay_day.loc[rows_to_update] = column_values.loc[rows_to_update]
            has_selected_value.loc[rows_to_update] = True

        if "ref" in prepared.columns:
            ref_text = prepared["ref"].fillna("").astype(str).str.upper()
            cr_rows = ref_text.str.contains("CR", na=False)
            selected_pay_day.loc[cr_rows] = -selected_pay_day.loc[cr_rows].abs()

        prepared["pay_day"] = selected_pay_day.fillna(0.0)
        added_columns.append("pay_day")

    if "claim" in prepared.columns and "Cclaim" not in prepared.columns:
        claim_text = prepared["claim"].fillna("").astype(str).str.strip()
        prepared["Cclaim"] = claim_text.where(
            ~(claim_text.str.startswith("DB") | claim_text.str.startswith("CR")),
            claim_text.str[-6:],
        )
        added_columns.append("Cclaim")

    if "pay_day" in prepared.columns and "Cclaim" in prepared.columns:
        reordered_columns = list(prepared.columns)
        reordered_columns.remove("Cclaim")
        pay_day_index = reordered_columns.index("pay_day")
        reordered_columns.insert(pay_day_index + 1, "Cclaim")
        prepared = prepared[reordered_columns]

    if added_columns:
        logger.log(f"Step 01 early column preparation applied: {', '.join(added_columns)}", "SUCCESS")

    return prepared, added_columns


def _prepare_step_02_po_details_columns(data_frame: pd.DataFrame, logger: Logger) -> tuple[pd.DataFrame, list[str]]:
    prepared = data_frame.copy()
    added_columns: list[str] = []
    empty_decimal_series = pd.Series([None] * len(prepared.index), index=prepared.index, dtype="object")
    month_numbers = {
        "jan": 1,
        "feb": 2,
        "mar": 3,
        "apr": 4,
        "may": 5,
        "jun": 6,
        "jul": 7,
        "aug": 8,
        "sep": 9,
        "oct": 10,
        "nov": 11,
        "dec": 12,
    }

    if "retail_order" in prepared.columns and "cRetailOrder" not in prepared.columns:
        retail_order_text = prepared["retail_order"].fillna("").astype(str).str.strip()
        prepared["cRetailOrder"] = retail_order_text.str.split("_", n=1).str[0].str.strip()
        added_columns.append("cRetailOrder")

    if "quantity" in prepared.columns and "qxc" not in prepared.columns:
        quantity_values = pd.to_numeric(prepared["quantity"], errors="coerce")
        cost_values = (
            pd.to_numeric(prepared["cost"], errors="coerce")
            if "cost" in prepared.columns
            else pd.Series(pd.NA, index=prepared.index)
        )
        prepared["qxc"] = (quantity_values * cost_values).round(2)
        added_columns.append("qxc")

    if "Odatee" not in prepared.columns:
        odatee_values = pd.Series([None] * len(prepared.index), index=prepared.index, dtype="object")
        if "source_file" in prepared.columns:
            source_file_text = prepared["source_file"].fillna("").astype(str)
            extracted_year = source_file_text.str.extract(r"([1-2][0-9]{3})", expand=False)
            year_values = pd.to_numeric(extracted_year, errors="coerce")

            source_file_lower = source_file_text.str.lower()
            month_values = pd.Series(pd.NA, index=prepared.index, dtype="Int64")
            for month_name, month_number in month_numbers.items():
                month_values = month_values.mask(
                    month_values.isna() & source_file_lower.str.contains(month_name, na=False),
                    month_number,
                )

            valid_rows = year_values.notna() & month_values.notna()
            if valid_rows.any():
                odatee_values.loc[valid_rows] = pd.to_datetime(
                    {
                        "year": year_values.loc[valid_rows].astype(int),
                        "month": month_values.loc[valid_rows].astype(int),
                        "day": 1,
                    },
                    errors="coerce",
                ).dt.date
        prepared["Odatee"] = odatee_values
        added_columns.append("Odatee")

    if "invoice_db_number" not in prepared.columns:
        prepared["invoice_db_number"] = ""
        added_columns.append("invoice_db_number")

    if "cr_issue" not in prepared.columns:
        prepared["cr_issue"] = ""
        added_columns.append("cr_issue")

    if "Po_Count" not in prepared.columns:
        prepared["Po_Count"] = ""
        added_columns.append("Po_Count")

    if "Total_Invoice" not in prepared.columns:
        prepared["Total_Invoice"] = empty_decimal_series.copy()
        added_columns.append("Total_Invoice")

    if "Total_Payment" not in prepared.columns:
        prepared["Total_Payment"] = empty_decimal_series.copy()
        added_columns.append("Total_Payment")

    if "diff" not in prepared.columns:
        prepared["diff"] = empty_decimal_series.copy()
        added_columns.append("diff")

    if "po_status" not in prepared.columns:
        prepared["po_status"] = ""
        added_columns.append("po_status")

    if added_columns:
        logger.log(f"Step 02 early column preparation applied: {', '.join(added_columns)}", "SUCCESS")

    return prepared, added_columns


def _prepare_step_03_detail_columns(data_frame: pd.DataFrame, logger: Logger) -> tuple[pd.DataFrame, list[str]]:
    prepared = data_frame.copy()
    added_columns: list[str] = []

    for column_name in STEP_03_SQL_COLUMN_ORDER:
        if column_name in prepared.columns:
            continue
        if column_name in STEP_03_TEXT_COLUMNS:
            prepared[column_name] = ""
        else:
            prepared[column_name] = None
        added_columns.append(column_name)

    for column_name in STEP_03_DECIMAL_COLUMNS:
        normalized_values = prepared[column_name].map(_normalize_payment_amount_value)
        prepared[column_name] = pd.to_numeric(normalized_values, errors="coerce")

    if "source_file" in prepared.columns:
        source_file_values = prepared["source_file"].where(prepared["source_file"].notna(), "")
        source_file_values = source_file_values.astype(str).str.strip()
        prepared["source_file"] = source_file_values.replace({"": None})

    if "sum_total" in prepared.columns and "source_file" in prepared.columns:
        if prepared["sum_total"].isna().all() and "transaction_value" in prepared.columns:
            source_series = prepared["source_file"].fillna("")
            transaction_series = prepared["transaction_value"].fillna(0)
            valid_source_rows = source_series.ne("")
            prepared.loc[valid_source_rows, "sum_total"] = (
                transaction_series.loc[valid_source_rows]
                .groupby(source_series.loc[valid_source_rows])
                .transform("sum")
                .round(2)
            )

    for column_name in STEP_03_DATE_COLUMNS:
        prepared[column_name] = pd.to_datetime(prepared[column_name], errors="coerce").dt.date

    for column_name in STEP_03_TEXT_COLUMNS:
        prepared[column_name] = prepared[column_name].where(prepared[column_name].notna(), "")
        prepared[column_name] = prepared[column_name].astype(str).str.strip()
        prepared.loc[prepared[column_name].eq(""), column_name] = None

    prepared = prepared[list(STEP_03_SQL_COLUMN_ORDER)]

    if added_columns:
        logger.log(f"Step 03 early column preparation applied: {', '.join(added_columns)}", "SUCCESS")

    return prepared, added_columns


def _read_file(path: str) -> pd.DataFrame:
    extension = os.path.splitext(path)[1].lower()
    if extension == ".csv":
        return pd.read_csv(path)

    engine = "xlrd" if extension == ".xls" else "openpyxl"
    return pd.read_excel(path, engine=engine)


def _read_excel_sheet(path: str, sheet_name: str, skiprows: int = 0) -> pd.DataFrame:
    extension = os.path.splitext(path)[1].lower()
    engine = "xlrd" if extension == ".xls" else "openpyxl"
    return pd.read_excel(path, sheet_name=sheet_name, engine=engine, skiprows=skiprows)


def _read_step_03_csv_detail(path: str, step_config: dict) -> pd.DataFrame:
    with open(path, "r", encoding="utf-8-sig", errors="replace") as file_handle:
        raw_lines = file_handle.readlines()
    header_row_index = _find_step_03_header_row(raw_lines, step_config)

    detail_df = pd.read_csv(
        path,
        skiprows=header_row_index,
        sep=",",
        engine="python",
        on_bad_lines="skip",
        encoding="utf-8-sig",
    )
    detail_df.columns = [str(column).strip() for column in detail_df.columns]
    detail_df = _drop_unnamed_columns(detail_df, "Step 03 CSV detail")

    return detail_df.reset_index(drop=True)


def _read_step_03_excel_detail(
    file_path: str,
    workbook: pd.ExcelFile,
    step_config: dict,
) -> tuple[pd.DataFrame, str, int]:
    configured_skiprows = int(step_config.get("skiprows", {}).get("remittance_payments", 0))
    skiprows_candidates = [configured_skiprows] + [value for value in range(0, 11) if value != configured_skiprows]

    alias_sheets = step_config.get("sheet_aliases", {}).get("remittance_payments", [])
    prioritized_sheets: list[str] = []
    for alias in alias_sheets:
        matched_sheet = find_sheet_name(workbook.sheet_names, [alias], alias)
        if matched_sheet and matched_sheet not in prioritized_sheets:
            prioritized_sheets.append(matched_sheet)
    for sheet_name in workbook.sheet_names:
        if sheet_name not in prioritized_sheets:
            prioritized_sheets.append(sheet_name)

    best_candidate: tuple[int, int, pd.DataFrame, str, int] | None = None
    for sheet_name in prioritized_sheets:
        for skiprows in skiprows_candidates:
            try:
                detail_df = _read_excel_sheet(
                    file_path,
                    sheet_name,
                    skiprows=skiprows,
                ).dropna(how="all").reset_index(drop=True)
            except Exception:
                continue

            detail_df = _drop_unnamed_columns(detail_df, "Step 03 remittance sheet")
            if detail_df.empty:
                continue

            key_overlap, overlap = _step_03_match_score(list(detail_df.columns), step_config)
            if best_candidate is None or (key_overlap, overlap) > (best_candidate[0], best_candidate[1]):
                best_candidate = (key_overlap, overlap, detail_df, sheet_name, skiprows)

            if _looks_like_step_03_schema(list(detail_df.columns), step_config):
                return detail_df, sheet_name, skiprows

    if best_candidate is not None:
        return best_candidate[2], best_candidate[3], best_candidate[4]

    raise ValueError("Step 03 workbook does not contain a readable payment-detail sheet.")


def _rename_step_03_display_columns(data_frame: pd.DataFrame) -> pd.DataFrame:
    renamed = data_frame.copy()
    existing_columns = [str(column).strip() for column in renamed.columns]
    normalized_lookup = {str(column).strip().lower(): str(column) for column in renamed.columns}

    if "Invoice_Number" not in existing_columns:
        source_column = normalized_lookup.get("invoice number")
        if source_column:
            renamed = renamed.rename(columns={source_column: "Invoice_Number"})

    return renamed


def _drop_unnamed_columns(data_frame: pd.DataFrame, context_label: str) -> pd.DataFrame:
    cleaned = data_frame.copy()
    removable_columns = [
        str(column)
        for column in cleaned.columns
        if not str(column).strip() or str(column).strip().lower().startswith("unnamed:")
    ]
    if removable_columns:
        cleaned = cleaned.drop(columns=removable_columns)
    return cleaned


def _normalize_sql_column_name(column_name: object, used_names: set[str]) -> str:
    text = "" if pd.isna(column_name) else str(column_name).strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")

    if not text:
        text = "column"
    if text[0].isdigit():
        text = f"col_{text}"

    base_name = text
    suffix = 2
    while text in used_names:
        text = f"{base_name}_{suffix}"
        suffix += 1

    used_names.add(text)
    return text


def _normalize_dataframe_columns(data_frame: pd.DataFrame) -> pd.DataFrame:
    used_names: set[str] = set()
    normalized = data_frame.copy()
    normalized.columns = [
        _normalize_sql_column_name(column_name, used_names)
        for column_name in normalized.columns
    ]
    return normalized


class InquiryProcessor:
    def __init__(self, logger: Logger, company_profile: CompanyProfile | None = None) -> None:
        self.logger = logger
        self.company_profile = company_profile

    def process(self, file_path: str) -> Optional[pd.DataFrame]:
        try:
            self.logger.log(f"Reading inquiry file: {os.path.basename(file_path)}")
            normalized_data_frame = _normalize_dataframe_columns(_read_file(file_path).copy())
            step_config = self.company_profile.steps.get("step_01", {}) if self.company_profile else {}
            mapped_data_frame = rename_with_aliases(normalized_data_frame, step_config.get("column_aliases", {}))
            ensure_required_columns(
                mapped_data_frame,
                step_config.get("required_columns", []),
                "Step 01 inquiry file",
            )
            data_frame, prepared_columns = _prepare_step_01_inquiry_columns(mapped_data_frame, self.logger)
            self.logger.log(
                f"Inquiry ready: {len(data_frame)} rows, {len(data_frame.columns)} SQL-safe columns",
                "SUCCESS",
            )
            if prepared_columns:
                self.logger.log(
                    f"Step 01 inquiry columns added before save/upload: {', '.join(prepared_columns)}",
                    "SUCCESS",
                )
            return data_frame
        except Exception as exc:
            self.logger.log(f"Inquiry processing failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return None


class InvoiceWorkbookCombiner:
    def __init__(self, logger: Logger, company_profile: CompanyProfile | None = None) -> None:
        self.logger = logger
        self.company_profile = company_profile

    def combine(self, file_paths: list[str], output_dir: Path) -> Optional[dict]:
        try:
            step_config = self.company_profile.steps.get("step_02", {}) if self.company_profile else {}
            farooq_frames: list[pd.DataFrame] = []
            po_details_frames: list[pd.DataFrame] = []

            for file_path in file_paths:
                source_name = self._source_name(file_path)
                self.logger.log(f"Reading workbook: {source_name}")

                workbook = pd.ExcelFile(file_path)
                farooq_sheet = find_sheet_name(
                    workbook.sheet_names,
                    step_config.get("sheet_aliases", {}).get("farooq", []),
                    "Farooq",
                )
                po_details_sheet = find_sheet_name(
                    workbook.sheet_names,
                    step_config.get("sheet_aliases", {}).get("po_details", []),
                    "Yasar AR",
                )
                if farooq_sheet is None or po_details_sheet is None:
                    raise ValueError(f"{source_name} is missing required Step 02 sheet(s).")

                farooq_df = _read_excel_sheet(
                    file_path,
                    farooq_sheet,
                    skiprows=int(step_config.get("skiprows", {}).get("farooq", 2)),
                ).dropna(how="all").reset_index(drop=True)
                po_details_df = _read_excel_sheet(file_path, po_details_sheet).dropna(how="all").reset_index(drop=True)

                if not farooq_df.empty:
                    farooq_df["source_file"] = source_name
                    farooq_frames.append(farooq_df)
                else:
                    self.logger.log(f"Farooq sheet is empty after deleting first two rows: {source_name}", "WARNING")

                if not po_details_df.empty:
                    po_details_df["source_file"] = source_name
                    po_details_frames.append(po_details_df)
                else:
                    self.logger.log(f"Yasar AR sheet is empty: {source_name}", "WARNING")

            if not farooq_frames and not po_details_frames:
                self.logger.log("No invoice data found to combine", "ERROR")
                return None

            farooq_combined = pd.concat(farooq_frames, ignore_index=True) if farooq_frames else pd.DataFrame()
            po_details_combined = pd.concat(po_details_frames, ignore_index=True) if po_details_frames else pd.DataFrame()

            master_path = output_dir / STEP_02_OUTPUT_FILE
            with pd.ExcelWriter(master_path, engine="openpyxl") as writer:
                set_workbook_author_metadata(writer.book)
                farooq_combined.to_excel(writer, sheet_name="Farooq", index=False)
                po_details_combined.to_excel(writer, sheet_name="Yasar AR", index=False)
                prepare_pivot_source_sheet(writer.sheets["Farooq"], "Step02Farooq")
                prepare_pivot_source_sheet(writer.sheets["Yasar AR"], "Step02YasarAR")

            self.logger.log(f"Step 02 workbook saved: {master_path}", "SUCCESS")

            normalized_farooq = rename_with_aliases(
                _normalize_dataframe_columns(farooq_combined),
                step_config.get("farooq_column_aliases", {}),
            )
            normalized_po_details = rename_with_aliases(
                _normalize_dataframe_columns(po_details_combined),
                step_config.get("po_details_column_aliases", {}),
            )
            ensure_required_columns(
                normalized_po_details,
                step_config.get("required_columns", {}).get("po_details", []),
                "Step 02 Yasar AR sheet",
            )
            prepared_po_details, prepared_columns = _prepare_step_02_po_details_columns(
                normalized_po_details,
                self.logger,
            )

            return {
                "farooq_df": normalized_farooq,
                "po_details_df": prepared_po_details,
                "po_details_prepared_columns": prepared_columns,
                "master_path": str(master_path),
            }
        except Exception as exc:
            self.logger.log(f"Invoice workbook combine failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return None

    @staticmethod
    def _source_name(file_path: str) -> str:
        stored_name = os.path.basename(file_path)
        return stored_name.split("__", 1)[1] if "__" in stored_name else stored_name


class DetailWorkbookCombiner:
    def __init__(self, logger: Logger, company_profile: CompanyProfile | None = None) -> None:
        self.logger = logger
        self.company_profile = company_profile

    def combine(self, file_paths: list[str], output_dir: Path) -> Optional[dict]:
        try:
            step_config = self.company_profile.steps.get("step_03", {}) if self.company_profile else {}
            detail_frames: list[pd.DataFrame] = []

            for file_path in file_paths:
                source_name = self._source_name(file_path)
                self.logger.log(f"Reading Step 03 workbook: {source_name}")

                extension = os.path.splitext(file_path)[1].lower()
                if extension == ".csv":
                    try:
                        detail_df = _read_step_03_csv_detail(file_path, step_config).dropna(how="all").reset_index(drop=True)
                    except pd.errors.EmptyDataError:
                        self.logger.log(
                            f"Skipping Step 03 workbook: {source_name} has no readable CSV columns",
                            "WARNING",
                        )
                        continue
                    self.logger.log(f"{source_name} -> csv detail rows: {len(detail_df)}")
                else:
                    workbook = pd.ExcelFile(file_path)
                    try:
                        detail_df, matched_detail_sheet, matched_skiprows = _read_step_03_excel_detail(
                            file_path,
                            workbook,
                            step_config,
                        )
                    except ValueError:
                        self.logger.log(
                            f"Skipping Step 03 workbook: {source_name} is missing a readable Step 03 payment sheet",
                            "WARNING",
                        )
                        continue
                    self.logger.log(
                        f"{source_name} -> sheet '{matched_detail_sheet}' rows: {len(detail_df)} (skiprows={matched_skiprows})"
                    )
                if detail_df.empty:
                    self.logger.log(f"Detail sheet is empty: {source_name}", "WARNING")
                    continue

                detail_df = _rename_step_03_display_columns(detail_df)

                detail_df["source_file"] = source_name
                detail_frames.append(detail_df)

            if not detail_frames:
                self.logger.log("No detail sheet data found to combine", "ERROR")
                return None

            combined_detail_df = pd.concat(detail_frames, ignore_index=True)

            output_path = output_dir / STEP_03_OUTPUT_FILE
            with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
                set_workbook_author_metadata(writer.book)
                combined_detail_df.to_excel(writer, sheet_name=STEP_03_RENAMED_SHEET, index=False)
                prepare_pivot_source_sheet(writer.sheets[STEP_03_RENAMED_SHEET], "Step03Detail")

            self.logger.log(
                f"Step 03 master sheet '{STEP_03_RENAMED_SHEET}' rows: {len(combined_detail_df)}"
            )
            self.logger.log(
                f"Step 03 workbook saved: {output_path} with sheet '{STEP_03_RENAMED_SHEET}'",
                "SUCCESS",
            )

            normalized_detail = rename_with_aliases(
                _normalize_dataframe_columns(combined_detail_df),
                step_config.get("detail_column_aliases", {}),
            )
            sql_ready_detail = normalized_detail.copy()
            ensure_required_columns(
                sql_ready_detail,
                step_config.get("required_columns", []),
                "Step 03 detail sheet",
            )
            prepared_detail, prepared_columns = _prepare_step_03_detail_columns(
                sql_ready_detail,
                self.logger,
            )

            return {
                "detail_df": prepared_detail,
                "detail_prepared_columns": prepared_columns,
                "combine_rows_df": normalized_detail,
                "master_path": str(output_path),
            }
        except Exception as exc:
            self.logger.log(f"Step 03 combine failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return None

    @staticmethod
    def _match_sheet(sheet_names: list[str], target_name: str) -> Optional[str]:
        target_normalized = target_name.strip().lower()
        for sheet_name in sheet_names:
            if sheet_name.strip().lower() == target_normalized:
                return sheet_name
        return None

    @staticmethod
    def _source_name(file_path: str) -> str:
        stored_name = os.path.basename(file_path)
        return stored_name.split("__", 1)[1] if "__" in stored_name else stored_name


class WorkflowOrchestrator:
    def __init__(
        self,
        logger: Logger,
        inquiry_processor: InquiryProcessor,
        invoice_combiner: InvoiceWorkbookCombiner,
        detail_combiner: DetailWorkbookCombiner,
    ) -> None:
        self.logger = logger
        self.inquiry_processor = inquiry_processor
        self.invoice_combiner = invoice_combiner
        self.detail_combiner = detail_combiner

    def run_step_01(self, inquiry_path: str, output_dir: Path) -> tuple[bool, dict]:
        try:
            self.logger.log("STEP 01: Normalize inquiry columns for SQL")
            inquiry_df = self.inquiry_processor.process(inquiry_path)
            if inquiry_df is None:
                return False, {"error": "Failed to process inquiry file."}

            output_path = output_dir / STEP_01_OUTPUT_FILE
            with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
                set_workbook_author_metadata(writer.book)
                inquiry_df.to_excel(writer, sheet_name="step_01_inquiry", index=False)
                prepare_pivot_source_sheet(writer.sheets["step_01_inquiry"], "Step01Inquiry")

            self.logger.log(f"Step 01 workbook saved: {output_path}", "SUCCESS")
            self.logger.log("Step 01 completed", "SUCCESS")
            return True, {"inquiry_df": inquiry_df, "output_path": str(output_path)}
        except Exception as exc:
            self.logger.log(f"Workflow failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return False, {"error": str(exc)}

    def run_step_02(self, invoice_paths: list[str], output_dir: Path) -> tuple[bool, dict]:
        try:
            self.logger.log("STEP 02: Combine workbook sheets")
            result = self.invoice_combiner.combine(invoice_paths, output_dir)
            if result is None:
                return False, {"error": "Failed to combine invoice workbooks."}

            self.logger.log("Step 02 completed", "SUCCESS")
            return True, result
        except Exception as exc:
            self.logger.log(f"Workflow failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return False, {"error": str(exc)}

    def run_step_03(self, workbook_paths: list[str], output_dir: Path) -> tuple[bool, dict]:
        try:
            self.logger.log("STEP 03: Combine remittance payment sheets")
            result = self.detail_combiner.combine(workbook_paths, output_dir)
            if result is None:
                return False, {"error": "Failed to combine Step 03 workbooks."}

            self.logger.log("Step 03 completed", "SUCCESS")
            return True, result
        except Exception as exc:
            self.logger.log(f"Workflow failed: {exc}", "ERROR")
            self.logger.log(traceback.format_exc(), "ERROR")
            return False, {"error": str(exc)}
