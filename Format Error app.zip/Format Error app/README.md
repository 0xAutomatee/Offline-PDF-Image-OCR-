# Excel Format Inspector

An easy local tool to identify Excel workbook errors before a file is sent on: changed values and formulas, font/fill/border/alignment/number format differences, row/column sizing, merged cells, and unexpected or missing worksheets.

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000. Upload the approved workbook as **Reference template** and the workbook to inspect as **Workbook to check**. The report identifies every difference. **Fix and download corrected copy** creates a separate download which applies the reference cells, formatting and layout; your original workbook is never replaced.

## Supported files and current scope

- `.xlsx` and `.xlsm` workbooks (macros are not run or changed).
- Cell values and formulas are compared exactly; formatting includes font, fill, borders, alignment, number format, and protection.
- The first version checks static workbook styling. It does not evaluate conditional formatting, charts, images, or formula results. Extra worksheets are reported but deliberately retained in the corrected copy to avoid deleting user work.

## Tests

```powershell
pytest
```
