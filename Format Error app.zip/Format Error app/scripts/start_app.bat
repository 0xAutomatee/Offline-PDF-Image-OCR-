@echo off
cd /d "%~dp0.."
if not exist "data\logs" mkdir "data\logs"
start "Excel Format Inspector" /b pythonw.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload > "data\logs\app.log" 2>&1
