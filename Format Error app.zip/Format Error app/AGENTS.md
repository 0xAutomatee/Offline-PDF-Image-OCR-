# Project Instructions

Maintain `app/struture&instruction.tx` as the basic project structure and operating-instructions reference. Update it whenever a change affects the application structure, module responsibilities, startup process, or user workflow.
