from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes_forensic import router as forensic_router
from app.config import ROOT_DIR

app = FastAPI(title="Excel Format Inspector")
app.mount("/static", StaticFiles(directory=ROOT_DIR / "app" / "static"), name="static")
app.include_router(forensic_router)


@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT_DIR / "app" / "templates" / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"status": "ok"}
