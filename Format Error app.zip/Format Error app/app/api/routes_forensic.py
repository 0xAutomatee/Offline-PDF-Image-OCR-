import json
import tempfile
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from app.services.forensic_format import create_corrected_workbook, scan_format_workbook
from app.services.forensic_storage import restore_source, save_source, saved_sources
from app.services.uploads import save_workbook_upload


router = APIRouter(prefix="/api/forensic", tags=["forensic"])


async def _uploaded_or_saved(source_type: str, upload: UploadFile | None, destination: Path) -> tuple[str | None, str]:
    if upload is not None and upload.filename:
        await save_workbook_upload(upload, destination)
        save_source(source_type, upload.filename, destination)
        return upload.filename, "uploaded"
    restored = restore_source(source_type, destination)
    return (restored, "saved") if restored else (None, "missing")


@router.post("/scan")
async def scan(
    ageing: UploadFile | None = File(None),
    write_up: UploadFile | None = File(None),
    memo: UploadFile | None = File(None),
):
    with tempfile.TemporaryDirectory(prefix="excel-forensic-") as directory:
        root = Path(directory)
        ageing_name, ageing_status = await _uploaded_or_saved("ageing", ageing, root / "ageing.xlsx")
        write_up_name, write_up_status = await _uploaded_or_saved("write_up", write_up, root / "write-up.xlsx")
        memo_name, memo_status = await _uploaded_or_saved("memo", memo, root / "memo.xlsx")
        if memo_name is None:
            raise HTTPException(400, "Upload the Credit Memo workbook once before running its format validation.")
        try:
            result = scan_format_workbook(root / "memo.xlsx")
            result["sources"] = {
                "ageing": ageing_name,
                "write_up": write_up_name,
                "memo": memo_name,
            }
            result["source_status"] = {"ageing": ageing_status, "write_up": write_up_status, "memo": memo_status}
            return result
        except Exception as exc:
            raise HTTPException(400, "The Credit Memo workbook could not be scanned. Check that all uploaded files are valid Excel files.") from exc


@router.post("/fix")
async def fix(
    background_tasks: BackgroundTasks,
    ageing: UploadFile | None = File(None),
    write_up: UploadFile | None = File(None),
    memo: UploadFile | None = File(None),
    issue_ids: str = Form(...),
):
    temporary = tempfile.TemporaryDirectory(prefix="excel-forensic-")
    source_path = Path(temporary.name) / "master.xlsx"
    ageing_path = Path(temporary.name) / "ageing.xlsx"
    write_up_path = Path(temporary.name) / "write-up.xlsx"
    selected_name = memo.filename if memo is not None and memo.filename else None
    suffix = Path(selected_name or "").suffix.lower() or ".xlsx"
    output_path = Path(temporary.name) / f"corrected-master{suffix}"
    try:
        selected = json.loads(issue_ids)
        if not isinstance(selected, list) or not all(isinstance(item, str) for item in selected):
            raise ValueError
        ageing_name, _ = await _uploaded_or_saved("ageing", ageing, ageing_path)
        write_up_name, _ = await _uploaded_or_saved("write_up", write_up, write_up_path)
        memo_name, _ = await _uploaded_or_saved("memo", memo, source_path)
        if memo_name is None:
            raise HTTPException(400, "Upload the Credit Memo workbook once before requesting a fix.")
        if ageing_name is None or write_up_name is None:
            raise HTTPException(400, "Upload the Ageing and Write-Up workbooks once before downloading a corrected Credit Memo workbook.")
        create_corrected_workbook(source_path, output_path, selected, ageing_path, write_up_path)
    except (ValueError, json.JSONDecodeError):
        temporary.cleanup()
        raise HTTPException(400, "Select a format finding with a safe automatic correction.")
    except HTTPException:
        temporary.cleanup()
        raise
    except Exception as exc:
        temporary.cleanup()
        raise HTTPException(400, "A corrected forensic workbook could not be created.") from exc
    background_tasks.add_task(temporary.cleanup)
    return FileResponse(output_path, filename=f"Vrfd {Path(selected_name or memo_name).name}", media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@router.get("/sources")
def sources():
    return {"sources": saved_sources()}
