"""Excel Format Inspector application."""
