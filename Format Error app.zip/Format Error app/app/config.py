from pathlib import Path
import os

ROOT_DIR = Path(__file__).resolve().parent.parent
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "25")) * 1024 * 1024
FORENSIC_TEMPLATE_PATH = ROOT_DIR / "app" / "forensic" / "credit_memo_template.xlsx"
FORENSIC_TEMPLATE_SHA256 = "9a0ebe595b5647d1c4414c4cdaa5dc70334bc222e19f4f4c8e46ee99b5c8b231"
FORENSIC_DATABASE_PATH = ROOT_DIR / "data" / "forensic_uploads.sqlite3"
FORENSIC_STORAGE_DIR = ROOT_DIR / "app" / "Storage"
