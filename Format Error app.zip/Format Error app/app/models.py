from dataclasses import asdict, dataclass


@dataclass
class Issue:
    category: str
    location: str
    message: str
    expected: str = ""
    actual: str = ""

    def to_dict(self):
        return asdict(self)
