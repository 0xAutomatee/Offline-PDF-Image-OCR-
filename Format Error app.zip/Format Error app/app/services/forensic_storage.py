"""Temporary local SQLite storage for uploaded forensic source workbooks."""

import sqlite3
import shutil
from datetime import datetime, timezone
from pathlib import Path

from app.config import FORENSIC_DATABASE_PATH, FORENSIC_STORAGE_DIR


def _connect(database_path: Path = FORENSIC_DATABASE_PATH) -> sqlite3.Connection:
    database_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database_path)
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS forensic_upload (
            source_type TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            workbook BLOB NOT NULL,
            uploaded_at TEXT NOT NULL
        )
        """
    )
    return connection


def _storage_path(source_type: str, storage_directory: Path) -> Path:
    return storage_directory / f"{source_type}.xlsx"


def _save_storage_copy(source_type: str, workbook_path: Path, storage_directory: Path) -> None:
    storage_directory.mkdir(parents=True, exist_ok=True)
    target = _storage_path(source_type, storage_directory)
    temporary = target.with_suffix(".tmp")
    shutil.copyfile(workbook_path, temporary)
    temporary.replace(target)


def _database_filename(source_type: str, database_path: Path) -> str | None:
    if not database_path.exists():
        return None
    connection = _connect(database_path)
    try:
        row = connection.execute(
            "SELECT filename FROM forensic_upload WHERE source_type = ?",
            (source_type,),
        ).fetchone()
    finally:
        connection.close()
    return row[0] if row else None


def save_source(
    source_type: str,
    filename: str,
    workbook_path: Path,
    database_path: Path = FORENSIC_DATABASE_PATH,
    storage_directory: Path = FORENSIC_STORAGE_DIR,
) -> None:
    connection = _connect(database_path)
    try:
        connection.execute(
            """
            INSERT INTO forensic_upload (source_type, filename, workbook, uploaded_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(source_type) DO UPDATE SET
                filename = excluded.filename,
                workbook = excluded.workbook,
                uploaded_at = excluded.uploaded_at
            """,
            (source_type, filename, workbook_path.read_bytes(), datetime.now(timezone.utc).isoformat()),
        )
        connection.commit()
    finally:
        connection.close()
    _save_storage_copy(source_type, workbook_path, storage_directory)


def restore_source(
    source_type: str,
    destination: Path,
    database_path: Path = FORENSIC_DATABASE_PATH,
    storage_directory: Path = FORENSIC_STORAGE_DIR,
) -> str | None:
    stored_copy = _storage_path(source_type, storage_directory)
    if stored_copy.is_file():
        shutil.copyfile(stored_copy, destination)
        return _database_filename(source_type, database_path) or stored_copy.name
    if not database_path.exists():
        return None
    connection = _connect(database_path)
    try:
        row = connection.execute(
            "SELECT filename, workbook FROM forensic_upload WHERE source_type = ?",
            (source_type,),
        ).fetchone()
    finally:
        connection.close()
    if row is None:
        return None
    destination.write_bytes(row[1])
    return row[0]


def saved_sources(
    database_path: Path = FORENSIC_DATABASE_PATH,
    storage_directory: Path = FORENSIC_STORAGE_DIR,
) -> dict[str, str]:
    storage_sources = {
        source_type: _storage_path(source_type, storage_directory).name
        for source_type in ("ageing", "write_up", "memo")
        if _storage_path(source_type, storage_directory).is_file()
    }
    if not database_path.exists():
        return storage_sources
    connection = _connect(database_path)
    try:
        rows = connection.execute("SELECT source_type, filename FROM forensic_upload").fetchall()
    finally:
        connection.close()
    # Keep the original user-facing filename from SQLite.  The disk copies use
    # stable technical names (for example, ``memo.xlsx``) and must not replace
    # the name shown in the browser after a refresh.
    database_sources = {source_type: filename for source_type, filename in rows}
    return {**storage_sources, **database_sources}
