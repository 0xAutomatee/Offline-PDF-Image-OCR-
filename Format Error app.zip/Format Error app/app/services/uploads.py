from pathlib import Path

from fastapi import HTTPException, UploadFile

from app.config import MAX_UPLOAD_BYTES


ALLOWED_WORKBOOK_EXTENSIONS = {".xlsx", ".xlsm"}


async def save_workbook_upload(upload: UploadFile, destination: Path) -> None:
    """Save an accepted workbook with the configured size limit."""
    if Path(upload.filename or "").suffix.lower() not in ALLOWED_WORKBOOK_EXTENSIONS:
        raise HTTPException(400, "Please upload an .xlsx or .xlsm workbook.")
    size = 0
    with destination.open("wb") as stream:
        while chunk := await upload.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                raise HTTPException(413, "Workbook is larger than the configured upload limit.")
            stream.write(chunk)
