"""Read-only forensic format checks for numbered credit-memo worksheets."""

from __future__ import annotations

import re
import hashlib
import zipfile
from collections import defaultdict
from copy import copy
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from xml.etree import ElementTree as ET

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

from app.config import FORENSIC_TEMPLATE_PATH, FORENSIC_TEMPLATE_SHA256


DEBIT_MEMO_PATTERN = re.compile(r"^[A-Za-z]{2}#\d+$")
DEBIT_MEMO_FIX_PATTERN = re.compile(r"^\s*([A-Za-z]{2})\s*#?\s*(\d+)\s*$")
WORKBOOK_NAMESPACE = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
RELATIONSHIP_NAMESPACE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_RELATIONSHIP_NAMESPACE = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_TYPE_NAMESPACE = "http://schemas.openxmlformats.org/package/2006/content-types"


def _text(value: object) -> str:
    return "" if value is None else str(value)


def _normal(value: object) -> str:
    return _text(value).strip().casefold()


def _has_valid_claim_spacing(value: str) -> bool:
    """Validate only the dynamic-text spacing structure: text + ` : ` + text."""
    if value != re.sub(r"\s+", " ", value.strip()):
        return False
    parts = value.split(" : ")
    return len(parts) == 2 and bool(parts[0]) and bool(parts[1])


def _normalized_claim_spacing(value: str) -> str | None:
    normalized = re.sub(r"\s*:\s*", " : ", re.sub(r"\s+", " ", value.strip()))
    return normalized if _has_valid_claim_spacing(normalized) else None


def _cell_label(sheet, label: str):
    expected = label.casefold()
    for row in sheet.iter_rows():
        for cell in row:
            if not isinstance(cell, MergedCell) and _normal(cell.value) == expected:
                return cell
    return None


def _coordinate(column: int, row: int, sheet) -> str:
    return sheet.cell(row, column).coordinate


def _issue(sheet: str, location: str, rule: str, message: str, expected: str = "", actual: str = "", fix_value: str | None = None) -> dict:
    return {
        "id": f"{rule}|{sheet}|{location}",
        "category": "format",
        "rule": rule,
        "sheet": sheet,
        "location": f"{sheet}!{location}" if location else sheet,
        "message": message,
        "expected": expected,
        "actual": actual,
        "fixable": fix_value is not None,
        "fix_value": fix_value,
    }


def _add_spacing_issue(issues: list[dict], sheet, cell, rule: str, expected: str) -> None:
    actual = _text(cell.value)
    if actual != actual.strip() or "  " in actual:
        proposed = re.sub(r" {2,}", " ", actual.strip())
        issues.append(
            _issue(
                sheet.title,
                cell.coordinate,
                rule,
                "Text has leading, trailing, or repeated spaces.",
                expected,
                actual,
                proposed,
            )
        )


def _claim_cell(sheet):
    label = _cell_label(sheet, "CUSTOMER CLAIM #")
    if label is None:
        return None
    candidates = [
        sheet.cell(label.row, column)
        for column in range(label.column + 1, sheet.max_column + 1)
        if sheet.cell(label.row, column).value is not None
    ]
    return candidates[-1] if candidates else None


def _debit_memo_cells(sheet):
    label = _cell_label(sheet, "DEBIT MEMO NOS.")
    if label is None:
        return []
    values = []
    for row in range(label.row + 1, sheet.max_row + 1):
        cell = sheet.cell(row, label.column)
        if cell.value is None:
            if values:
                break
            continue
        values.append(cell)
    return values


def _formula_text(value: object) -> str:
    return re.sub(r"\s+", "", _text(value)).upper()


@lru_cache(maxsize=1)
def _template_metadata(fingerprint: str) -> dict:
    """Open the approved template only when its verified fingerprint changes."""
    workbook = load_workbook(FORENSIC_TEMPLATE_PATH, read_only=True, data_only=False, keep_links=False)
    try:
        return {
            "name": FORENSIC_TEMPLATE_PATH.name,
            "sha256": fingerprint,
            "numbered_template_sheets": [sheet.title for sheet in workbook.worksheets if sheet.title.isdigit()],
        }
    finally:
        workbook.close()


def _locked_template_metadata() -> dict:
    if not FORENSIC_TEMPLATE_PATH.is_file():
        raise FileNotFoundError("The locked forensic template is missing.")
    fingerprint = hashlib.sha256(FORENSIC_TEMPLATE_PATH.read_bytes()).hexdigest()
    if fingerprint != FORENSIC_TEMPLATE_SHA256:
        raise ValueError("The locked forensic template has changed and must be re-approved.")
    return _template_metadata(fingerprint)


def _check_formulas(sheet, issues: list[dict]) -> None:
    style_header = _cell_label(sheet, "STYLE NO.")
    pcs_header = _cell_label(sheet, "PCS")
    price_header = _cell_label(sheet, "PRICE")
    amount_header = _cell_label(sheet, "AMOUNT")
    subtotal_label = _cell_label(sheet, "SUBTOTAL")
    adjustment_label = _cell_label(sheet, "ADJUSTMENT")
    total_label = _cell_label(sheet, "TOTAL")
    required = (style_header, pcs_header, price_header, amount_header, subtotal_label, adjustment_label, total_label)
    if not all(required):
        return

    start_row = max(style_header.row, pcs_header.row) + 1
    product_rows = [
        row
        for row in range(start_row, subtotal_label.row)
        if sheet.cell(row, style_header.column).value is not None
    ]
    if not product_rows:
        return

    for row in product_rows:
        amount_cell = sheet.cell(row, amount_header.column)
        expected = f"={_coordinate(price_header.column, row, sheet)}*{_coordinate(pcs_header.column, row, sheet)}"
        if _formula_text(amount_cell.value) != expected:
            issues.append(
                _issue(
                    sheet.title,
                    amount_cell.coordinate,
                    "amount_line_formula",
                    "AMOUNT must equal PRICE multiplied by PCS on the same row.",
                    expected,
                    _text(amount_cell.value),
                    expected,
                )
            )

    subtotal_cell = sheet.cell(subtotal_label.row, amount_header.column)
    expected_subtotal = f"=SUM({_coordinate(amount_header.column, product_rows[0], sheet)}:{_coordinate(amount_header.column, product_rows[-1], sheet)})"
    if _formula_text(subtotal_cell.value) != expected_subtotal:
        issues.append(
            _issue(
                sheet.title,
                subtotal_cell.coordinate,
                "subtotal_formula",
                "SUBTOTAL must sum all populated product-line AMOUNT cells.",
                expected_subtotal,
                _text(subtotal_cell.value),
                expected_subtotal,
            )
        )

    total_cell = sheet.cell(total_label.row, amount_header.column)
    expected_total = f"=SUM({_coordinate(amount_header.column, subtotal_label.row, sheet)}:{_coordinate(amount_header.column, adjustment_label.row, sheet)})"
    if _formula_text(total_cell.value) != expected_total:
        issues.append(
            _issue(
                sheet.title,
                total_cell.coordinate,
                "total_formula",
                "TOTAL must sum SUBTOTAL through ADJUSTMENT.",
                expected_total,
                _text(total_cell.value),
                expected_total,
            )
        )


def _check_style_numbers(sheet, issues: list[dict]) -> None:
    style_header = _cell_label(sheet, "STYLE NO.")
    subtotal_label = _cell_label(sheet, "SUBTOTAL")
    if style_header is None or subtotal_label is None:
        return
    first_row = style_header.row + 2
    seen: dict[str, list] = defaultdict(list)
    for row in range(first_row, subtotal_label.row):
        cell = sheet.cell(row, style_header.column)
        if cell.value is not None:
            seen[_normal(cell.value)].append(cell)
    for style, cells in seen.items():
        if style and len(cells) > 1:
            for cell in cells:
                other_rows = ", ".join(str(other.row) for other in cells if other.row != cell.row)
                issues.append(
                    _issue(
                        sheet.title,
                        cell.coordinate,
                        "duplicate_style_no",
                        f"STYLE NO. duplicates the same value on row(s) {other_rows}.",
                        "A unique STYLE NO.",
                        _text(cell.value),
                    )
                )


def _check_batch_sheet(workbook, issues: list[dict]) -> None:
    if "Batch" not in workbook.sheetnames:
        issues.append(_issue("Batch", "", "batch_sheet_missing", "The Batch worksheet is required by the approved template."))
        return
    sheet = workbook["Batch"]
    headers = ["#", "COMPANY", "DATE", "AMOUNT", "DB#", "CLAIM #", "RT #", "RT AMOUNT", "DISCREPANCY", "CREDIT OVER / UNDER"]
    for column, expected in enumerate(headers, start=1):
        cell = sheet.cell(7, column)
        if _text(cell.value) != expected:
            issues.append(_issue(sheet.title, cell.coordinate, "batch_header", "Batch header must match the approved template.", expected, _text(cell.value), expected))
    company_column, amount_column, first_entry_row = 2, 4, 8
    product_rows: list[int] = []
    for row in range(first_entry_row, sheet.max_row + 1):
        if sheet.cell(row, company_column).value is None:
            if product_rows:
                break
            continue
        product_rows.append(row)
    last_product_row = product_rows[-1] if product_rows else 25
    total_row = last_product_row + 1
    expected_total = f"=SUM(D{first_entry_row}:D{last_product_row})"
    total_cell = sheet.cell(total_row, amount_column)
    if _formula_text(total_cell.value) != expected_total:
        issues.append(_issue(sheet.title, total_cell.coordinate, "batch_total_formula", "Batch AMOUNT total must be placed immediately after the last product row.", expected_total, _text(total_cell.value), expected_total))
    for row in product_rows or list(range(first_entry_row, 26)):
        expected_number = row - 7
        cell = sheet.cell(row, 1)
        if cell.value != expected_number:
            issues.append(_issue(sheet.title, cell.coordinate, "batch_entry_number", "Batch entry rows must be numbered sequentially.", str(expected_number), _text(cell.value), expected_number))
    for row in product_rows:
        cell = sheet.cell(row, amount_column)
        if isinstance(cell.value, str) and _formula_text(cell.value).startswith("=SUM("):
            issues.append(_issue(sheet.title, cell.coordinate, "batch_total_misplaced", "Batch total formula is inside a product row and must be moved below the final product.", "A product amount", _text(cell.value), ""))


def _check_price_list(sheet, cached_sheet, issues: list[dict]) -> None:
    for coordinate, expected in {"A1": "Item #", "B1": "Description"}.items():
        if _text(sheet[coordinate].value) != expected:
            issues.append(_issue(sheet.title, coordinate, "price_list_header", "PRICE LIST header must match the approved template.", expected, _text(sheet[coordinate].value), expected))
    seen: set[str] = set()
    for row in range(2, sheet.max_row + 1):
        item_cell = sheet.cell(row, 1)
        item = _normal(item_cell.value)
        if item:
            if item in seen:
                issues.append(_issue(sheet.title, item_cell.coordinate, "price_list_duplicate_item", "PRICE LIST Item # must be distinct; the later duplicate row will be deleted.", "A distinct Item #", _text(item_cell.value), "Delete duplicate row"))
            seen.add(item)
        for cell in sheet[row]:
            if isinstance(cell.value, str) and cell.value.startswith("="):
                cached_value = cached_sheet[cell.coordinate].value
                issues.append(_issue(sheet.title, cell.coordinate, "price_list_formula", "PRICE LIST must contain stored values, not formulas.", "A stored value", cell.value, cached_value if cached_value is not None else None))


def _check_reason_sheet(workbook, issues: list[dict]) -> None:
    if "REASON" not in workbook.sheetnames:
        issues.append(_issue("REASON", "", "reason_sheet_missing", "The REASON worksheet is required by the approved template."))
        return
    sheet = workbook["REASON"]
    for coordinate, expected in {"A2": "Code", "B2": "Description"}.items():
        if _text(sheet[coordinate].value) != expected:
            issues.append(_issue(sheet.title, coordinate, "reason_header", "REASON header must match the approved template.", expected, _text(sheet[coordinate].value), expected))
    codes: set[str] = set()
    for row in range(3, sheet.max_row + 1):
        code, description = _normal(sheet.cell(row, 1).value), _normal(sheet.cell(row, 2).value)
        if not code and not description:
            continue
        if not code or not description:
            issues.append(_issue(sheet.title, f"A{row}" if not code else f"B{row}", "reason_row_incomplete", "Every populated REASON row needs both Code and Description."))
        elif code in codes:
            issues.append(_issue(sheet.title, f"A{row}", "reason_duplicate_code", "REASON Code must be distinct.", "A distinct Code", _text(sheet.cell(row, 1).value)))
        else:
            codes.add(code)
    for form in (sheet for sheet in workbook.worksheets if sheet.title.isdigit()):
        header = _cell_label(form, "REASON CODE")
        if header is None:
            continue
        code_cell = form.cell(header.row + 1, header.column)
        if _normal(code_cell.value) and _normal(code_cell.value) not in codes:
            issues.append(_issue(form.title, code_cell.coordinate, "reason_code_not_found", "REASON CODE is not listed on the REASON worksheet.", "A listed REASON Code", _text(code_cell.value)))


def scan_format_workbook(path: Path) -> dict:
    template = _locked_template_metadata()
    # External-link caches can be tens of megabytes but are not part of the
    # approved-format checks. Skipping them keeps large Credit Memo batches responsive.
    workbook = load_workbook(path, data_only=False, keep_links=False)
    cached_workbook = load_workbook(path, data_only=True, keep_links=False)
    issues: list[dict] = []
    numbered = [(int(sheet.title), sheet) for sheet in workbook.worksheets if sheet.title.isdigit()]
    numbered.sort(key=lambda item: item[0])

    if len(numbered) > 20:
        issues.append(_issue("Workbook", "", "numbered_sheet_count", "Only 20 numbered credit-memo worksheets are allowed.", "At most 20", str(len(numbered))))

    for number, sheet in numbered:
        if number < 1 or number > 20:
            issues.append(_issue(sheet.title, "", "numbered_sheet_name", "Numbered credit-memo worksheet must be named from 1 through 20.", "1 through 20", sheet.title))
            continue

        claim = _claim_cell(sheet)
        if claim is None:
            issues.append(_issue(sheet.title, "", "claim_cell_missing", "CUSTOMER CLAIM # row has no claim description value."))
        else:
            actual = _text(claim.value)
            expected = "<dynamic text> : <dynamic text>"
            if not _has_valid_claim_spacing(actual):
                fix_value = _normalized_claim_spacing(actual)
                issues.append(_issue(sheet.title, claim.coordinate, "claim_description_format", "Customer claim description has an invalid spacing or delimiter format.", expected, actual, fix_value))

        debit_cells = _debit_memo_cells(sheet)
        if not debit_cells:
            issues.append(_issue(sheet.title, "", "debit_memo_missing", "DEBIT MEMO NOS. has no memo value."))
        for cell in debit_cells:
            actual = _text(cell.value)
            if not DEBIT_MEMO_PATTERN.fullmatch(actual):
                match = DEBIT_MEMO_FIX_PATTERN.fullmatch(actual)
                fix_value = f"{match.group(1).upper()}#{match.group(2)}" if match else None
                issues.append(_issue(sheet.title, cell.coordinate, "debit_memo_format", "Debit memo must use an alphabetic prefix, #, and memo number.", "DB#534438", actual, fix_value))

        _check_formulas(sheet, issues)
        _check_style_numbers(sheet, issues)

    _check_batch_sheet(workbook, issues)
    if "PRICE LIST" in workbook.sheetnames:
        _check_price_list(workbook["PRICE LIST"], cached_workbook["PRICE LIST"], issues)
    else:
        issues.append(_issue("PRICE LIST", "", "price_list_sheet_missing", "The PRICE LIST worksheet is required by the approved template."))
    _check_reason_sheet(workbook, issues)
    cached_workbook.close()
    workbook.close()

    return {
        "issues": issues,
        "summary": {
            "total": len(issues),
            "fixable": sum(issue["fixable"] for issue in issues),
            "manual_review": sum(not issue["fixable"] for issue in issues),
            "numbered_sheets": len(numbered),
        },
        "template": template,
    }


def apply_format_fixes(source_path: Path, output_path: Path, issue_ids: list[str]) -> list[dict]:
    scan = scan_format_workbook(source_path)
    selected = {issue["id"]: issue for issue in scan["issues"] if issue["id"] in issue_ids}
    fixable = [issue for issue in selected.values() if issue["fixable"]]
    if not fixable:
        raise ValueError("No selected format findings can be safely corrected automatically.")

    workbook = load_workbook(source_path, data_only=False, keep_links=False)
    for issue in fixable:
        sheet = workbook[issue["sheet"]]
        coordinate = issue["location"].split("!", 1)[1]
        sheet[coordinate] = None if issue["rule"] == "batch_total_misplaced" else issue["fix_value"]
    workbook.save(output_path)
    return fixable


def fix_format_issues(source_path: Path, output_path: Path, issue_ids: list[str]) -> int:
    """Backward-compatible count-only wrapper for a safe format correction."""
    return len(apply_format_fixes(source_path, output_path, issue_ids))


def _copy_first_sheet(source_path: Path, target_workbook, target_name: str) -> tuple[str, int]:
    """Import review data without per-cell style cloning.

    Ageing workbooks can contain hundreds of thousands of cells.  The imported
    sheet is for traceability, so its values and formulas are retained while
    the expensive presentation-only styles are intentionally omitted.
    """
    source_workbook = load_workbook(source_path, data_only=False, read_only=True, keep_links=False)
    try:
        source = source_workbook.worksheets[0]
        if target_name in target_workbook.sheetnames:
            target_workbook.remove(target_workbook[target_name])
        target = target_workbook.create_sheet(target_name)
        for values in source.iter_rows(values_only=True):
            target.append([
                re.sub(r" {2,}", " ", value.strip())
                if isinstance(value, str) and not value.startswith("=")
                else value
                for value in values
            ])
        return source.title, source.max_row
    finally:
        source_workbook.close()


def _selected_fixable_issues(source_path: Path, issue_ids: list[str]) -> list[dict]:
    # A report-only download is valid: it preserves the batch and records
    # unresolved findings in the Forensic Log without applying a correction.
    if not issue_ids:
        return []
    scan = scan_format_workbook(source_path)
    selected = {issue["id"]: issue for issue in scan["issues"] if issue["id"] in issue_ids}
    fixable = [issue for issue in selected.values() if issue["fixable"]]
    if not fixable:
        raise ValueError("No selected format findings can be safely corrected automatically.")
    return fixable


def _apply_issues(workbook, fixed_issues: list[dict]) -> None:
    duplicate_rows: list[int] = []
    for issue in fixed_issues:
        if issue["rule"] == "price_list_duplicate_item" and issue["sheet"] == "PRICE LIST":
            coordinate = issue["location"].split("!", 1)[1]
            duplicate_rows.append(workbook["PRICE LIST"][coordinate].row)
            continue
        sheet = workbook[issue["sheet"]]
        coordinate = issue["location"].split("!", 1)[1]
        sheet[coordinate] = None if issue["rule"] == "batch_total_misplaced" else issue["fix_value"]
    for row in sorted(set(duplicate_rows), reverse=True):
        workbook["PRICE LIST"].delete_rows(row, 1)


def _clean_price_list(workbook, source_path: Path) -> list[dict]:
    """Freeze PRICE LIST formulas and retain only the first row per Item #."""
    if "PRICE LIST" not in workbook.sheetnames:
        return []
    price_list = workbook["PRICE LIST"]
    cached_workbook = load_workbook(source_path, data_only=True, read_only=False, keep_links=False)
    try:
        cached_sheet = cached_workbook["PRICE LIST"]
        changes: list[dict] = []
        for row in price_list.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formula = cell.value
                    cell.value = cached_sheet[cell.coordinate].value
                    changes.append({
                        "rule": "price_list_formula_to_value",
                        "location": f"PRICE LIST!{cell.coordinate}",
                        "actual": formula,
                        "fix_value": _text(cell.value),
                    })
                if isinstance(cell.value, str):
                    normalized = re.sub(r" {2,}", " ", cell.value.strip())
                    if normalized != cell.value:
                        original = cell.value
                        cell.value = normalized
                        changes.append({
                            "rule": "price_list_text_spacing",
                            "location": f"PRICE LIST!{cell.coordinate}",
                            "actual": original,
                            "fix_value": normalized,
                        })

        item_header = _cell_label(price_list, "ITEM #")
        if item_header is None:
            return changes
        seen: set[str] = set()
        duplicate_rows: list[int] = []
        for row in range(item_header.row + 1, price_list.max_row + 1):
            item_value = price_list.cell(row, item_header.column).value
            item_key = _normal(item_value)
            if not item_key:
                continue
            if item_key in seen:
                duplicate_rows.append(row)
                changes.append({
                    "rule": "price_list_duplicate_item",
                    "location": f"PRICE LIST!{price_list.cell(row, item_header.column).coordinate}",
                    "actual": _text(item_value),
                    "fix_value": "Deleted duplicate row",
                })
            else:
                seen.add(item_key)
        for row in reversed(duplicate_rows):
            price_list.delete_rows(row, 1)
        return changes
    finally:
        cached_workbook.close()


def _clean_workbook_text_spacing(workbook) -> list[dict]:
    """Apply the no-left/right/double-space rule to all non-formula text cells."""
    changes: list[dict] = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if not isinstance(cell.value, str) or cell.value.startswith("="):
                    continue
                normalized = re.sub(r" {2,}", " ", cell.value.strip())
                if normalized != cell.value:
                    original = cell.value
                    cell.value = normalized
                    changes.append({
                        "rule": "workbook_text_spacing",
                        "location": f"{sheet.title}!{cell.coordinate}",
                        "actual": original,
                        "fix_value": normalized,
                    })
    return changes


def _append_forensic_log(
    workbook,
    fixed_issues: list[dict],
    imported: list[tuple[str, str, int]],
    price_list_changes: list[dict] | None = None,
    source_spacing_changes: list[tuple[str, int]] | None = None,
    manual_issues: list[dict] | None = None,
) -> None:
    if "Forensic Log" in workbook.sheetnames:
        workbook.remove(workbook["Forensic Log"])
    log = workbook.create_sheet("Forensic Log")
    log.append(["Timestamp", "Action", "Rule", "Sheet", "Cell", "Original value", "Corrected value", "Status"])
    timestamp = datetime.now().isoformat(timespec="seconds")
    for issue in fixed_issues:
        sheet, coordinate = issue["location"].split("!", 1)
        log.append([timestamp, "Format fix", issue["rule"], sheet, coordinate, issue["actual"], issue["fix_value"], "Applied"])
    for issue in manual_issues or []:
        sheet, coordinate = issue["location"].split("!", 1)
        log.append([
            timestamp,
            "Manual correction required",
            issue["rule"],
            sheet,
            coordinate,
            issue["actual"],
            issue.get("expected", ""),
            "Manual review",
        ])
    for change in price_list_changes or []:
        sheet, coordinate = change["location"].split("!", 1)
        action = "PRICE LIST cleanup" if sheet == "PRICE LIST" else "Workbook text cleanup"
        log.append([timestamp, action, change["rule"], sheet, coordinate, change["actual"], change["fix_value"], "Applied"])
    for sheet, count in source_spacing_changes or []:
        if count:
            log.append([timestamp, "Source text cleanup", "workbook_text_spacing", sheet, "", f"{count} text cell(s)", "Spaces normalized", "Applied"])
    for target_name, source_name, rows in imported:
        log.append([timestamp, "Source import", "first_sheet_copy", target_name, "", source_name, f"{rows} row(s)", "Imported"])
    for cell in log[1]:
        header_font = copy(cell.font)
        header_font.bold = True
        cell.font = header_font
    log.freeze_panes = "A2"
    log.auto_filter.ref = f"A1:H{log.max_row}"
    for column in "ABCDEFGH":
        log.column_dimensions[column].width = 20


def _first_sheet_package_data(source_path: Path) -> tuple[str, int, bytes, int]:
    """Read one source sheet as XLSX XML, avoiding a large openpyxl cell graph."""
    with zipfile.ZipFile(source_path) as archive:
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        first_sheet = workbook.find(f"{{{WORKBOOK_NAMESPACE}}}sheets/{{{WORKBOOK_NAMESPACE}}}sheet")
        if first_sheet is None:
            raise ValueError(f"{source_path.name} has no worksheets.")
        relationship_id = first_sheet.attrib[f"{{{RELATIONSHIP_NAMESPACE}}}id"]
        relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        relationship = next(item for item in relationships if item.attrib.get("Id") == relationship_id)
        target = relationship.attrib["Target"].lstrip("/")
        sheet_path = target if target.startswith("xl/") else f"xl/{target}"
        sheet_xml = archive.read(sheet_path)
        dimension = re.search(rb'<dimension[^>]*ref="(?:[A-Z]+\d+:)?[A-Z]+(\d+)"', sheet_xml)
        rows = int(dimension.group(1)) if dimension else 0
        shared_strings = []
        if "xl/sharedStrings.xml" in archive.namelist():
            shared_xml = archive.read("xl/sharedStrings.xml")
            shared_strings = re.findall(rb"<si>(.*?)</si>|<si/>", shared_xml, flags=re.DOTALL)
    sheet_xml = re.sub(rb' s="\d+"', b"", sheet_xml)

    def inline_string(match: re.Match[bytes]) -> bytes:
        attributes = match.group("before") + match.group("after")
        index = int(match.group("index"))
        content = shared_strings[index] if index < len(shared_strings) else b""
        return b'<c' + attributes + b' t="inlineStr"><is>' + content + b"</is></c>"

    sheet_xml = re.sub(
        rb'<c(?P<before>[^>]*)\bt="s"(?P<after>[^>]*)><v>(?P<index>\d+)</v></c>',
        inline_string,
        sheet_xml,
    )
    text_changes = 0

    def normalize_text(match: re.Match[bytes]) -> bytes:
        nonlocal text_changes
        original = match.group("value")
        normalized = re.sub(rb" {2,}", b" ", original.strip())
        if normalized != original:
            text_changes += 1
        return match.group("open") + normalized + match.group("close")

    sheet_xml = re.sub(
        rb'(?P<open><t(?:\s[^>]*)?>)(?P<value>.*?)(?P<close></t>)',
        normalize_text,
        sheet_xml,
        flags=re.DOTALL,
    )
    return first_sheet.attrib["name"], rows, sheet_xml, text_changes


def _append_source_sheets_to_package(output_path: Path, source_data: list[tuple[str, str, int, bytes, int]]) -> None:
    """Add source review sheets directly to the completed XLSX package.

    This prevents openpyxl from instantiating and styling every Ageing cell.
    Source-cell presentation styles are removed, but values and formulas stay
    intact for review in the verified workbook.
    """
    with zipfile.ZipFile(output_path) as archive:
        files = {entry.filename: archive.read(entry.filename) for entry in archive.infolist()}

    workbook = ET.fromstring(files["xl/workbook.xml"])
    relationships = ET.fromstring(files["xl/_rels/workbook.xml.rels"])
    content_types = ET.fromstring(files["[Content_Types].xml"])
    sheets = workbook.find(f"{{{WORKBOOK_NAMESPACE}}}sheets")
    sheet_ids = [int(sheet.attrib["sheetId"]) for sheet in sheets]
    relationship_ids = [
        int(match.group(1))
        for relationship in relationships
        if (match := re.fullmatch(r"rId(\d+)", relationship.attrib.get("Id", "")))
    ]
    worksheet_numbers = [
        int(match.group(1))
        for name in files
        if (match := re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", name))
    ]
    for target_name, _, _, sheet_xml, _ in source_data:
        sheet_id = max(sheet_ids, default=0) + 1
        relationship_id = max(relationship_ids, default=0) + 1
        worksheet_number = max(worksheet_numbers, default=0) + 1
        sheet_ids.append(sheet_id)
        relationship_ids.append(relationship_id)
        worksheet_numbers.append(worksheet_number)
        worksheet_path = f"xl/worksheets/sheet{worksheet_number}.xml"
        sheets.append(ET.Element(f"{{{WORKBOOK_NAMESPACE}}}sheet", {
            "name": target_name,
            "sheetId": str(sheet_id),
            f"{{{RELATIONSHIP_NAMESPACE}}}id": f"rId{relationship_id}",
        }))
        relationships.append(ET.Element(f"{{{PACKAGE_RELATIONSHIP_NAMESPACE}}}Relationship", {
            "Id": f"rId{relationship_id}",
            "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
            "Target": f"worksheets/sheet{worksheet_number}.xml",
        }))
        content_types.append(ET.Element(f"{{{CONTENT_TYPE_NAMESPACE}}}Override", {
            "PartName": f"/{worksheet_path}",
            "ContentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml",
        }))
        files[worksheet_path] = sheet_xml
    files["xl/workbook.xml"] = ET.tostring(workbook, encoding="utf-8", xml_declaration=True)
    files["xl/_rels/workbook.xml.rels"] = ET.tostring(relationships, encoding="utf-8", xml_declaration=True)
    files["[Content_Types].xml"] = ET.tostring(content_types, encoding="utf-8", xml_declaration=True)
    staging_path = output_path.with_name(f"{output_path.stem}.source-import.tmp{output_path.suffix}")
    with zipfile.ZipFile(staging_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in files.items():
            archive.writestr(name, content)
    staging_path.replace(output_path)


def create_corrected_workbook(
    source_path: Path,
    output_path: Path,
    issue_ids: list[str],
    ageing_path: Path,
    write_up_path: Path,
) -> list[dict]:
    """Create the full verified workbook with one Credit Memo save operation."""
    manual_issues = [issue for issue in scan_format_workbook(source_path)["issues"] if not issue["fixable"]]
    fixed_issues = _selected_fixable_issues(source_path, issue_ids)
    workbook = load_workbook(source_path, data_only=False, keep_vba=source_path.suffix.lower() == ".xlsm", keep_links=False)
    _apply_issues(workbook, fixed_issues)
    price_list_changes = _clean_price_list(workbook, source_path)
    price_list_changes.extend(_clean_workbook_text_spacing(workbook))
    for generated_name in ("Ageing", "Write-Up", "Forensic Log"):
        if generated_name in workbook.sheetnames:
            workbook.remove(workbook[generated_name])
    source_data = [
        ("Ageing", *_first_sheet_package_data(ageing_path)),
        ("Write-Up", *_first_sheet_package_data(write_up_path)),
    ]
    imported = [(target_name, source_name, rows) for target_name, source_name, rows, _, _ in source_data]
    source_spacing_changes = [(target_name, changes) for target_name, _, _, _, changes in source_data]
    _append_forensic_log(workbook, fixed_issues, imported, price_list_changes, source_spacing_changes, manual_issues)
    workbook.save(output_path)
    _append_source_sheets_to_package(output_path, source_data)
    return fixed_issues


def add_forensic_log_and_sources(
    output_path: Path,
    ageing_path: Path,
    write_up_path: Path,
    fixed_issues: list[dict],
) -> None:
    """Append first source sheets and a traceable correction log to the generated memo copy."""
    workbook = load_workbook(output_path, data_only=False, keep_vba=output_path.suffix.lower() == ".xlsm", keep_links=False)
    spacing_changes = _clean_workbook_text_spacing(workbook)
    imported = [
        ("Ageing", *_copy_first_sheet(ageing_path, workbook, "Ageing")),
        ("Write-Up", *_copy_first_sheet(write_up_path, workbook, "Write-Up")),
    ]
    _append_forensic_log(workbook, fixed_issues, imported, spacing_changes)
    workbook.save(output_path)
