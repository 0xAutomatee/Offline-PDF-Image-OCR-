from pathlib import Path

from openpyxl import Workbook, load_workbook

from app.services.forensic_format import add_forensic_log_and_sources, create_corrected_workbook, fix_format_issues, scan_format_workbook


def build_credit_memo(path: Path, claim: str = "Freight Allowance : 2700-1481307865"):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "1"
    sheet["A10"] = "CUSTOMER CLAIM #"
    sheet["E10"] = claim
    sheet["A11"] = "STYLE NO."
    sheet["G11"] = "PRICE"
    sheet["I11"] = "AMOUNT"
    sheet["D12"] = "PCS"
    sheet["A13"], sheet["D13"], sheet["G13"], sheet["I13"] = "4257", 1, 3.2, "=G13*D13"
    sheet["A14"], sheet["D14"], sheet["G14"], sheet["I14"] = "50184B-4", 2, 0.65, "=G14*D14"
    sheet["E15"], sheet["I15"] = "SUBTOTAL", "=SUM(I13:I14)"
    sheet["E16"] = "GST/HST"
    sheet["E17"] = "FREIGHT/HANDLING"
    sheet["E18"], sheet["I18"] = "ADJUSTMENT", 0.24
    sheet["G19"], sheet["I19"] = "TOTAL", "=SUM(I15:I18)"
    sheet["A20"], sheet["A21"] = "DEBIT MEMO NOS.", "DB#534438"
    price_list = workbook.create_sheet("PRICE LIST")
    price_list.append(["Item #", "Description"])
    reason = workbook.create_sheet("REASON")
    reason["A2"], reason["B2"] = "Code", "Description"
    reason["A3"], reason["B3"] = "FA", "Freight Allowance"
    batch = workbook.create_sheet("Batch")
    for column, value in enumerate(["#", "COMPANY", "DATE", "AMOUNT", "DB#", "CLAIM #", "RT #", "RT AMOUNT", "DISCREPANCY", "CREDIT OVER / UNDER"], start=1):
        batch.cell(7, column).value = value
    for row in range(8, 26):
        batch.cell(row, 1).value = row - 7
    batch["D26"] = "=SUM(D8:D25)"
    workbook.save(path)


def test_valid_credit_memo_has_no_forensic_format_findings(tmp_path: Path):
    source = tmp_path / "credit-memo.xlsx"
    build_credit_memo(source)
    assert scan_format_workbook(source)["issues"] == []


def test_dynamic_claim_description_uses_structure_not_a_fixed_value(tmp_path: Path):
    source = tmp_path / "credit-memo.xlsx"
    build_credit_memo(source, "Discount & Allowance : SPA-2800/1481282230")
    assert scan_format_workbook(source)["issues"] == []


def test_forensic_scan_reports_formula_duplicate_and_spacing_findings(tmp_path: Path):
    source = tmp_path / "credit-memo.xlsx"
    build_credit_memo(source, "Freight Allowance: 2700-1481307865")
    workbook = load_workbook(source)
    sheet = workbook["1"]
    sheet["A14"] = "4257"
    sheet["I14"] = 1.3
    sheet["A21"] = " DB#534438 "
    workbook.save(source)

    issues = scan_format_workbook(source)["issues"]
    assert {issue["rule"] for issue in issues} == {"claim_description_format", "debit_memo_format", "amount_line_formula", "duplicate_style_no"}
    assert any(issue["fixable"] for issue in issues)


def test_debit_memo_spacing_is_a_safe_automatic_fix(tmp_path: Path):
    source, corrected = tmp_path / "credit-memo.xlsx", tmp_path / "corrected.xlsx"
    build_credit_memo(source)
    workbook = load_workbook(source)
    workbook["1"]["A21"] = "DB 534323"
    workbook.save(source)

    issue = next(issue for issue in scan_format_workbook(source)["issues"] if issue["rule"] == "debit_memo_format")
    assert issue["fixable"]
    assert issue["fix_value"] == "DB#534323"
    fix_format_issues(source, corrected, [issue["id"]])
    assert load_workbook(corrected)["1"]["A21"].value == "DB#534323"


def test_safe_format_fix_creates_corrected_copy(tmp_path: Path):
    source, corrected = tmp_path / "credit-memo.xlsx", tmp_path / "corrected.xlsx"
    build_credit_memo(source, "Freight Allowance: 2700-1481307865")
    issue = scan_format_workbook(source)["issues"][0]
    assert issue["fixable"]
    assert fix_format_issues(source, corrected, [issue["id"]]) == 1
    assert load_workbook(corrected)["1"]["E10"].value == "Freight Allowance : 2700-1481307865"


def test_claim_description_spacing_is_a_safe_automatic_fix(tmp_path: Path):
    source, corrected = tmp_path / "credit-memo.xlsx", tmp_path / "corrected.xlsx"
    build_credit_memo(source, " Discount  Allowance: SPA - 2800 / 1481282230 ")
    issue = next(issue for issue in scan_format_workbook(source)["issues"] if issue["rule"] == "claim_description_format")
    assert issue["fixable"]
    assert issue["fix_value"] == "Discount Allowance : SPA - 2800 / 1481282230"
    fix_format_issues(source, corrected, [issue["id"]])
    assert load_workbook(corrected)["1"]["E10"].value == "Discount Allowance : SPA - 2800 / 1481282230"


def test_batch_price_list_and_reason_template_rules_are_scanned(tmp_path: Path):
    source = tmp_path / "credit-memo.xlsx"
    build_credit_memo(source)
    workbook = load_workbook(source)
    workbook["Batch"]["D7"] = "Total"
    workbook["Batch"]["D26"] = 0
    workbook["Batch"]["A8"] = 99
    workbook["PRICE LIST"].append(["SKU-1", "First"])
    workbook["PRICE LIST"].append(["SKU-1", "=A3"])
    workbook["REASON"]["A4"] = "FA"
    workbook["REASON"]["B4"] = "Duplicate"
    workbook["1"]["C8"] = "REASON CODE"
    workbook["1"]["C9"] = "NOT-LISTED"
    workbook.save(source)

    rules = {issue["rule"] for issue in scan_format_workbook(source)["issues"]}
    assert {"batch_header", "batch_total_formula", "batch_entry_number", "price_list_formula", "price_list_duplicate_item", "reason_duplicate_code", "reason_code_not_found"} <= rules


def test_batch_total_moves_below_the_last_product_row(tmp_path: Path):
    source, corrected = tmp_path / "credit-memo.xlsx", tmp_path / "corrected.xlsx"
    build_credit_memo(source)
    workbook = load_workbook(source)
    batch = workbook["Batch"]
    for row in range(8, 28):
        batch.cell(row, 1).value = row - 7
        batch.cell(row, 2).value = "AMAZON.COM,INC."
        batch.cell(row, 4).value = row
    batch["D26"] = "=SUM(D8:D25)"
    batch["D28"] = 999
    workbook.save(source)

    issues = scan_format_workbook(source)["issues"]
    selected = [issue["id"] for issue in issues if issue["rule"] in {"batch_total_formula", "batch_total_misplaced"}]
    fix_format_issues(source, corrected, selected)
    batch = load_workbook(corrected, data_only=False)["Batch"]
    assert batch["D26"].value is None
    assert batch["D28"].value == "=SUM(D8:D27)"


def test_corrected_memo_includes_source_sheets_and_forensic_log(tmp_path: Path):
    memo, ageing, write_up = tmp_path / "memo.xlsx", tmp_path / "ageing.xlsx", tmp_path / "write-up.xlsx"
    build_credit_memo(memo)
    workbook = load_workbook(memo)
    workbook["Batch"]["A1"] = "  Batch  note  "
    workbook.save(memo)
    for path, sheet_name, value in ((ageing, "Ledger", "  Ageing  source  "), (write_up, "Input", "Write-Up source")):
        workbook = Workbook()
        workbook.active.title = sheet_name
        workbook.active["A1"] = value
        workbook.save(path)

    add_forensic_log_and_sources(
        memo,
        ageing,
        write_up,
        [{"location": "1!E10", "rule": "claim_description_format", "actual": "bad", "fix_value": "good"}],
    )
    workbook = load_workbook(memo)
    assert workbook["Ageing"]["A1"].value == "Ageing source"
    assert workbook["Write-Up"]["A1"].value == "Write-Up source"
    assert workbook["Forensic Log"]["B2"].value == "Format fix"
    assert workbook["Forensic Log"].auto_filter.ref == f"A1:H{workbook['Forensic Log'].max_row}"
    assert "Batch" in workbook.sheetnames


def test_fast_verified_download_keeps_sources_and_batch(tmp_path: Path):
    memo, ageing, write_up, corrected = (tmp_path / "memo.xlsx", tmp_path / "ageing.xlsx", tmp_path / "write-up.xlsx", tmp_path / "corrected.xlsx")
    build_credit_memo(memo, "Freight Allowance: 2700-1481307865")
    workbook = load_workbook(memo)
    workbook["Batch"]["A1"] = "  Batch  note  "
    workbook.save(memo)
    for path, sheet_name, value in ((ageing, "Ledger", "Ageing source"), (write_up, "Input", "Write-Up source")):
        workbook = Workbook()
        workbook.active.title = sheet_name
        workbook.active["A1"] = value
        workbook.save(path)

    issue = scan_format_workbook(memo)["issues"][0]
    create_corrected_workbook(memo, corrected, [issue["id"]], ageing, write_up)
    workbook = load_workbook(corrected, data_only=False)
    assert workbook["1"]["E10"].value == "Freight Allowance : 2700-1481307865"
    assert workbook["Ageing"]["A1"].value == "Ageing source"
    assert workbook["Write-Up"]["A1"].value == "Write-Up source"
    assert "Batch" in workbook.sheetnames
    assert workbook["Batch"]["A1"].value == "Batch note"


def test_verified_download_logs_manual_review_findings(tmp_path: Path):
    memo, ageing, write_up, corrected = (tmp_path / "memo.xlsx", tmp_path / "ageing.xlsx", tmp_path / "write-up.xlsx", tmp_path / "corrected.xlsx")
    build_credit_memo(memo, "Freight Allowance: 2700-1481307865")
    workbook = load_workbook(memo)
    workbook["1"]["A14"] = "4257"
    workbook.save(memo)
    for path in (ageing, write_up):
        source = Workbook()
        source.save(path)

    fixable_issue = next(issue for issue in scan_format_workbook(memo)["issues"] if issue["fixable"])
    create_corrected_workbook(memo, corrected, [fixable_issue["id"]], ageing, write_up)

    log = load_workbook(corrected, data_only=False)["Forensic Log"]
    assert any(
        row[1].value == "Manual correction required"
        and row[2].value == "duplicate_style_no"
        and row[6].value == "A unique STYLE NO."
        and row[7].value == "Manual review"
        for row in log.iter_rows(min_row=2)
    )


def test_report_only_download_allows_manual_findings_without_safe_fixes(tmp_path: Path):
    memo, ageing, write_up, report = (tmp_path / "memo.xlsx", tmp_path / "ageing.xlsx", tmp_path / "write-up.xlsx", tmp_path / "report.xlsx")
    build_credit_memo(memo, "Void")
    for path in (ageing, write_up):
        Workbook().save(path)

    assert create_corrected_workbook(memo, report, [], ageing, write_up) == []

    log = load_workbook(report, data_only=False)["Forensic Log"]
    assert any(
        row[1].value == "Manual correction required"
        and row[2].value == "claim_description_format"
        and row[7].value == "Manual review"
        for row in log.iter_rows(min_row=2)
    )


def test_verified_download_freezes_price_list_formulas_and_removes_duplicate_items(tmp_path: Path):
    memo, ageing, write_up, corrected = (tmp_path / "memo.xlsx", tmp_path / "ageing.xlsx", tmp_path / "write-up.xlsx", tmp_path / "corrected.xlsx")
    build_credit_memo(memo, "Freight Allowance: 2700-1481307865")
    workbook = load_workbook(memo)
    price_list = workbook["PRICE LIST"]
    price_list.append([" Item-1 ", "  First  description  "])
    price_list.append(["Item-1", "=A3"])
    price_list.append(["Item-2", "=A4"])
    workbook.save(memo)
    for path in (ageing, write_up):
        workbook = Workbook()
        workbook.save(path)

    issue = scan_format_workbook(memo)["issues"][0]
    create_corrected_workbook(memo, corrected, [issue["id"]], ageing, write_up)
    workbook = load_workbook(corrected, data_only=False)
    price_list = workbook["PRICE LIST"]
    assert [price_list.cell(row, 1).value for row in range(2, price_list.max_row + 1)] == ["Item-1", "Item-2"]
    assert price_list["B2"].value == "First description"
    assert all(not (isinstance(cell.value, str) and cell.value.startswith("=")) for row in price_list.iter_rows() for cell in row)
    assert any(row[2].value == "price_list_duplicate_item" for row in workbook["Forensic Log"].iter_rows(min_row=2))
    assert any(row[2].value == "price_list_text_spacing" for row in workbook["Forensic Log"].iter_rows(min_row=2))
