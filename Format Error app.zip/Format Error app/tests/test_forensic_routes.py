import asyncio

from app.api import routes_forensic


def test_scan_reuses_saved_memo_when_file_picker_is_empty(monkeypatch):
    def restore_saved(source_type, destination):
        destination.write_bytes(b"saved workbook")
        return f"saved-{source_type}.xlsx"

    monkeypatch.setattr(routes_forensic, "restore_source", restore_saved)
    monkeypatch.setattr(
        routes_forensic,
        "scan_format_workbook",
        lambda _: {"issues": [], "summary": {"total": 0, "fixable": 0, "manual_review": 0, "numbered_sheets": 1}},
    )

    response = asyncio.run(routes_forensic.scan(None, None, None))

    assert response["sources"] == {
        "ageing": "saved-ageing.xlsx",
        "write_up": "saved-write_up.xlsx",
        "memo": "saved-memo.xlsx",
    }
