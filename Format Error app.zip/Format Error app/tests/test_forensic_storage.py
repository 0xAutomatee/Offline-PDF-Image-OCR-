from pathlib import Path

from app.services.forensic_storage import restore_source, save_source, saved_sources


def test_saves_and_restores_latest_source_workbook(tmp_path: Path):
    database = tmp_path / "forensic.sqlite3"
    storage = tmp_path / "Storage"
    source, restored = tmp_path / "source.xlsx", tmp_path / "restored.xlsx"
    source.write_bytes(b"workbook-one")
    save_source("ageing", "ageing.xlsx", source, database, storage)

    source.write_bytes(b"workbook-two")
    save_source("ageing", "updated-ageing.xlsx", source, database, storage)

    assert (storage / "ageing.xlsx").read_bytes() == b"workbook-two"
    assert saved_sources(database, storage) == {"ageing": "updated-ageing.xlsx"}
    assert restore_source("ageing", restored, database, storage) == "updated-ageing.xlsx"
    assert restored.read_bytes() == b"workbook-two"

    database.unlink()
    restored.unlink()
    assert restore_source("ageing", restored, database, storage) == "ageing.xlsx"
    assert restored.read_bytes() == b"workbook-two"
