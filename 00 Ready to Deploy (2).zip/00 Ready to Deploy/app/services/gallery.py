"""Local gallery file operations."""

from __future__ import annotations

import mimetypes
import json
import shutil
from pathlib import Path
from urllib.parse import quote

from fastapi import HTTPException
from fastapi.responses import Response
from .storage_layout import PDFS, migrate_legacy_gallery


PROJECT_DIR = Path(__file__).resolve().parents[2]
GALLERY_DIR = PROJECT_DIR / "BOL images"


def ensure_gallery_dir() -> Path:
    GALLERY_DIR.mkdir(exist_ok=True)
    migrate_legacy_gallery()
    return GALLERY_DIR


def gallery_cards(query: str = "", trash: bool = False, include_text: bool = True) -> list[dict[str, str | int | bool]]:
    """Return only gallery pages that currently exist on disk.

    OCR manifests remain the source of metadata, while the JPG existence check
    prevents the browser from receiving cards for deleted or moved files.
    """
    # Every gallery refresh also upgrades any older page-image location.
    migrate_legacy_gallery()
    normalized_query = query.casefold().strip()
    cards: list[dict[str, str | int | bool]] = []
    for manifest_path in PDFS.rglob("ocr-results.json"):
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue

        source_name = Path(str(manifest.get("source_pdf", ""))).name
        source_path = manifest_path.parent / source_name
        image_dir = GALLERY_DIR / str(manifest.get("images_folder", ""))
        if not image_dir.is_dir():
            image_dir = manifest_path.parent
        searchable_name = str(manifest.get("searchable_pdf") or f"{Path(source_name).stem} Searchable.pdf")
        searchable_path = manifest_path.parent / searchable_name
        if not searchable_path.is_file():
            candidates = sorted(
                path for path in manifest_path.parent.glob("* Searchable.pdf") if path.is_file()
            )
            if len(candidates) == 1:
                searchable_path = candidates[0]

        for page in manifest.get("pages", []):
            image_name = str(page.get("image", ""))
            image_path = image_dir / image_name
            trash_path = image_dir / "Trash" / image_name
            is_trash = not image_path.is_file() and trash_path.is_file()
            active_path = trash_path if is_trash else image_path
            if not active_path.is_file() or is_trash != trash:
                continue

            page_text = str(page.get("searchable_text", ""))
            card: dict[str, str | int | bool] = {
                "image": active_path.relative_to(GALLERY_DIR).as_posix(),
                "name": active_path.name,
                "pdf": str(manifest.get("source_pdf", "")),
                "page": int(page.get("page", 0)),
                "date": str(manifest.get("processed_at", ""))[:10] or "Unknown date",
                "processed_at": str(manifest.get("processed_at", "")),
                "text": (page_text if include_text or normalized_query else page_text[:600]),
                "trash": is_trash,
                "source_pdf": source_path.relative_to(GALLERY_DIR).as_posix() if source_path.is_file() else "",
                "searchable_pdf": searchable_path.relative_to(GALLERY_DIR).as_posix() if searchable_path.is_file() else "",
                "pdf_folder": manifest_path.parent.relative_to(GALLERY_DIR).as_posix(),
                "image_folder": image_dir.relative_to(GALLERY_DIR).as_posix(),
            }
            if not normalized_query or normalized_query in " ".join([str(value) for value in card.values()] + [page_text]).casefold():
                cards.append(card)

    if not trash:
        processing_root = GALLERY_DIR / "_Processing"
        for state_path in processing_root.glob("*/processing-state.json"):
            try:
                state = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if state.get("status") == "complete":
                continue
            source_name = Path(str(state.get("source_pdf", ""))).name
            searchable_name = str(state.get("searchable_pdf") or f"{Path(source_name).stem} Searchable.pdf")
            searchable_path = state_path.parent / searchable_name
            if not searchable_path.is_file():
                continue
            card = {
                "image": "",
                "name": source_name,
                "pdf": source_name,
                "page": 0,
                "date": "Processing",
                "text": "Searchable PDF is ready. Image rendering and OCR are still processing.",
                "trash": False,
                "processing": True,
                "source_pdf": "",
                "searchable_pdf": searchable_path.relative_to(GALLERY_DIR).as_posix(),
            }
            if not normalized_query or normalized_query in " ".join(str(value) for value in card.values()).casefold():
                cards.append(card)
    return cards


def delete_pdf_output(relative_folder: str) -> dict[str, str]:
    """Permanently delete one user-selected PDF output and its registry rows."""
    root = ensure_gallery_dir().resolve()
    target = (root / relative_folder).resolve()
    if PDFS.resolve() not in target.parents or not target.is_dir():
        raise HTTPException(status_code=404, detail="PDF output folder not found.")
    manifest_path = target / "ocr-results.json"
    if not manifest_path.is_file():
        raise HTTPException(status_code=404, detail="This folder is not a processed PDF output.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=409, detail=f"Could not read PDF record: {error}") from error
    source_sha256 = str(manifest.get("source_sha256", ""))
    shutil.rmtree(target)
    from .integrity import delete_database_record

    delete_database_record(source_sha256)
    return {"status": "deleted", "pdf": str(manifest.get("source_pdf", ""))}


def local_image(relative_path: str) -> Path:
    root = ensure_gallery_dir().resolve()
    target = (root / relative_path).resolve()
    if root not in target.parents or not target.is_file() or target.suffix.lower() not in {".jpg", ".jpeg"}:
        raise HTTPException(status_code=404, detail="Image not found")
    return target


def download_response(relative_path: str) -> Response:
    """Download a local image or PDF without widening Trash file operations."""
    root = ensure_gallery_dir().resolve()
    target = (root / relative_path).resolve()
    if root not in target.parents or not target.is_file() or target.suffix.lower() not in {".jpg", ".jpeg", ".pdf"}:
        raise HTTPException(status_code=404, detail="Download file not found")
    return Response(
        content=target.read_bytes(),
        media_type=mimetypes.guess_type(target.name)[0] or "application/octet-stream",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(target.name)}"},
    )


def move_to_trash(relative_path: str) -> dict[str, str]:
    image = local_image(relative_path)
    if image.parent.name == "Trash":
        return {"status": "already in trash"}
    trash_dir = image.parent / "Trash"
    trash_dir.mkdir(exist_ok=True)
    destination = trash_dir / image.name
    if destination.exists():
        raise HTTPException(status_code=409, detail="An image with this name is already in Trash.")
    shutil.move(str(image), str(destination))
    return {"status": "moved to trash"}


def restore_from_trash(relative_path: str) -> dict[str, str]:
    image = local_image(relative_path)
    if image.parent.name != "Trash":
        return {"status": "already restored"}
    destination = image.parent.parent / image.name
    if destination.exists():
        raise HTTPException(status_code=409, detail="An image with this name already exists outside Trash.")
    shutil.move(str(image), str(destination))
    return {"status": "restored"}



