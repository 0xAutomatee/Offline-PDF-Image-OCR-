"""Services for the BOL Images application."""
