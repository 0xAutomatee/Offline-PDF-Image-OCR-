import base64
import os
import subprocess
import sys
from functools import lru_cache
from pathlib import Path

import httpx
from openai import OpenAI

OCR_PROMPT = """Extract all readable text from this document page exactly as shown.
Preserve headings, labels, numbers, dates, and table rows where possible. Do not invent
missing values. After the transcription, list any unreadable or uncertain content under
the heading `Exceptions:`."""

PROVIDERS = {
    "openai": {"label": "OpenAI", "key_env": "OPENAI_API_KEY", "model_env": "OPENAI_OCR_MODEL", "default_model": "gpt-4.1-mini"},
    "anthropic": {"label": "Anthropic Claude", "key_env": "ANTHROPIC_API_KEY", "model_env": "ANTHROPIC_OCR_MODEL", "default_model": "claude-sonnet-4-5"},
    "gemini": {"label": "Google Gemini", "key_env": "GEMINI_API_KEY", "model_env": "GEMINI_OCR_MODEL", "default_model": "gemini-2.5-flash"},
    "compatible": {"label": "OpenAI-compatible API", "key_env": "COMPATIBLE_API_KEY", "model_env": "COMPATIBLE_OCR_MODEL", "default_model": ""},
    "ocrmypdf": {"label": "OCRmyPDF (local)", "key_env": "", "model_env": "", "default_model": "local"},
    "pymupdf": {"label": "PyMuPDF (local)", "key_env": "", "model_env": "", "default_model": "local"},
    "rapidocr": {"label": "RapidOCR (local)", "key_env": "", "model_env": "", "default_model": "local"},
}


def resolve_provider(provider: str, requested_model: str) -> tuple[str, str, str]:
    if provider not in PROVIDERS:
        raise ValueError("Select a supported OCR provider.")
    settings = PROVIDERS[provider]
    if provider in {"ocrmypdf", "pymupdf", "rapidocr"}:
        return "", "local", settings["label"]
    api_key = os.getenv(settings["key_env"], "").strip()
    model = requested_model.strip() or os.getenv(settings["model_env"], settings["default_model"]).strip()
    if not api_key:
        raise ValueError(f"{settings['key_env']} is not configured in .env.")
    if not model:
        raise ValueError(f"Choose a model or set {settings['model_env']} in .env.")
    if provider == "compatible" and not os.getenv("COMPATIBLE_API_BASE_URL", "").strip():
        raise ValueError("COMPATIBLE_API_BASE_URL is not configured in .env.")
    return api_key, model, settings["label"]


def _image_base64(image_path: Path) -> str:
    return base64.b64encode(image_path.read_bytes()).decode("ascii")


def _openai_response(image_data: str, api_key: str, model: str, base_url: str | None = None) -> str:
    client = OpenAI(api_key=api_key, base_url=base_url)
    response = client.responses.create(
        model=model,
        input=[{"role": "user", "content": [
            {"type": "input_text", "text": OCR_PROMPT},
            {"type": "input_image", "image_url": f"data:image/png;base64,{image_data}"},
        ]}],
    )
    return response.output_text.strip()


def _anthropic_response(image_data: str, api_key: str, model: str) -> str:
    response = httpx.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
        json={"model": model, "max_tokens": 4096, "messages": [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": image_data}},
            {"type": "text", "text": OCR_PROMPT},
        ]}]}, timeout=120,
    )
    response.raise_for_status()
    return "\n".join(part["text"] for part in response.json()["content"] if part.get("type") == "text").strip()


def _gemini_response(image_data: str, api_key: str, model: str) -> str:
    response = httpx.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        headers={"x-goog-api-key": api_key},
        json={"contents": [{"parts": [
            {"inline_data": {"mime_type": "image/png", "data": image_data}},
            {"text": OCR_PROMPT},
        ]}]}, timeout=120,
    )
    response.raise_for_status()
    parts = response.json()["candidates"][0]["content"]["parts"]
    return "\n".join(part["text"] for part in parts if "text" in part).strip()


def _compatible_response(image_data: str, api_key: str, model: str, base_url: str) -> str:
    """Call the broadly supported OpenAI-compatible Chat Completions vision format."""
    response = httpx.post(
        f"{base_url.rstrip('/')}/chat/completions",
        headers={"Authorization": f"Bearer {api_key}"},
        json={"model": model, "messages": [{"role": "user", "content": [
            {"type": "text", "text": OCR_PROMPT},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_data}"}},
        ]}]}, timeout=120,
    )
    response.raise_for_status()
    content = response.json()["choices"][0]["message"]["content"]
    return content if isinstance(content, str) else "\n".join(part.get("text", "") for part in content).strip()


def extract_page_text(image_path: Path, provider: str, model: str) -> str:
    """Extract OCR text with the selected configured AI provider."""
    api_key, resolved_model, _ = resolve_provider(provider, model)
    image_data = _image_base64(image_path)
    if provider == "openai":
        return _openai_response(image_data, api_key, resolved_model)
    if provider == "anthropic":
        return _anthropic_response(image_data, api_key, resolved_model)
    if provider == "gemini":
        return _gemini_response(image_data, api_key, resolved_model)
    return _compatible_response(image_data, api_key, resolved_model, os.getenv("COMPATIBLE_API_BASE_URL", ""))


@lru_cache(maxsize=1)
def _rapidocr_engine():
    try:
        from rapidocr import RapidOCR
    except ImportError as error:
        raise RuntimeError("RapidOCR is not installed. Run: python -m pip install rapidocr onnxruntime") from error
    return RapidOCR()


def extract_rapidocr_text(image_path: Path) -> str:
    """Return local RapidOCR text in the detected reading order."""
    result = _rapidocr_engine()(str(image_path))
    return "\n".join(result.txts or []).strip()


def run_ocrmypdf(input_pdf: Path, output_pdf: Path, sidecar_text: Path) -> None:
    """Create a searchable PDF and retain OCRmyPDF's raw sidecar text locally."""
    executable = Path(sys.executable).parent / "Scripts" / "ocrmypdf.exe"
    if not executable.is_file():
        raise RuntimeError(f"OCRmyPDF is not installed for {sys.executable}.")
    result = subprocess.run(
        [str(executable), "--skip-text", "--deskew", "--output-type", "pdf", "--sidecar", str(sidecar_text), str(input_pdf), str(output_pdf)],
        capture_output=True,
        text=True,
        timeout=1800,
        check=False,
    )
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()
        raise RuntimeError(detail or f"OCRmyPDF exited with code {result.returncode}.")
