"""BOL Images FastAPI application package."""
