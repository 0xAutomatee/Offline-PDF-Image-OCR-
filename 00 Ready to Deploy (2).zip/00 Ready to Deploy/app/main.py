"""FastAPI routes for the BOL Images gallery."""

from datetime import datetime
import hashlib
from pathlib import Path
import threading

from fastapi import FastAPI, File, Header, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from .services import spreadsheets
from .services.retention import clean_unshown_data

from .services.gallery import (
    GALLERY_DIR,
    download_response,
    delete_pdf_output,
    ensure_gallery_dir,
    gallery_cards,
    move_to_trash,
    restore_from_trash,
)
from .services.processing import (
    UPLOAD_DIR,
    duplicate_pdf_names,
    delete_held as delete_held_processing,
    hold as hold_processing,
    resume as resume_processing,
    start as start_processing,
    start_images,
    status as processing_status,
    stop as stop_processing,
)
from .services.integrity import integrity_status, start_manual_integrity_check


ensure_gallery_dir()
app = FastAPI(title="BOL Images", docs_url="/docs")
app.mount("/media", StaticFiles(directory=str(GALLERY_DIR)), name="media")
_repair_lock = threading.Lock()


def ensure_gallery_index() -> Path:
    """Create the lightweight gallery shell when the app starts without one."""
    index = GALLERY_DIR / "index.html"
    if not index.is_file():
        from .services.batch_pdf_to_images import generate_gallery

        generate_gallery()
    return index


def repair_searchable_pdfs_in_background() -> None:
    """Repair older records without delaying application startup."""
    if not _repair_lock.acquire(blocking=False):
        return

    def repair() -> None:
        try:
            from .services.batch_pdf_to_images import cleanup_completed_processing, generate_gallery, repair_searchable_pdfs
            from .services.dependencies import ensure_tesseract

            available, message = ensure_tesseract()
            print(message, flush=True)
            if not available:
                return
            cleaned = cleanup_completed_processing()
            if cleaned:
                print(f"Removed {cleaned} completed temporary processing folder(s).", flush=True)
            repaired, failed = repair_searchable_pdfs()
            if repaired or failed:
                print(f"Searchable PDF startup repair: {repaired} created, {failed} failed.", flush=True)
            generate_gallery()
        except Exception as error:
            print(f"Searchable PDF startup repair failed: {error}", flush=True)
        finally:
            _repair_lock.release()

    threading.Thread(target=repair, name="searchable-pdf-repair", daemon=True).start()


@app.on_event("startup")
def initialize_gallery() -> None:
    # Rebuild the lightweight browser shell once per server start so deployed UI updates apply immediately.
    from .services.batch_pdf_to_images import generate_gallery

    generate_gallery()
    repair_searchable_pdfs_in_background()


@app.get("/health")
def health() -> dict[str, str]:
    """Lightweight endpoint for the local watchdog and service monitor."""
    return {"status": "ok"}


@app.get("/", response_class=FileResponse)
def gallery_home() -> FileResponse:
    # The gallery shell contains live UI logic, so always refresh it instead of
    # leaving a browser with an older JavaScript version after an app update.
    return FileResponse(ensure_gallery_index(), headers={"Cache-Control": "no-store"})


@app.get("/api/download")
def download_image(file: str = Query(...)) -> Response:
    return download_response(file)


@app.get("/api/gallery")
def live_gallery(query: str = Query(""), trash: bool = Query(False), include_text: bool = Query(True)) -> list[dict[str, object]]:
    """Serve a live, disk-backed gallery instead of embedding OCR data in HTML."""
    clean_unshown_data()
    return gallery_cards(query=query, trash=trash, include_text=include_text)


@app.post("/api/spreadsheets/upload")
async def upload_spreadsheets(files: list[UploadFile] = File(...)) -> dict:
    results, errors = [], []
    for upload in files:
        content = await upload.read(spreadsheets.MAX_BYTES + 1)
        try:
            results.append(await run_in_threadpool(spreadsheets.ingest, upload.filename or "", content))
        except HTTPException as error:
            errors.append({"name": upload.filename, "error": error.detail})
        finally:
            await upload.close()
    return {"files": results, "errors": errors}


@app.get("/api/spreadsheets")
def spreadsheet_cards(query: str = Query("")) -> list[dict]:
    return spreadsheets.cards(query)


@app.get("/api/spreadsheets/{file_id}/rows")
def spreadsheet_rows(file_id: str, sheet: int | None = Query(None, ge=0), query: str = Query(""), offset: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=100)) -> dict:
    return spreadsheets.table(file_id, sheet, query, offset, limit)


@app.get("/api/spreadsheets/{file_id}/download")
def spreadsheet_download(file_id: str) -> FileResponse:
    path, name = spreadsheets.original(file_id)
    return FileResponse(path, filename=name)


@app.post("/api/trash")
def trash_image(file: str = Query(...)) -> dict[str, str]:
    return move_to_trash(file)


@app.delete("/api/spreadsheets/{file_id}")
def delete_spreadsheet(file_id: str, confirm: bool = Query(False)) -> dict:
    if not confirm:
        raise HTTPException(400, "Permanent deletion requires confirmation.")
    return spreadsheets.delete_permanently(file_id)


@app.post("/api/restore")
def restore_image(file: str = Query(...)) -> dict[str, str]:
    return restore_from_trash(file)


@app.post("/api/pdf/delete")
def delete_pdf(folder: str = Query(..., min_length=1)) -> dict[str, str]:
    return delete_pdf_output(folder)


@app.get("/api/integrity/status")
def data_validation_status() -> dict[str, object]:
    return integrity_status()


@app.post("/api/integrity/validate")
def validate_data() -> dict[str, object]:
    return start_manual_integrity_check(repair=False)


@app.post("/api/integrity/repair")
def repair_data() -> dict[str, object]:
    return start_manual_integrity_check(repair=True)


@app.get("/api/process/status")
def process_status() -> dict[str, object]:
    return processing_status()




def require_slot_password(slots: int, password: str) -> None:
    if slots != 1 and password != "moreslots":
        raise HTTPException(status_code=403, detail="Enter the correct password to use custom slots.")


@app.post("/api/process/path")
def process_path(source_path: str = Query(...), slots: int = Query(1, ge=1), slot_password: str = Header("", alias="X-Slot-Password")) -> dict[str, object]:
    require_slot_password(slots, slot_password)
    return start_processing(Path(source_path.strip().strip('"')), slots=slots)


@app.post("/api/process/upload")
async def process_upload(files: list[UploadFile] = File(...), slots: int = Query(1, ge=1), slot_password: str = Header("", alias="X-Slot-Password")) -> dict[str, object]:
    require_slot_password(slots, slot_password)
    accepted: list[tuple[str, bytes]] = []
    duplicates: list[dict[str, object]] = []
    incoming: dict[str, str] = {}
    for upload in files:
        if not upload.filename or Path(upload.filename).suffix.lower() != ".pdf":
            continue
        name = Path(upload.filename).name
        content = await upload.read()
        source_sha256 = hashlib.sha256(content).hexdigest()
        existing = duplicate_pdf_names(source_sha256)
        if source_sha256 in incoming:
            existing = sorted(set(existing + [incoming[source_sha256]]))
        if existing:
            duplicates.append({"uploaded": name, "existing": existing})
            continue
        incoming[source_sha256] = name
        accepted.append((name, content))
    if not accepted:
        raise HTTPException(status_code=409, detail={"message": "Duplicate PDF upload was not started.", "duplicates": duplicates})
    upload_folder = UPLOAD_DIR / datetime.now().strftime("%Y%m%d-%H%M%S")
    upload_folder.mkdir(parents=True, exist_ok=True)
    for name, content in accepted:
        (upload_folder / name).write_bytes(content)
    result = start_processing(upload_folder, slots=slots)
    result["duplicates"] = duplicates
    return result


@app.post("/api/process/images")
async def process_images(files: list[UploadFile] = File(...), slots: int = Query(1, ge=1), slot_password: str = Header("", alias="X-Slot-Password")) -> dict[str, object]:
    require_slot_password(slots, slot_password)
    upload_folder = UPLOAD_DIR / ("images-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    upload_folder.mkdir(parents=True, exist_ok=True)
    saved = 0
    for upload in files:
        if upload.filename and Path(upload.filename).suffix.lower() in {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff"}:
            (upload_folder / Path(upload.filename).name).write_bytes(await upload.read())
            saved += 1
    if not saved:
        raise HTTPException(status_code=400, detail="Choose at least one supported image file.")
    return start_images(upload_folder, slots=slots)


@app.post("/api/process/stop")
def stop_process() -> dict[str, object]:
    return stop_processing()


@app.post("/api/process/hold")
def hold_process(held_by: str = Query("", max_length=80)) -> dict[str, object]:
    """Safely pause a job and retain the name of the person who held it."""
    return hold_processing(held_by)


@app.post("/api/process/resume")
def resume_process(job_id: str = Query(..., min_length=1)) -> dict[str, object]:
    return resume_processing(job_id)


@app.delete("/api/process/held")
def delete_held_process(job_id: str = Query(..., min_length=1)) -> dict[str, object]:
    return delete_held_processing(job_id)



