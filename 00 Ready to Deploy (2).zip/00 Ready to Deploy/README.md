# BOL Images deployment package

This folder is a clean copy of the files required to deploy the BOL Images
application. It intentionally excludes generated images, PDFs, OCR data,
uploads, and Python cache files.

## Deploy on a Windows PC

1. Copy this folder to the target PC.
2. Install the dependencies:

   ~~~powershell
   python -m pip install -r requirements.txt
   ~~~

3. Start the local application:

   ~~~powershell
   .\start_bol_images_app.bat
   ~~~

4. Open http://127.0.0.1:8766/.

See app/DEVELOPER.md for terminal OCR commands and the server workflow.
