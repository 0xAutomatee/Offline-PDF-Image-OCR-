# Bulk Email Merge

This is a browser-only mail-merge tool. Keep the experience dependency-light and privacy-first: uploaded workbooks must be processed in the browser and must never be uploaded by this app.

## Structure

- `index.html` contains the application shell and controls.
- `styles.css` contains the visual system and responsive layout.
- `app.js` owns workbook parsing, merge logic, local settings, and draft export.

## Implementation notes

- Use SheetJS through the CDN already referenced by `index.html` for Excel parsing.
- Persist user preferences with `localStorage`, and validate saved column names against the selected sheet.
- Browser security prevents directly saving messages into a desktop mail client's Drafts folder. Keep the “Open mail app” action `mailto:` based and offer `.eml` export as a portable draft alternative.
- Never add a server, telemetry, or upload endpoint without explicit approval.
