document.querySelectorAll('.app-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    if (tab.dataset.view === 'composer') {
      document.getElementById('reviewPanel').classList.add('hidden');
      document.getElementById('composerPanel').classList.remove('hidden');
    }
    if (tab.dataset.view === 'review' && document.getElementById('reviewPanel').classList.contains('hidden')) {
      buildDrafts();
    }
    const target = document.getElementById(tab.dataset.target);
    if (!target || target.classList.contains('hidden')) return;
    document.querySelectorAll('.app-tab').forEach((item) => item.classList.remove('active'));
    tab.classList.add('active');
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});
