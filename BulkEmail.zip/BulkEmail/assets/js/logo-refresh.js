document.getElementById('refreshApp').addEventListener('click', (event) => {
  event.preventDefault();
  saveSettings();
  window.location.reload();
});
