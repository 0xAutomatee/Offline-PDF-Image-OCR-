function emailSafeHtml(content) {
  const copy = content.cloneNode(true);
  copy.querySelectorAll('table').forEach((table) => {
    table.style.cssText = 'border-collapse:collapse;background:#ffffff;color:#111111;font-family:Arial,sans-serif;font-size:14px;line-height:1.45;';
  });
  copy.querySelectorAll('th').forEach((cell) => {
    cell.style.cssText = 'background:#1d7458;color:#ffffff;border:1px solid #b9c8c0;padding:8px 10px;text-align:left;font-weight:700;white-space:nowrap;';
  });
  copy.querySelectorAll('td').forEach((cell) => {
    cell.style.cssText = 'background:#ffffff;color:#111111;border:1px solid #cfd8d2;padding:8px 10px;text-align:left;vertical-align:top;';
  });
  copy.querySelectorAll('.grand-total-row td').forEach((cell) => {
    cell.style.cssText = 'background:#e5f2eb;color:#14513e;border:1px solid #9ab7a8;border-top:2px solid #1d7458;padding:8px 10px;font-weight:700;text-align:right;';
  });
  return `<div style="background:#ffffff !important;color:#111111 !important;font-family:Arial,sans-serif;font-size:14px;line-height:1.5;padding:12px;">${copy.innerHTML}</div>`;
}

async function copyPreviewAsSelected() {
  const content = document.getElementById('previewBodyContent');
  if (!content) return;
  const html = emailSafeHtml(content);
  try {
    if (window.ClipboardItem) {
      await navigator.clipboard.write([new ClipboardItem({
        'text/html': new Blob([html], { type: 'text/html' }),
        'text/plain': new Blob([content.innerText], { type: 'text/plain' })
      })]);
      toast('Preview body copied with light-theme-safe formatting.');
      return;
    }
    await navigator.clipboard.writeText(content.innerText);
    toast('Preview body copied as text.');
  } catch {
    toast('Copy is unavailable in this browser.');
  }
}

document.getElementById('copyOne').onclick = copyPreviewAsSelected;
