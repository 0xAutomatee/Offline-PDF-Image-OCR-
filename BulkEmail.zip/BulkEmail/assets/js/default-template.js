document.getElementById('subjectInput').value = defaultTemplate.subject;
document.getElementById('bodyInput').value = defaultTemplate.body;
