const previewToolbar = document.createElement('div');
previewToolbar.className = 'preview-toolbar';
previewToolbar.innerHTML = '<div class="handoff-copy"><span>Hi Sir,</span><span>Kindly send the below email to: <strong id="forwardEmail"></strong><button class="icon-copy" id="copyForward" type="button" title="Copy forwarding email">⧉</button></span><span>Subject: <strong id="previewSubjectCopy"></strong><button class="icon-copy" id="copySubject" type="button" title="Copy subject">⧉</button></span></div><button class="secondary-button copy-body-top" id="copyTop" type="button">Copy preview body</button>';
document.querySelector('.email-preview').prepend(previewToolbar);
document.getElementById('copyTop').addEventListener('click', () => document.getElementById('copyOne').click());
document.getElementById('previewBody').addEventListener('click', (event) => {
  if (event.target.closest('[data-copy-preview]')) document.getElementById('copyOne').click();
});
document.getElementById('copyForward').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(document.getElementById('forwardEmail').textContent); toast('Forwarding email copied.'); } catch { toast('Copy is unavailable in this browser.'); }
});
document.getElementById('copySubject').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(document.getElementById('previewSubjectCopy').textContent); toast('Subject copied.'); } catch { toast('Copy is unavailable in this browser.'); }
});
